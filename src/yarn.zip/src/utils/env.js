var isLocal = undefined;
var protocol = 'https://';
var domain = 'localhost:9027';
var prefix = '/api/';
var apiPrefix = 'http://localhost:9027' + prefix;

if (process.env.NODE_ENV === "production") {
    apiPrefix = prefix;
}


/*if (window.location.hostname === "localhost") {
    protocol = 'http://'
    domain = "localhost:10150";
    isLocal = "local";
}

//Dev
if (window.location.hostname === "brmapps-dev.fitchratings.com") {
    domain = "brmapps-dev.fitchratings.com";
}

//QA
if (window.location.hostname === "brmapps-qa.fitchratings.com") {
    domain = "brmapps-qa.fitchratings.com";
}

//Prod
if (window.location.hostname === "brmapps.fitchratings.com") {
    domain = "brmapps.fitchratings.com";
}*/

//var apiPrefix = domain + prefix;

export {isLocal, apiPrefix}