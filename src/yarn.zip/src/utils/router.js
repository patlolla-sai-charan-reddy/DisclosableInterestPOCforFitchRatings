import Vue from 'vue'
import VueRouter from 'vue-router'

import {store} from './store/store'

import Home from '../components/routes/Home.vue';
import Forms from '../components/routes/Forms.vue';
import NewDeal from '../components/routes/NewDeal.vue';
import RatedDeals from '../components/routes/RatedDeals.vue';
import NonRatedDeals from '../components/routes/NonRatedDeals.vue'; 
import BulkEntry from '../components/routes/BulkEntry.vue'; 
import DealsSearch from '../components/routes/DealsSearch.vue'; 
import Errors from '../components/routes/Errors.vue';
import Hello from '../components/routes/Hello.vue';

Vue.use(VueRouter)

const routes = [
    {
        path: '/home',
        name: 'home',
        component: Home
    },
    {
        path: '/deals/:id',
        name: 'deals',
        component: Forms
    },
    {
        path: '/newdeal',
        name: 'newDeal',
        component: NewDeal,
        beforeEnter (to, from, next) {
            const userRole = store.getters.getUserRole;
            if (userRole === "Read only") {
                next('home');
            } else {
                store.state.newDeal = true;
                next();
            }
        }
    },
    {
        path: '/bulkupdate/rated',
        name: 'rated',
        component: RatedDeals
    },
    {
        path: '/bulkupdate/rated/:id',
        name: 'rated',
        component: RatedDeals
    },
    {
        path: '/bulkupdate/rated/:id/published',
        name: 'rated',
        component: RatedDeals
    },
    {
        path: '/bulkupdate/unrated',
        name: 'nonrated',
        component: NonRatedDeals
    },
    {
        path: '/bulkupdate/unrated/:id',
        name: 'nonrated',
        component: NonRatedDeals
    },
    {
        path: '/bulkupdate/unrated/:id/published',
        name: 'nonrated',
        component: NonRatedDeals
    },
    {
        path: '/error/:status',
        name: 'error',
        component: Errors
    },
    {
        path: '/isAlive',
        name: 'hello',
        component: Hello
    },
    {
        path: '/bulkupdate',
        name: 'BulkEntry',
        component: BulkEntry
    },
    {
        path: '/deals',
        name: 'DealsSearch',
        component: DealsSearch
    },
    //default
    {
        path: '/',
        redirect: 'home'
    },
    {
        path: '*',
        redirect: '/error/' + 404
    }
];


export const router = new VueRouter({
    routes: routes,
    mode: 'history'
});

router.beforeEach((to, from, next) => {
    //in case directly accesing pages
    store.commit("storeUser");
    //reset control flags
    store.commit('resetControlFlags');
    next();
});