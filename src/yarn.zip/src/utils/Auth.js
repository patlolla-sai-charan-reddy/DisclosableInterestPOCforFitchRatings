import decode from 'jwt-decode';
import axios from 'axios';

export default {
    loggedIn: localStorage.getItem('auth_token'),
    login() {
        if(!this.loggedIn || isTokenExpired(this.loggedIn)) {
            window.location = '/api/login';
        } else {
            //determine user privileges
        }
    }
}

function isTokenExpired(encodedToken) {
    if (!encodedToken) {
        return true;
    }
    const token = decode(encodedToken);
    const expiryDate = new Date(0);
    expiryDate.setUTCSeconds(token.exp);

    //renew if about to expire
    /*var rightNow = Math.floor((new Date().getTime())/1000); //get UTC milliseconds, divide by 1000 to get seconds
    var timeToRenew = token.exp - 900; //15 minutes before token expiration
    var remainingTime = timeToRenew - rightNow;
    remainingTime = remainingTime * 1000; //get milliseconds
    setTimeout(getToken, remainingTime);*/

    return expiryDate < Date.now();
}

/*function getToken() {
    //call
    axios.get('/api/refreshLogin', { headers: { 'Authorization': localStorage.getItem('auth_token') }})
      .then(function (response) {
        localStorage.setItem('auth_token', response.data);
      })
      .catch(function (error) {
        console.log(error);
      });
}*/