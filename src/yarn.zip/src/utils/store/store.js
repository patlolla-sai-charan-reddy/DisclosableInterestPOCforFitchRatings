import Vue from 'vue';
import Vuex from 'vuex';
import decode from 'jwt-decode';

import axios from 'axios';
import $moment from 'moment';
import {HTTP} from '../calls';
import {router} from '../router';

Vue.use(Vuex);

export const store = new Vuex.Store({
    state: {
        hotData: null,
        hotSettings: {
            readOnly: false
        },
        rated: false,
        readOnly: false,
        newDeal: false,
        formsReady: false,
        show: {
            analysts: false,
            cartInfo: false,
            classInfo: false,
            dealInfo: true,
            publishedInfo: true,
            publishedCompletedInfo: true,
            dealMeta: false,
            issuerInfo: false,
            mainInfo: true,
            partiesToDeal: false,
            results: null,
            showRatedResults: false,
            seventeenG5: true,
            showStagingArea: 'false',
            showRated: 'false',
            showNonRated: 'false',
            showNonRated: 'false',
            showSearchInfo: 'false',
            showInitialView: 'true',
            showRatedTable: 'false',
            showSpinner: 'false',
            nonRatedTableView: 'false',
            createNewTable: 'false'
        },
        modal: {
            success: {
                show: false,
                modalRef: "success",
                title: "Success",
                message: "Entered information has been saved!"
            },
            dynamic: {
                show: false,
                modalRef: "dynamic",
                title: "Error",
                message: 'There are errors in one or more rows. Please correct and publish again'
            },
            apiError: {
                show: false,
                modalRef: "apiError",
                title: "Error",
                message: "Something went wrong. Please try again later."
            },
            fieldErrors: {
                show: false,
                modalRef: "fieldErrors",
                title: "Invalid Fields",
                message: "Please fill all the required fields."
            },
            nullSearch: {
                show: false,
                modalRef: "nullSearch",
                title: "Invalid Search",
                message: "No search results found."
            },
            publish: {
                show: false,
                modalRef: "publish",
                title: "Publish",
                message: "Selected Deal Id's are published."
            },
            saved: {
                show: false,
                modalRef: "saved",
                title: "Save",
                message: "Saved in staging area."
            }
        },
        dontSubmit: false,
        classInfoErrors: false,
        dontSubmitClass: false,
        user: {
            userId: null,
            userName: null,
            userRole: null
        },
        searchTerm: "",
        searchResults: [],
        ratedTableResults: [],
        notRatedTableResults: [],
        searchPageLimit: 10,
        searchPageNumber: null,
        formData: {
            dealInfo: {},
            ratedDealInfo: {},
            ratedDealInfoData : {
                rows: []
            },
            classInfo: {
                currency: [],
                classType: [],
                bondType: [],
                jurisdiction: [],
                registration: [],
                rows: []
            },
            lookUpDetails: {
                marketSectorName: []
            },
            partiesToDeal: {
                companyRole: [],
                rows: []
            }
        },//end FORM DATA
        balancTable: {
            fitch: 0,
            snp: 0,
            moodys: 0,
            dbrs: 0,
            morningStar: 0,
            kroll: 0,
            scope: 0,
            total: 0
        },
        datepickerConfig: { 
            format: 'DD-MMM-YYYY',
            extraFormats: [ 'YYYY-MM-DD' ],
            useCurrent: false,
            showClear: true,
            showClose: true,
            icons: {
                time: 'fa fa-clock-o',
                date: 'fa fa-calendar',
                up: 'fa fa-chevron-up',
                down: 'fa fa-chevron-down',
                previous: 'fa fa-chevron-left',
                next: 'fa fa-chevron-right',
                today: 'fa fa-sun-o',
                clear: 'fa fa-trash',
                close: 'fa fa-remove'
            }
        }
    }, //end state
    //getters are like computed properties, in case we don't want to just read state property but with little processing we can have getters
    //for example formatting currency data as currency
    getters: {
        isReadOnly: (state) => {
            return state.readOnly;
        },
        getUser: (state) => {
            return state.user.userName;
        },
        getUserId: (state) => {
            return state.user.userId;
        },
        getUserRole: (state) => {
            return state.user.userRole;
        },
        getSearchTerm: (state) => {
            return state.searchTerm;
        },
        getSearchPageLimit: (state) => {
            return state.searchPageLimit;
        },
        getSearchPageNumber: (state) => {
            return state.searchPageNumber;
        },
        showResults: (state) => {
            return state.show.results;
        },
        showRatedResults: (state) => {
            return state.show.showRatedResults;
        },
        showNotRatedResults: (state) => {
            return state.show.showNotRatedResults;
        },
        showRated: (state) => {
            return state.show.showRated;
        },
        showNonRated: (state) => {
            return state.show.showNonRated;
        },
        showNonRated: (state) => {
            return state.show.showNonRated;
        },
        showSearchInfo: (state) => {
            return state.show.showSearchInfo;
        },
        showInitialView: (state) => {
            return state.show.showInitialView;
        },
        showStagingArea: (state) => {
            return state.show.showStagingArea;
        },
        getSearchResults: (state) => {
            return state.searchResults;
        },
        rowData: (state) => {
            return state.ratedTableResults;
        },
        NonrowData: (state) => {
            return state.notRatedTableResults;
        },
        getLookup: () => {
            return HTTP.get('lookup');
        },
        getFormsStatus: (state) => {
            return state.formsReady;
        },
        getFormData: (state) => {
            return state.formData;
        },
        isNewDeal: (state) => {
            return state.newDeal;
        },
        isRated: (state) => {
            return state.rated;
        },
        showSpinner: (state) => {
            return state.show.showSpinner;
        },
        showRatedTable: (state) => {
            return state.show.showRatedTable;
        },
        nonRatedTableView: (state) => {
            return state.show.nonRatedTableView;
        },
        createNewTable: (state) => {
            return state.show.createNewTable;
        },
        showSection: (state, section) => {
            return (section) => { return state.show[section] };
        },
        required: (state) => {
            if (state.rated) {
                return "";
            }
            return "required";
        },
        getBalanceTable: (state) => {
            return state.balancTable;
        },
        getModal: (state, modalName) => {
            return (modalName) => { return state.modal[modalName] };
        },
        getDatepickerConfig: (state) => {
            return state.datepickerConfig;
        },
        getDealCurrency: (state) => {
            return state.formData.dealInfo.dealIssuanceCurrencyId;
        },
        getDealSize: (state) => {
            return state.formData.dealInfo.dealSize;
        },
        getPricingDate: (state) => {
            return state.formData.dealInfo.pricingDate
        }
    }, //end getters
    //mutations is to change the state but only for synchronous tasks
    mutations: {
        updateData(state, hotData) {
            state.hotData = hotData;
          },
        updateSettings(state, updateObj) {
            state.hotSettings[updateObj.prop] = updateObj.value;
        },
        storeUser: (state) => {
            state.user.userId = localStorage.getItem('user_id');
            state.user.userName = localStorage.getItem('user_name');

            const userRole = localStorage.getItem('user_roles');
            if (userRole.includes('ADMIN')) {
                state.user.userRole = "Admin";
            } else if (userRole.includes('FULL')) {
                state.user.userRole = "BRM";
            } else if (userRole.includes('READ')) {
                state.user.userRole = "Read only";
                state.readOnly = true;
            } else {
                state.user.userRole = "Unknown";
                router.push({ name: 'error', params: { status: 403 }})
            }
        },
        resetControlFlags: (state) => {
            state.rated = false;
            state.newDeal = false;
            state.formsReady = false;
            state.show.analysts = false;
            state.show.cartInfo = false;
            state.show.classInfo = false;
            state.show.dealInfo = true;
            state.show.publishedCompletedInfo = true;
            state.show.publishedInfo = true;
            state.show.dealMeta = false;
            state.show.issuerInfo = false;
            state.show.mainInfo = true;
            state.show.partiesToDeal = false;
            //state.show.results = null;
            state.show.seventeenG5 = false
        },
        onApiError: (state, error) => {
            state.showResults = false;
            if (error.response.status === 401) {
                router.push('/api/login');
            } else {
                router.push({ name: 'error', params: { status: error.response.status }})
            }
        },
        setSearchTerm: (state, value) => {
            return state.searchTerm = value;
        },
        updateSearchResults: (state, data) => {
            return state.searchResults = data;
        },
        updateRatedDealsTable: (state, data) => {
            return state.ratedTableResults = data;
        },
        updateNotRatedDealsTable: (state, data) => {
            return state.notRatedTableResults = data;
        },
        storeSearchPageLimit: (state, limit) => {
            state.searchPageLimit = limit;
        },
        storeSearchPageNumer: (state, page) => {
            state.searchPageNumber = page;
        },
        resetFormData: (state, emptyForm) => {
            state.formData = emptyForm;
        },
        storeDealData: (state, deal) => {
            state.rated = (deal.dealStatus === "NOT RATED") ? false : true;
            state.formData.dealInfo = deal;
            state.formData.classInfo.rows = deal.classInfos;
            //erroneous fields clean up
            state.formData.dealInfo.dealSize = (deal.dealSize === null) ? "" : state.formData.dealInfo.dealSize;
            state.formData.dealInfo.fitchRatedAmount = (deal.fitchRatedAmount === null) ? "" : state.formData.dealInfo.fitchRatedAmount;
            state.formData.classInfo.rows.forEach((item) => {item.originalBalance = item.originalBalance === null ? "" : item.originalBalance;});
        },
        storeRatedDealsData: (state, deal) => {
            //state.formData.ratedDealInfoData.rows = deal.
        },
        storeNewDealData: (state, newDeal) => {
            state.formData.dealInfo.id = newDeal.substring(4);
            state.formData.dealInfo.dealId = newDeal;
            state.formData.dealInfo.dealStatus = "NOT RATED";
            state.formData.dealInfo.dealStatusId = 5;
        },
        storeLookUpData: (state, lookUp) => {
            state.formData.lookUpDetails = lookUp;
            state.formData.classInfo.bondType = lookUp.classBondType;
            state.formData.classInfo.classType = lookUp.classType;
            state.formData.classInfo.currency = lookUp.dealIssuanceCurrency;
            state.formData.classInfo.jurisdiction = lookUp.jurisdiction;
            state.formData.classInfo.registration = lookUp.registration;
            state.formData.partiesToDeal.companyRole = lookUp.companyRole;
            state.formData.lookUpDetails.marketSectorName = lookUp.marketSectorNameAll;
        },
        processPartiesForRender: (state, parties) => {
            let newPartyArray = [];
            let companyRoleObj = {};
            let company = {};
            for(let i=0; i < parties.length; i++ ) {
                let companyRoles = [];
                let companyArray = company[parties[i].companyId];
                companyRoleObj = {
                    desc: parties[i].companyRole,
                    extrafields: {},
                    id: parties[i].companyRoleId
                };
                if (!company[parties[i].companyId]) {
                    newPartyArray.push(Object.assign({}, parties[i]));
                    company[parties[i].companyId] = [];
                }
                if (parties[i].companyRoleId) {
                    company[parties[i].companyId].push(companyRoleObj);
                }
            }
            newPartyArray.forEach((party) => {
                party.companyRoles = company[party.companyId]
            })
            state.formData.partiesToDeal.rows = newPartyArray;
        },
        processPartieForSave: (state) => {
            let parties = state.formData.partiesToDeal.rows;
            let constructParties = [];
            let partyObj = {};
            parties.forEach((party) => {
                partyObj = {
                    companyId: party.companyId,
                    companyName: party.companyName,
                    companyRole: "",
                    companyRoleId: "",
                    createdBy: party.createdBy,
                    dealInfoId: party.dealInfoId,
                    updatedBy: party.updatedBy
                };
                //update roles for each row
                if (party.companyRoles.length) {
                    party.companyRoles.forEach((role) => {
                        partyObj.companyRole = role.desc;
                        partyObj.companyRoleId = role.id;
                        constructParties.push(Object.assign({}, partyObj));
                    });
                } else {
                    constructParties.push(Object.assign({}, partyObj));
                }
            });
            state.formData.dealInfo.partiesToDeal = constructParties;
        },
		updateClassinfoDate: (state, params, e) => {
            state.formData.classInfo.rows.filter(el => el.activeFlag)[params.rowIndex].pricingDate = params.value;
        },
        updateSection: (state, section) => {
            state.show[section] = !state.show[section];
        },
        updateDropdown: (state, event) => {
            state.formData.dealInfo[event.target.id + 'Id'] = event.target.value;
            state.formData.lookUpDetails[event.target.id].forEach((item) => {
                if (item.id === parseInt(event.target.value)) {
                    state.formData.dealInfo[event.target.id] = item.desc;
                }
            });

        },
        calculateBalances: (state) => {
            //reset
            state.balancTable.total = 0;
            state.balancTable.fitch = 0;
            state.balancTable.snp = 0;
            state.balancTable.moodys = 0;
            state.balancTable.dbrs = 0;
            state.balancTable.morningStar = 0;
            state.balancTable.kroll = 0;
            state.balancTable.scope = 0;

            state.formData.classInfo.rows.forEach((row) => {

                if (row.balanceInDealCurrency && row.activeFlag) {
                    if (row.publiclyRatedByFitch && row.bondTypeId !== 1 && row.classTypeId !== 463) {
                        state.balancTable.fitch += row.balanceInDealCurrency;
                    }
                    if (row.spRated) {
                        state.balancTable.snp += row.balanceInDealCurrency;
                    }
                    if (row.moodysRated) {
                        state.balancTable.moodys += row.balanceInDealCurrency;
                    }
                    if (row.dbrsRated) {
                        state.balancTable.dbrs += row.balanceInDealCurrency;
                    }
                    if (row.morningstarRated) {
                        state.balancTable.morningStar += row.balanceInDealCurrency;
                    }
                    if (row.krollRated) {
                        state.balancTable.kroll += row.balanceInDealCurrency;
                    }
                    if (row.scopeRated) {
                        state.balancTable.scope += row.balanceInDealCurrency;
                    }
                    state.balancTable.total += row.balanceInDealCurrency;
                }
                row.updatedBy = row.classId ? state.user.userId : null;
            });
        },
        updateDate: (state, {object, key, value}) => {
            object[key] = value ? $moment(value).format('YYYY-MM-DD') : null;
        },
        updateNewDealModelSave: (state) => {
            state.formData.dealInfo.classInfos = state.formData.classInfo.rows;
            state.formData.dealInfo.partiesToDeal = state.formData.partiesToDeal.rows;
            state.formData.dealInfo.createdBy = state.user.userId;
        },
        updateRatedDealModalSave: (state) => {
            state.formData.ratedDealInfo.stagingData = state.formData.ratedDealInfoData.rows;
        },
        showModal: (state, modalName) => {
            state.modal[modalName].show = true;
        },
        hideModal: (state, modalName) => {
            state.modal[modalName].show = false;
        }
    }, //end mutations
    //actions for doing asynchornous tasks
    actions: {
        tryLogin: ({commit, dispatch}) => {
            const token = localStorage.getItem('auth_token');
            if (!token) {
                dispatch('login');
                return
            }
            //Token validity
            const decodedToken = decode(token);
            const expiryDate = new Date(0);
            expiryDate.setUTCSeconds(decodedToken.exp);
            const expired = Date.now() > expiryDate;
            if(expired) {
                dispatch('login');
                return
            }

            commit('storeUser');
        },
        login: () => {
            window.location = '/api/login';
        },
        updateSearchTerm: ({commit}, value) => {
            commit('setSearchTerm', value);
        },
        fetchStagingArea: ({commit, state}, flag) => {
            /* Temp Logic */
            if(flag === "loadNextView") {
                router.push({ path: '/bulkupdate'});
            } else if (flag === "loadSearchView") {
                router.push({ path: '/deals'});
            } else if (flag === "updateRated") {
                router.push({ path: '/bulkupdate/rated'});
            } else if (flag === "loadNonrated") {
                router.push({ path: '/bulkupdate/unrated'});
            } else if (flag === "test5") {
                router.push({ path: '/deals'});
            }
        },
        fetchForNotRatedResults: ({commit, state}, api, flag) => {
            let defineApi = '';
            /*
            if(api.workId) {
                defineApi = 'fetchWorkIdDeals';
            } else {
                defineApi = 'searchnotrateddeals'
            }*/
            if(api.workId) {
                defineApi = 'fetchNotRatedWorkIdDeals';
            } else {
                defineApi = 'searchnotrateddeals'
            }
            state.show.showSpinner = 'true';
            state.show.nonRatedTableView = 'false';
            state.show.createNewTable = 'false';
            if(window.location.href.indexOf('published') > -1) {
                api.tableType = "publish";
            } else {
                api.tableType = "staged";
            }

            HTTP.post(defineApi, api)
            .then(response => {    
                state.show.showNotRatedResults= response.data.length ? "true" : commit('showModal', 'nullSearch');
                state.show.showSpinner = 'false';
                state.show.nonRatedTableView = 'true';
                var convertY = [];
                response.data.map(el => { 
                    convertY.push({
                        recordStatus: el.recordStatus,
                        checked: el.checked,
                        ID: el.ID,
                        DEAL_ID: el.DEAL_ID,
                        MANAGEMENT_LINE_REGION: el.MANAGEMENT_LINE_REGION,
                        COUNTRY_OF_ASSETS: el.COUNTRY_OF_ASSETS,
                        DEAL_ISSUANCE_CURRENCY: el.DEAL_ISSUANCE_CURRENCY,
                        PRICING_DATE: el.PRICING_DATE,
                        MANAGEMENT_LINE: el.MANAGEMENT_LINE,
                        MARKET_SECTOR_NAME: el.MARKET_SECTOR_NAME,
                        DEAL_NAME: el.DEAL_NAME,
                        FITCH_RATED_AMOUNT: el.FITCH_RATED_AMOUNT,
                        REASON_NOT_RATED: el.REASON_NOT_RATED,
                        REASON_NOT_RATED_COMMENT: el.REASON_NOT_RATED_COMMENT,
                        PUBLICLY_RATED_BY_FITCH: el.PUBLICLY_RATED_BY_FITCH == true ? 'Y' : el.PUBLICLY_RATED_BY_FITCH == false ? 'N' : '',
                        INCLUDE_IN_REPORT: el.INCLUDE_IN_REPORT == true ? 'Y' : el.INCLUDE_IN_REPORT == false ? 'N' : '',
                        MOODYS_RATED: el.MOODYS_RATED == true ? 'Y' : el.MOODYS_RATED == false ? 'N' : '',
                        SP_RATED: el.SP_RATED == true ? 'Y' : el.SP_RATED == false ? 'N' : '',
                        DBRS_RATED: el.DBRS_RATED == true ? 'Y' : el.DBRS_RATED == false ? 'N' : '',
                        KROLL_RATED: el.KROLL_RATED == true ? 'Y' : el.KROLL_RATED == false ? 'N' : '',
                        MORNINGSTAR_RATED: el.MORNINGSTAR_RATED == true ? 'Y' : el.MORNINGSTAR_RATED == false ? 'N' : '',
                        SCOPE_RATED: el.SCOPE_RATED == true ? 'Y' : el.SCOPE_RATED == false ? 'N' : '',
                        REGISTRATION: el.REGISTRATION,
                        JURISDICTION: el.JURISDICTION,
                        CLASS_NAME: el.CLASS_NAME,
                        ORIGINATOR: el.ORIGINATOR,
                        ARRANGER: el.ARRANGER,
                        SPONSOR_OF_THE_SPV: el.SPONSOR_OF_THE_SPV,
                        ASSET_MANAGER: el.ASSET_MANAGER,
                        SUB_SECTOR: el.SUB_SECTOR
                    })
                })

                commit('updateNotRatedDealsTable', convertY);

            })
            .catch((error) => commit('onApiError', error));
        },
        fetchNewTable: ({commit, state}, api, flag) => {
            state.show.showSpinner = 'true';
            state.show.nonRatedTableView = 'false';
            state.show.createNewTable = 'false';

            HTTP.get('getNewNotRatedRecords')
            .then(response => {    
                state.show.showNotRatedResults= response.data.length ? "true" : commit('onApiError', error);
                var convertY = [];
                response.data.map(el => { 
                    convertY.push({
                        recordStatus: el.recordStatus,
                        checked: el.checked,
                        ID: el.ID,
                        DEAL_ID: el.DEAL_ID,
                        MANAGEMENT_LINE_REGION: el.MANAGEMENT_LINE_REGION,
                        COUNTRY_OF_ASSETS: el.COUNTRY_OF_ASSETS,
                        DEAL_ISSUANCE_CURRENCY: el.DEAL_ISSUANCE_CURRENCY,
                        PRICING_DATE: el.PRICING_DATE,
                        MANAGEMENT_LINE: el.MANAGEMENT_LINE,
                        MARKET_SECTOR_NAME: el.MARKET_SECTOR_NAME,
                        DEAL_NAME: el.DEAL_NAME,
                        FITCH_RATED_AMOUNT: el.FITCH_RATED_AMOUNT,
                        REASON_NOT_RATED: el.REASON_NOT_RATED,
                        REASON_NOT_RATED_COMMENT: el.REASON_NOT_RATED_COMMENT,
                        PUBLICLY_RATED_BY_FITCH: el.PUBLICLY_RATED_BY_FITCH == true ? 'Y' : el.PUBLICLY_RATED_BY_FITCH == false ? 'N' : '',
                        INCLUDE_IN_REPORT: el.INCLUDE_IN_REPORT == true ? 'Y' : el.INCLUDE_IN_REPORT == false ? 'N' : '',
                        MOODYS_RATED: el.MOODYS_RATED == true ? 'Y' : el.MOODYS_RATED == false ? 'N' : '',
                        SP_RATED: el.SP_RATED == true ? 'Y' : el.SP_RATED == false ? 'N' : '',
                        DBRS_RATED: el.DBRS_RATED == true ? 'Y' : el.DBRS_RATED == false ? 'N' : '',
                        KROLL_RATED: el.KROLL_RATED == true ? 'Y' : el.KROLL_RATED == false ? 'N' : '',
                        MORNINGSTAR_RATED: el.MORNINGSTAR_RATED == true ? 'Y' : el.MORNINGSTAR_RATED == false ? 'N' : '',
                        SCOPE_RATED: el.SCOPE_RATED == true ? 'Y' : el.SCOPE_RATED == false ? 'N' : '',
                        REGISTRATION: el.REGISTRATION,
                        JURISDICTION: el.JURISDICTION,
                        CLASS_NAME: el.CLASS_NAME,
                        ORIGINATOR: el.ORIGINATOR,
                        ARRANGER: el.ARRANGER,
                        SPONSOR_OF_THE_SPV: el.SPONSOR_OF_THE_SPV,
                        ASSET_MANAGER: el.ASSET_MANAGER,
                        SUB_SECTOR: el.SUB_SECTOR
                    })
                })

                commit('updateNotRatedDealsTable', convertY);
                state.show.showSpinner = 'false';
                state.show.createNewTable = 'true';

            })
            .catch((error) => commit('onApiError', error));
        },
        fetchRatedResults: ({commit, state}, api) => {
            let defineApi = '';
            if(api.workId) {
                defineApi = 'fetchWorkIdDeals';
            } else {
                defineApi = 'searchForRatedDeals'
            }
            if(window.location.href.indexOf('published') > -1) {
                api.tableType = "publish";
            } else {
                api.tableType = "staged";
            }
            state.show.showSpinner = 'true';
            state.show.showRatedTable = 'false';
            HTTP.post(defineApi, api)
            .then(response => {
                state.show.showRatedResults= response.data.length ? "true" : commit('showModal', 'nullSearch');
                state.show.showSpinner = 'false';
                state.show.showRatedTable = 'true';
                var convertY = [];
                response.data.map(el => {
                    convertY.push({
                        checked: el.checked,
                        className: el.className,
                        dbrsRated: el.dbrsRated == true ? 'Y' : (el.dbrsRated == false ? 'N' : ''),
                        dealId: el.dealId,
                        dealName: el.dealName,
                        fitchRated: el.fitchRated == true ? 'Y' : (el.fitchRated == false ? 'N' : ''),
                        id: el.id,
                        includeInReport: el.includeInReport == true ? 'Y' : el.includeInReport == false ? 'N' : '',
                        moodysRated: el.moodysRated == true ? 'Y' : el.moodysRated == false ? 'N' : '',
                        mrngStarRated: el.mrngStarRated == true ? 'Y' : el.mrngStarRated == false ? 'N' : '',
                        krollRated: el.krollRated == true ? 'Y' : el.krollRated == false ? 'N' : '',
                        pricingDate: el.pricingDate,
                        registration: el.registration,
                        scopeRated: el.scopeRated == true ? 'Y' :  el.scopeRated == false ? 'N' : '',
                        snpRated: el.snpRated == true ? 'Y' : el.snpRated == false ? 'N': '',
                    })
                })

                
                commit('updateRatedDealsTable', convertY);

            })
            .catch((error) => commit('onApiError', error));
        },
        fetchResults: ({commit, state}, api) => {
            HTTP.get(api)
                .then(response => {
                    state.show.results= response.data.length ? "true" : "false";
                    //reset component pagination to first page
                    commit('storeSearchPageNumer', 1);
                    commit('updateSearchResults', response.data);
                })
                .catch((error) => commit('onApiError', error));
        },
        fetchDeal: ({commit, state, getters}, dealId) => {

            const getDeal = () => {
                return HTTP.get('deals/' + dealId);
            };
            const getLookup = getters.getLookup;

            axios.all([getDeal(), getLookup])
                .then(axios.spread((deal, lookup) => {
                    //deal
                    commit('storeDealData', deal.data);
                    //lookup
                    commit('storeLookUpData', lookup.data.lookUpDataDetails);
                    commit('processPartiesForRender', deal.data.partiesToDeal);
                    //Render the form
                    state.formsReady = true;
                }))
                .catch((error) => commit('onApiError', error));
        },
        fetchRatedDealData: ({commit, state, getters}, dealId) => {
            const getDeal = () => {
                return HTTP.get('deals/' + dealId);
            };
            const getLookup = getters.getLookup;

            axios.all([getDeal(), getLookup])
                .then(axios.spread((deal, lookup) => {
                    //deal
                    commit('storeRatedDealsData', deal.data);

                }))
                .catch((error) => commit('onApiError', error));
        },
        fetchNewDeal: ({commit, state, getters}) => {
            const getNextDealId = () => {
                return HTTP.get('nextDealId');
            };
            const getLookup = getters.getLookup;

            axios.all([getNextDealId(), getLookup])
                .then(axios.spread((newDeal, lookup) => {
                    //dealId
                    commit('storeNewDealData', newDeal.data);
                    //lookup
                    commit('storeLookUpData', lookup.data.lookUpDataDetails);

                    //render the form
                    state.formsReady = true;
                }))
                .catch((error) => commit('onApiError', error));
        },
        storeDeal: ({commit, state, getters}, newDeal) => {
            //validate ClassInfos
            state.formData.dealInfo.classInfos.forEach((item) => {
                if (item.activeFlag === true) {
                    if (getters.required) {
                        if (!item.name || !item.registrationId || !item.originalBalance || !item.currencyId) {
                            state.classInfoErrors = true;
                            return;
                        }
                    }
                    if (!item.jurisdictionId || !item.pricingDate) {
                            state.classInfoErrors = true;
                            return;
                    }
                }
            });
            //validate entire form
            if (state.dontSubmit || state.classInfoErrors) {
                state.dontSubmitClass = true;
                commit('showModal', 'fieldErrors');
            } else {
                //parties
                commit('processPartieForSave');
                //if no creator then update
                state.formData.dealInfo.updatedBy = state.formData.dealInfo.createdBy ? state.user.userId : state.formData.dealInfo.updatedBy;
                //if no creator then make current user creator
                state.formData.dealInfo.createdBy = state.formData.dealInfo.createdBy ? state.formData.dealInfo.createdBy : state.user.userId;

                HTTP.put('deals', state.formData.dealInfo)
                    .then(response => {
                        if (newDeal) {
                            router.push({ path: '/deals/' + state.formData.dealInfo.dealId })
                        } else {
                            commit('showModal', 'success');
                        }
                    })
                    .catch(error => {
                        commit('showModal', 'apiError');
                    });
            }

            //reset
            state.dontSubmit = false;
            state.classInfoErrors = false;
        },
        sendRatedDeals: ({commit, state, getters}, newDeal) => {

            HTTP.put('storeStageData',newDeal)
            .then(response => {
                commit('showModal', 'saved');
            })
            .catch(error => {
                commit('showModal', 'apiError');
            });
        },
        sendNotRatedDeals: ({commit, state, getters}, newDeal) => {
            HTTP.put('storeStageNotRatedData',newDeal)
            .then(response => {
                commit('showModal', 'saved');
            })
            .catch(error => {
                commit('showModal', 'apiError');
            });
        },
        publishNotRatedDeals: ({commit, state, getters}, newDeal) => {
            HTTP.put('publishNotRatedDeals',newDeal)
            .then(response => {
                if(response.data.message !== undefined) {
                    commit('showModal', 'dynamic');
                    $("#app > div > div:nth-child(4) > div.my-form.search-table-data > div.ag-theme-fresh > div > div.ag-root-wrapper-body.ag-layout-normal > div.ag-root.ag-font-style.ag-layout-normal > div.ag-body.ag-layout-normal.ag-row-no-animation > div.ag-body-viewport-wrapper.ag-layout-normal > div > div >").css('background', 'white');
                    for(var i=0; i < response.data.index.split("-").length; i++) {
                        $("#app > div > div:nth-child(4) > div.my-form.search-table-data > div.ag-theme-fresh > div > div.ag-root-wrapper-body.ag-layout-normal > div.ag-root.ag-font-style.ag-layout-normal > div.ag-body.ag-layout-normal.ag-row-no-animation > div.ag-body-viewport-wrapper.ag-layout-normal > div > div >[row-index=" + response.data.index.split("-")[i] + "]").css('background', '#ff7f50');
                    }
                } else {
                    $("#app > div > div:nth-child(4) > div.my-form.search-table-data > div.ag-theme-fresh > div > div.ag-root-wrapper-body.ag-layout-normal > div.ag-root.ag-font-style.ag-layout-normal > div.ag-body.ag-layout-normal.ag-row-no-animation > div.ag-body-viewport-wrapper.ag-layout-normal > div > div >").css('background', 'white');
                    commit('showModal', 'publish');
                }
            })
            .catch(error => {
                commit('showModal', 'apiError');
            });
        },
        publishRatedDeals: ({commit, state, getters}, newDeal) => {
            HTTP.put('publishDeals',newDeal)
            .then(response => {
                if(response.data.message !== undefined) {
                    commit('showModal', 'dynamic');
                    $("#app > div > div.my-form.loading-area > div.ag-theme-fresh > div > div.ag-root-wrapper-body.ag-layout-normal > div.ag-root.ag-font-style.ag-layout-normal > div.ag-body.ag-layout-normal.ag-row-no-animation > div.ag-body-viewport-wrapper.ag-layout-normal > div > div >").css('background', 'white');
                    for(var i=0; i < response.data.index.split("-").length; i++) {
                        $("#app > div > div.my-form.loading-area > div.ag-theme-fresh > div > div.ag-root-wrapper-body.ag-layout-normal > div.ag-root.ag-font-style.ag-layout-normal > div.ag-body.ag-layout-normal.ag-row-no-animation > div.ag-body-viewport-wrapper.ag-layout-normal > div > div >[row-index=" + response.data.index.split("-")[i] + "]").css('background', '#ff7f50');
                    }
                } else {
                    $("#app > div > div.my-form.loading-area > div.ag-theme-fresh > div > div.ag-root-wrapper-body.ag-layout-normal > div.ag-root.ag-font-style.ag-layout-normal > div.ag-body.ag-layout-normal.ag-row-no-animation > div.ag-body-viewport-wrapper.ag-layout-normal > div > div >").css('background', 'white');
                    commit('showModal', 'publish');
                }
            })
            .catch(error => {
                commit('showModal', 'apiError');
            });
        },
        searchCallForRated() {
        }
    }// end actions
});