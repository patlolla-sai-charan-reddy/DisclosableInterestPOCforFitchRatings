import axios from 'axios';
import {isProd, apiPrefix} from './env';


export const HTTP = axios.create({
    baseURL: apiPrefix,
    headers: {
        'Authorization': localStorage.getItem('auth_token')
    }
});

/*HTTP.interceptors.response.use(
    function (response) {
        return response;
    },
    function (error) {
        if (error.response.status === 401) {
            window.location = '/api/login';
        }
});*/