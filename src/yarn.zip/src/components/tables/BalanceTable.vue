<style type="text/css" scoped>
    div.table-container {
        padding-left: 0;
    }
    .table-container th, .table-container td {
        min-width: 125px;
    }
    .row {
        margin-bottom: 10px;
    }
</style>
<template>
    <div>
        <div class="row">
            <div class="col-sm-4 col-md-4 col-lg-4 key">
                TOTAL OVERALL AMOUNT
            </div>
            <div class="col-sm-4 col-md-4 col-lg-4 key">{{ balanceTable.total | currency }}</div>
        </div>
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>AGENCIES</th>
                        <th>RATED AMOUNT IN DEAL CURRENCY</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Fitch</td>
                        <td> {{ balanceTable.fitch | currency }} </td>
                    </tr>
                    <tr>
                        <td>S&amp;P</td>
                        <td> {{ balanceTable.snp | currency }} </td>
                    </tr>
                    <tr>
                        <td>Moody's</td>
                        <td> {{ balanceTable.moodys | currency }} </td>
                    </tr>
                    <tr>
                        <td>DBRS</td>
                        <td> {{ balanceTable.dbrs | currency }} </td>
                    </tr>
                    <tr>
                        <td>Morningstar</td>
                        <td> {{ balanceTable.morningStar | currency }} </td>
                    </tr>
                    <tr>
                        <td>Kroll</td>
                        <td> {{ balanceTable.kroll | currency }} </td>
                    </tr>
                     <tr>
                        <td>Scope</td>
                        <td> {{ balanceTable.scope | currency }} </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>
<script>
    import {EventBus} from '../../utils/bus';
    export default {
        props: {
            model: {
                type: Object,
                required: true
            }
        },
        data() {
            return {
                fitch: 0,
                snp: 0,
                moodys: 0,
                dbrs: 0,
                morningStar: 0,
                kroll: 0,
                scope: 0,
                total: 0
            }
        },
        computed: {
            balanceTable() {
                return this.$store.getters.getBalanceTable;
            }
        },
        filters: {
            currency(value) {
                return " " + value.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,");
            }
        },
        methods: {
            calculateBalances() {
                //reset
                this.total = 0;
                this.fitch = 0;
                this.snp = 0;
                this.moodys = 0;
                this.dbrs = 0;
                this.morningStar = 0;
                this.kroll = 0;
                this.scope = 0;

                this.model.rows.forEach((row) => {

                    if (row.balanceInDealCurrency) {
                        if (row.publiclyRatedByFitch && row.bondTypeId !== 1 && row.classTypeId !== 463) {
                            this.fitch += row.balanceInDealCurrency;
                        }
                        if (row.spRated) {
                            this.snp += row.balanceInDealCurrency;
                        }
                        if (row.moodysRated) {
                            this.moodys += row.balanceInDealCurrency;
                        }
                        if (row.dbrsRated) {
                            this.dbrs += row.balanceInDealCurrency;
                        }
                        if (row.morningstarRated) {
                            this.morningStar += row.balanceInDealCurrency;
                        }
                        if (row.krollRated) {
                            this.kroll += row.balanceInDealCurrency;
                        }
                         if (row.scopeRated) {
                            this.scope += row.balanceInDealCurrency;
                        }
                        this.total += row.balanceInDealCurrency;
                    }
                });
            }
        }
    }
</script>