<style scoped>
    .grid-class {
        width: 100%;
        height: 400px;
        margin-bottom: 20px;
    }
    .group-updates {
        padding-bottom: 15px;
        border-bottom: 1px solid #CCC;
        margin-bottom: 15px;
    }
    .btn-modal {
        margin-bottom: 20px;
    }
</style>
<template>
    <div>
        <ag-grid-vue class="ag-theme-fresh grid-class"
            :gridReady="onReady"
            :gridOptions="gridOptions"
            :columnDefs="columnDefs"
            :rowData="rowData"
            :enableColResize="true"
            :suppressColumnVirtualisation="true"
            :enableSorting="true"
            :enableFilter="false"
            :singleClickEdit="true"
            rowHeight="40"
            headerHeight="40">
        </ag-grid-vue>
        <div v-if="isNotRated && !readOnly" class="btn btn-md btn-modal" @click="addRow">Add New Class</div>
        <div v-if="isNotRated && !readOnly" class="btn btn-md btn-modal" @click="removeRow">Delete Selected</div>
    </div>
</template>

<script>
    import {AgGridVue} from 'ag-grid-vue';

    import { store } from '../../utils/store/store';
    import {HTTP} from '../../utils/calls';
    //table components
    import HeaderInput from './Components/HeaderInput.vue';
    import HeaderCheckbox from './Components/HeaderCheckbox.vue';
    import ClassCurrency from './Components/ClassCurrency.vue';
    import ClassSelect from './Components/ClassSelect.vue';
    import Checkbox from './Components/Checkbox.vue';
    import OriginalBalance from './Components/OriginalBalance.vue';
    import ClassMoney from './Components/ClassMoney.vue';
    import MyInput from './Components/MyInput.vue';
    import DateInput from './Components/DateInput.vue';
    import moment from 'moment';

    export default {
        props: {
            type: {
                type: Boolean
            },
            dealCurrency: {
                //type: Number
            },
            model: {
                type: Object
            },
            flag: {}
        },
        data () {
            return {
                columnDefs: null,
                colIds: [],
                showGrid: false,
                newRow: {
                    id: null,
                    classId: null,
                    name: "",
                    classTypeId: null,
                    classTypeDesc: null,
                    activeFlag: true,
                    originalBalance: "",
                    currency: null,
                    currencyId: null,
                    registration: null,
                    registrationId: null,
                    cusip: null,
                    isin: null,
                    pricingDate: null,
                    ratedDeals: null,
                    includeInMSReport: true,
                    publiclyRatedByFitch: false,
                    spRated: false,
                    scopeRated: false,
                    moodysRated: false,
                    dbrsRated: false,
                    morningstarRated: false,
                    krollRated: false,
                    jurisdiction: null,
                    jurisdictionId: null,
                    dealInfoId: null,
                    createdBy: this.$store.state.user.userId,
                    updatedBy: null
                }
            }
        },
        computed: {
            isRated() {
                return this.$store.getters.isRated;
            },
            isNotRated() {
                return !this.$store.getters.isRated;
            },
            readOnly() {
                return this.$store.getters.isReadOnly;
            },
            showSection() {
                return this.$store.getters.showSection('classInfoMock');
            },
            rowData() {
                const filteredRows = [];
                this.model.rows.forEach((item, i) => {
                    if (item.activeFlag) {
                        filteredRows.push(item);
                    } 
                });
                return filteredRows;
            },
            dealPricingDate() {
                return this.$store.getters.getPricingDate;
            }
        },
        components: {
            'ag-grid-vue': AgGridVue,
            HeaderInput,
            HeaderCheckbox,
            ClassCurrency,
            ClassSelect,
            datePicker: getDatePicker(),
            Checkbox,
            ClassMoney,
            OriginalBalance,
            MyInput,
            DateInput
        },
        watch: {
            flag() {

                if (this.flag) {
                    this.resizeColumns();
                }
            }
        },
        created() {
            //Update Balance In Deal Currency
            this.model.rows.forEach(function(row){
                if (this.dealCurrency && row.currencyId && row.originalBalance) {
                    HTTP.get('convertCurrency?from=' + row.currencyId + '&to=' + this.dealCurrency + '&amount=' + row.originalBalance)
                        .then(response => {
                            row.balanceInDealCurrency = response.data;
                            this.$store.commit('calculateBalances');
                            this.gridOptions.api.refreshCells();
                        })
                        .catch(error => {
                            //console.log("error", error.response);
                        })
                }
            }.bind(this));
        },
        mounted() {
            //field validation
            this.$bus.$on('veeValidate', () => {
                this.$validator.validateAll();
            });
        },
        methods: {
            onReady() {
                this.gridOptions.columnApi.getAllColumns().forEach((column) => {
                    this.colIds.push(column.colId);
                });
            },
            addRow() {
                HTTP.get('nextClassId')
                .then(response => {
                    this.newRow.id = response.data;
                    this.newRow.classId = response.data;
                    this.newRow.pricingDate = this.dealPricingDate;
                    //this.newRow.ratedDeals = this.dealPricingDate;
                    this.model.rows.push(Object.assign({}, this.newRow)); // imp
                })
                .catch(error => {
                    this.$root.$emit('bv::show::modal','errorModal');
                });
            },
            removeRow: function () {
                var rowsToDelete = this.gridOptions.api.getSelectedRows();
                rowsToDelete.forEach((item) => {
                    item.activeFlag = false;
                });
                this.$store.commit('calculateBalances');
                //this.model.rows.splice(index, 1);
            }, 
            resizeColumns() {
                this.gridOptions.columnApi.autoSizeColumns(this.colIds);
            },
            createColumnDefs() {
                this.columnDefs = [
                    {
                        headerName: 'CLASS DETAILS',
                        //headerGroupComponentFramework: HeaderGroupComponent,
                        children: [
                            {
                                colId: 'name',
                                field:'name',
                                pinned: true,
                                width: 140,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Class Name'},
                                cellRendererFramework: MyInput
                            }
                        ]
                    },
                    {
                        headerName: 'REQUIRED FIELDS',
                        //headerGroupComponentFramework: HeaderGroupComponent,
                        children: [
                            {
                                colId: "registration",
                                field: "registration",
                                minWidth: 100,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Registration'},
                                cellRendererFramework: ClassSelect
                            },
                            {
                                colId: "pricingDate",
                                cellClass: "class-date-picker",
                                field: "pricingDate",
                                minWidth: 115,
                                editable: true,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Pricing Date'},
                                cellEditor: "datePicker",
                                cellRendererFramework: DateInput
                            },
                           
                            {
                                colId: "jurisdiction",
                                field: "jurisdiction",
                                minWidth: 130,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Jurisdiction'},
                                cellRendererFramework: ClassSelect
                            },
                        ]
                    },
                    {
                        headerName: 'AMOUNT',
                        children: [
                            {
                                colId: "currency",
                                field: "currencyId",
                                minWidth: 140,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Currency'},
                                cellRendererFramework: ClassCurrency,
                            },
                            {
                                colId: "originalBalance",
                                field: "originalBalance",
                                width: 130,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Original Balance'},
                                cellRendererFramework: OriginalBalance,
                            },
                            {
                                headerName: "Balance in Deal Currency",
                                field: "balanceInDealCurrency",
                                width: 140,
                                cellRendererFramework: ClassMoney,
                            }
                        ]
                    },
                    {
                        headerName: 'MARKET SHARE',
                        children: [
                            {
                                colId: "publiclyRatedByFitch",
                                minWidth: 80,
                                headerComponentFramework: HeaderCheckbox,
                                headerComponentParams: { name: 'Fitch'},
                                cellRendererFramework: Checkbox
                            },
                            {
                                colId: "spRated",
                                minWidth: 70,
                                headerComponentFramework: HeaderCheckbox,
                                headerComponentParams: { name: 'S&P'},
                                cellRendererFramework: Checkbox
                            },
                            {
                                colId: "moodysRated",
                                minWidth:100,
                                headerComponentFramework: HeaderCheckbox,
                                headerComponentParams: { name: 'Moodys'},
                                cellRendererFramework: Checkbox
                            },
                            {
                                colId: "dbrsRated",
                                minWidth:80,
                                headerComponentFramework: HeaderCheckbox,
                                headerComponentParams: { name: 'DBRS'},
                                cellRendererFramework: Checkbox
                            },
                            {
                                colId: "morningstarRated",
                                width:125,
                                headerComponentFramework: HeaderCheckbox,
                                headerComponentParams: { name: 'Morningstar'},
                                cellRendererFramework: Checkbox
                            },
                            {
                                colId: "krollRated",
                                minWidth:80,
                                headerComponentFramework: HeaderCheckbox,
                                headerComponentParams: { name: 'Kroll'},
                                cellRendererFramework: Checkbox
                            },
                            {
                                colId: "scopeRated",
                                minWidth:80,
                                headerComponentFramework: HeaderCheckbox,
                                headerComponentParams: { name: 'Scope'},
                                cellRendererFramework: Checkbox
                            },
                        ]
                    },
                    {
                        headerName: 'OTHER',
                        children: [
                            {
                                colId: "includeInMSReport",
                                maxWidth:95,
                                headerComponentFramework: HeaderCheckbox,
                                headerComponentParams: { name: 'Include in Report?'},
                                cellRendererFramework: Checkbox
                            },
                            {
                                headerName: "Class Type",
                                colId: "classType",
                                field: "classType",
                                cellRendererFramework: ClassSelect,
                            },
                            {
                                headerName: "Legal Maturity Date",
                                colId: "legalMaturityDate",
                                cellClass: 'class-date-picker',
                                field: "legalMaturityDate",
                                minWidth: 115,
                                editable:this.isNotRated,
                                cellEditor: "datePicker",
                                cellRendererFramework: DateInput
                            },
                            {
                                headerName: "Bond Type",
                                colId: "bondType",
                                field: "bondType",
                                cellRendererFramework: ClassSelect,
                            },
                            {
                                headerName: "CUSIP",
                                colId: 'cusip',
                                field: "cusip",
                                minWidth: 105,
                                cellRendererFramework: MyInput
                            },
                            {
                                headerName: "ISIN",
                                colId: "isin",
                                field: "isin",
                                minWidth: 125,
                                cellRendererFramework: MyInput
                            }
                        ]
                    },
                    {
                        headerName: 'Delete',
                        colId: 'delete',
                        width: 120,
                        hide: this.isRated,
                        headerCheckboxSelection: this.isNotRated,
                        checkboxSelection: this.isNotRated
                    }
                ];
            }
        },
        beforeMount() {
            this.gridOptions = {
                components:{
                    datePicker: getDatePicker()
                }
            };
            this.createColumnDefs();
            this.showGrid = true;
        }
    }
//DatePicker for AG-Grid
function getDatePicker() {
    function Datepicker() {}
    Datepicker.prototype.init = function(params) {
        this.eInput = document.createElement("input");
        this.eInput.className = 'ag-cell';
        //this.eInput.value = this.$moment(params.value).format('YYYY-MM-DD');
         this.eInput.value = moment(params.value).format('DD-MMM-YYYY');
         window.$(this.eInput).datepicker({ 
                dateFormat: "dd-M-yy",
                onSelect: function (date) {
                    params.value = date;
                    var eInputvalue = this;
                    Datepicker.prototype.setDateAndClose(eInputvalue);
                    Datepicker.prototype.getValue(eInputvalue, date, params);
                }
            });
    };
    Datepicker.prototype.getGui = function() {
        return this.eInput;
    };
    Datepicker.prototype.setDateAndClose = function(eInputvalue) {
        this.eInput  = eInputvalue;

        Datepicker.prototype.destroy();
      };
    Datepicker.prototype.afterGuiAttached = function() {
        this.eInput.focus();
        this.eInput.select();
        this.eInput.value = event.target.value;//moment(params.value).format('DD-MMM-YYYY');
    };
    Datepicker.prototype.getValue = function() {
        return this.eInput.value;
    };
    Datepicker.prototype.getValue = function(eInputvalue, date, params, e) {
        params.value = moment(params.value).format('YYYY-MM-DD');
            this.eInput = eInputvalue;
            this.eInput.value = date;
            store.commit('updateClassinfoDate', params);
        }
        Datepicker.prototype.destroy = function() {};
        Datepicker.prototype.isPopup = function() {
            return false;
        };
        return Datepicker;
    }
</script>