<style type="text/css" scoped>
</style>
<template>
    <div class="col-sm-12">
        <fieldset :disabled="rated || readOnly">
            <table class="table">
                <thead>
                    <tr class="row">
                        <th class="col-sm-12 col-md-7 col-lg-7 col-xl-7">COMPANY NAME</th>
                        <th class=" col-sm-12 col-md-4 col-lg-4 col-xl-4">COMPANY ROLE</th>
                        <th class="col-sm-12 col-md-1 col-lg-1 col-xl-1">DELETE</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="row" v-for="(row, index) in model.rows">
                        <td class="col-sm-12 col-md-7 col-lg-7 col-xl-7" v-model="row.companyName">
                            <typeahead :companyName="row.companyName" :companyId="row.companyId" @updateCompany="updateRow(row, $event)"></typeahead>
                        </td>
                        <td class=" col-sm-12 col-md-4 col-lg-4 col-xl-4" :class="{ 'has-danger': errors.has('companyRole'+ index) }">
                             <multiselect
                                id="companyRole"
                                :name="'companyRole' + index"
                                v-validate="required"
                                v-model="row.companyRoles"
                                :options="model.companyRole"
                                track-by="id"
                                label="desc"
                                :multiple="true"
                                @input="updateRoles($event, row)">
                            </multiselect>
                            <div v-show="errors.first('companyRole'+ index)" class="form-control-feedback">Select a company role.</div>
                        </td>
                        <td v-if="!rated && !readOnly" class="col-sm-12 col-md-1 col-lg-1 col-xl-1">
                            <i class="fa fa-times-circle" @click="removeRow(row, index)" aria-hidden="true"></i>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div v-if="!rated && !readOnly" class="btn btn-md btn-modal" @click="addRow">Add New Company</div>
        </fieldset>
    </div>
</template>
<script type="text/javascript">
    import Typeahead from '../fields/TypeAhead.vue';
    import Multiselect from 'vue-multiselect';
    export default {
        props: {
            model: Object
        },
        data() {
            return {
                newRow: {
                    companyId: "",
                    companyName: "",
                    companyRole: "",
                    companyRoleId: "",
                    companyRoles:[],
                    createdBy: "",
                    dealInfoId: "",
                },
                parties: []
            }
        },
        computed: {
            readOnly() {
                return this.$store.getters.isReadOnly;
            },
            rated() {
                return this.$store.getters.isRated;
            },
            required() {
                return this.$store.getters.required;
            },
            userId() {
                return this.$store.getters.getUserId;
            }
        },
        mounted() {
            this.$bus.$on('veeValidate', () => {
            this.$validator.validateAll();
                if (this.errors.items.length) {
                    this.$bus.$emit('field-errors', true);
                }
            });
        },
        methods: {
            updateRow(row, event){
                row.companyId = event.id;
                row.companyName = event.name;
                row.updatedBy = this.userId;
            },
            updateRoles(event, row) {
                row.updatedBy = this.userId;
            },
            addRow() {
                this.newRow.createdBy = this.userId;
                this.model.rows.push(Object.assign({}, this.newRow));
            },
            removeRow(row, index) {
                this.model.rows.splice(index, 1);
            },
        },
        components: {
            'typeahead' : Typeahead,
            'Multiselect': Multiselect
        }
    }
</script>