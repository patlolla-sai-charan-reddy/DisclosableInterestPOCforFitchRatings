<style type="text/css" scoped>
    input {
        background-color: transparent;
        width: 100%;
    }
</style>
<template>
    <!-- <input
    name="originalBalance"
    class="ag-cell"
    :class="{ 'class-invalid-field': missingBalance && dontSubmit }"
    type="text"
    :required="required"
    v-model="displayOriginalBalance"
    @focus="isInputActive = true"
    @blur="balanceInDealCurrency(currentRow.currencyId, currentRow.originalBalance, currentRow)"> -->
    <money
        :disabled="isRated"
        class="ag-cell money"
        :class="{ 'class-invalid-field': missingBalance && dontSubmit }"
        v-model="currentRow.originalBalance"
        v-bind="money"
        @blur.native="balanceInDealCurrency(currentRow.currencyId, currentRow.originalBalance, currentRow)">
    </money>
</template>

<script>
    import Vue from "vue";
    import { store } from '../../../utils/store/store';
    import {HTTP} from '../../../utils/calls';

    export default Vue.extend({
        data() {
            return {
                params: null,
                //currencyformat
                money: {
                    decimal: '.',
                    thousands: ',',
                    prefix: '',
                    suffix: '',
                    precision: 2,
                    masked: false
                },
              isInputActive: false
          }
        },
        computed: {
            formData() {
                return store.getters.getFormData;
            },
            isRated() {
                return store.getters.isRated;
            },
            required() {
                return store.getters.required;
            },
            currentRow() {
                return this.params.data;
            },
            missingBalance() { if (this.required && !this.currentRow.originalBalance) return true},
            dontSubmit() {
                return store.state.dontSubmitClass;
            },
            dealCurrency() {
                return store.getters.getDealCurrency;
            },
            displayOriginalBalance: {
                get() {
                    if (this.currentRow.originalBalance) {
                        if (this.isInputActive) {
                        // Cursor is inside the input field. unformat display value for user
                        return this.currentRow.originalBalance.toString()
                        } else {
                            // User is not modifying now. Format display value for user interface
                            return this.currentRow.originalBalance.toFixed(2).replace(/(\d)(?=(\d{3})+(?:\.\d+)?$)/g, "$1,")
                        }
                    }
                },
                set(modifiedValue) {
                    // Recalculate value after ignoring "$" and "," in user input
                    let newValue = parseFloat(modifiedValue.replace(/[^\d\.]/g, ""))
                    // Ensure that it is not NaN
                    if (isNaN(newValue)) {
                        newValue = ""
                    }
                    // Note: we cannot set this.value as it is a "prop". It needs to be passed to parent component
                    // $emit the event so that parent component gets it
                    this.currentRow.originalBalance = newValue
                }
            },
        },
        methods: {
            updateDropdown(event, row) {
                this.formData.classInfo[event.target.name].forEach((item) => {
                    if (item.id === row[event.target.name + 'Id']) {
                        row[event.target.name] = item.desc;
                    }
                });
                this.updateClassMeta(currentRow);
            },
            updateClassMeta(row) {
                row.updatedBy = row.classId ? this.userId : null;
            },
            balanceInDealCurrency(rowCurrency, rowBalance, row) {
                //for Original Balance
                this.isInputActive = false;
                if (this.dealCurrency && rowCurrency && rowBalance) {
                    HTTP.get('convertCurrency?from=' + rowCurrency + '&to=' + this.dealCurrency + '&amount=' + rowBalance)
                    .then(response => {
                        row.balanceInDealCurrency = response.data
                        store.commit('calculateBalances');
                        row.balanceInDealCurrency;
                        this.params.api.refreshCells();
                    })
                }
                this.updateClassMeta;
            },
        }
    });
</script>

<style scoped>
    .currency {
        color: blue;
    }
</style>