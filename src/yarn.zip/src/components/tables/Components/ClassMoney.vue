// create your cellRenderer as a VueJS component
<style type="text/css" scoped>
    .money {
        background-color: transparent;
    }
</style>
<template>
    <money
        :disabled="true"
        class="ag-cell money"
        v-model="currentRow.balanceInDealCurrency"
        v-bind="money">
    </money>
</template>

<script>
    import Vue from "vue";
    import { store } from '../../../utils/store/store';

    export default Vue.extend({
        data() {
            return {
                params: null,
                //currencyformat
                money: {
                    decimal: '.',
                    thousands: ',',
                    prefix: '',
                    suffix: '',
                    precision: 2,
                    masked: false
                }
          }
        },
        computed: {
            formData() {
                return store.getters.getFormData;
            },
            isRated() {
                return store.getters.isRated;
            },
            currentRow() {
                return this.params.data;
            }
        },
        methods: {
            updateClassMeta(row) {
                row.updatedBy = row.classId ? this.userId : null;
            }
        }
    });
</script>

<style scoped>
    .currency {
        color: blue;
    }
</style>