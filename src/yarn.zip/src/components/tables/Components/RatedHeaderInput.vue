<style type="text/css" scoped>
    .my-header {
        overflow: hidden;
        text-overflow: ellipsis;
    }
</style>
<template>
    <div class="my-header">
        <label class=""><span v-show="required" class="required-field"></span>{{ params.name }}</label>
    </div>
</template>

<script>
    import Vue from "vue";
    import { store } from '../../../utils/store/store';

    export default Vue.extend({
        data() {
            return {
              params: null,
          }
        },
        computed: {
            required() {
                return store.getters.required;
            },
        }
    });
</script>

<style scoped>
    .currency {
        color: blue;
    }
</style>