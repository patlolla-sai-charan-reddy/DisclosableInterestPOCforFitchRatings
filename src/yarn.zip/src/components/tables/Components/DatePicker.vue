// create your cellRenderer as a VueJS component
<style type="text/css">
.ag-pinned-left-cols-viewport .ag-row, .ag-pinned-left-cols-viewport .ag-cell {
    position: static;
}
</style>
<template>
    <date-picker
        :name="params.colDef.colId"
        :required="required"
        :disabled="isRated"
        :value="currentRow[params.colDef.colId]"
        :config="config"
        @dp-hide="updateDate($event, currentRow)">
    </date-picker>
</template>

<script>
    import Vue from "vue";
    import { store } from '../../../utils/store/store';

    export default Vue.extend({
        data() {
            return {
                params: null,
                required: "qwe"
            }
        },
        computed: {
            formData() {
                return store.getters.getFormData;
            },
            isRated() {
                return store.getters.isRated;
            },
            config() {
                return store.getters.getDatepickerConfig;
            },
            currentRow() {
                return this.params.data;
            }
        },
        methods: {
            updateDate(event, row) {
                const dateObj = {
                    object: row,
                    key: event.target.id,
                    value: event.target.value
                };
                store.commit('updateDate', dateObj);
                this.updateClassMeta(row);
            },
            updateClassMeta(row) {
                row.updatedBy = row.classId ? this.userId : null;
            }
        }
    });
</script>

<style scoped>
    .currency {
        color: blue;
    }
</style>