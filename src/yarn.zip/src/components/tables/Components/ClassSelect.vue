// create your cellRenderer as a VueJS component
<style type="text/css" scoped>
    select {
        background-color: transparent;
        width: 100%;
    }
</style>
<template>
    <select
        class="ag-cell"
        :class="{ 'class-invalid-field': missingField && dontSubmit }"
        :name="params.colDef.colId"
        :disabled="isRated"
        v-model="currentRow[params.colDef.colId + 'Id']"
        @change="updateDropdown($event, currentRow)">
        <option v-for="option in formData.classInfo[params.colDef.colId]" :value="option.id"> {{ option.desc }}</option>
    </select>
</template>

<script>
    import Vue from "vue";
    import { store } from '../../../utils/store/store';

    export default Vue.extend({
        data() {
            return {
              params: null,
          }
        },
        computed: {
            formData() {
                return store.getters.getFormData;
            },
            isRated() {
                return store.getters.isRated;
            },
            required() {
                return store.getters.required;
            },
            currentRow() {
                return this.params.data;
            },
            missingField() {
                var isMissing = false;
                var keys = Object.keys(this.currentRow);
                keys.forEach((item) => {
                    if (item === "registration" && item === this.params.colDef.colId && !this.currentRow[item + 'Id']) {
                        isMissing = true;
                    }
                    if (item === "jurisdiction" && item === this.params.colDef.colId && !this.currentRow[item + 'Id']) {
                        isMissing = true;
                    }
                });
                return isMissing;
            },
            dontSubmit() {
                return store.state.dontSubmitClass;
            }
        },
        methods: {
            updateDropdown(event, row) {
                this.formData.classInfo[event.target.name].forEach((item) => {
                    if (item.id === row[event.target.name + 'Id']) {
                        row[event.target.name] = item.desc;
                    }
                });
                this.updateClassMeta(this.currentRow);
            },
            updateClassMeta(row) {
                row.updatedBy = row.classId ? this.userId : null;
            }
        }
    });
</script>

<style scoped>
    .currency {
        color: blue;
    }
</style>