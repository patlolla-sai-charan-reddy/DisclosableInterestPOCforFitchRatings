// create your cellRenderer as a VueJS component
<style type="text/css">
    .my-checkbox {
        padding: 5px 12px;
    }
</style>
<template>
    <div class="my-checkbox">
        <label class="">
            <input
                class=""
                type="checkbox"
                :name="params.colDef.colId"
                v-model="currentRow[params.colDef.colId]"
                @change="checkboxChanged"/>
        </label>
    </div>
</template>

<script>
    import Vue from "vue";
    import { store } from '../../../utils/store/store';

    export default Vue.extend({
        data() {
            return {
              params: null
          }
        },
        computed: {
            formData() {
                return store.getters.getFormData;
            },
            isRated() {
                return store.getters.isRated;
            },
            currentRow() {
                return this.params.data;
            }
        },
        methods: {
            checkboxChanged(event) {
                store.commit('calculateBalances');
                this.updateClassMeta(this.currentRow);
            },
            updateClassMeta(row) {
                row.updatedBy = row.classId ? this.userId : null;
            }
        }
    });
</script>

<style scoped>
    .currency {
        color: blue;
    }
</style>