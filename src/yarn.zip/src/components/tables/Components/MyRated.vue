<style type="text/css" scoped>
    input {
        background-color: transparent;
        width: 100%;
    }
</style>
<template>
    <input
        :name="params.colDef.colId"
        class="ag-cell class-input"
        :class="{ 'class-invalid-field': missingField && dontSubmit }"
        type="text"
        placeholder="Enter value"
        :disabled="true"
        v-model="currentRow[params.colDef.colId]"
        @change="updateClassMeta(currentRow)">
</template>

<script>
    import Vue from "vue";
    import { store } from '../../../utils/store/store';
    export default Vue.extend({
        data() {
            return {
              params: null
          }
        },
        computed: {
            formData() {
                return store.getters.getFormData;
            },
            required() {
                return store.getters.required;
            },
            isRated() {
                return store.getters.isRated;
            },
            currentRow() {
                return this.params.data;
            },
            missingField() {
                var isMissing = false;
                var keys = Object.keys(this.currentRow);
                keys.forEach((item) => {
                    if (item === "name" && item === this.params.colDef.colId && !this.currentRow.name) {
                        isMissing = true;
                    }
                });
                return isMissing;
            },
            dontSubmit() {
                return store.state.dontSubmitClass;
            }
        },
        methods: {
            updateClassMeta(row) {
                row.updatedBy = row.classId ? this.userId : null;
            }
        }
    });
</script>