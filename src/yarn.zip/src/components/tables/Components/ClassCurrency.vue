// create your cellRenderer as a VueJS component
<style type="text/css" scoped>
    select {
        background-color: transparent;
        width: 100%;
    }
</style>
<template>
    <select
        class="ag-cell"
        :class="{ 'class-invalid-field': missingCurrency && dontSubmit }"
        name="currency"
        :disabled="isRated"
        v-model="currentRow.currencyId"
        @change="updateDropdown($event, currentRow)">
        <option v-for="option in formData.classInfo.currency" :value="option.id"> {{ option.desc }}</option>
    </select>
</template>

<script>
    import Vue from "vue";
    import { store } from '../../../utils/store/store';
    import {HTTP} from '../../../utils/calls';

    export default Vue.extend({
        data() {
            return {
                params: null
            }
        },
        computed: {
            formData() {
                return store.getters.getFormData;
            },
            isRated() {
                return store.getters.isRated;
            },
            required() {
                return store.getters.required;
            },
            currentRow() {
                return this.params.data;
            },
            missingCurrency() { if (this.required && !this.currentRow.currencyId) return true },
            dontSubmit() {
                return store.state.dontSubmitClass;
            },
            dealCurrency() {
                return store.getters.getDealCurrency;
            }
        },
        methods: {
            updateDropdown(event, row) {
                this.formData.classInfo[event.target.name].forEach((item) => {
                    if (item.id === row[event.target.name + 'Id']) {
                        row[event.target.name] = item.desc;
                    }
                });
                this.balanceInDealCurrency(row.currencyId, row.originalBalance, row);
            },
            balanceInDealCurrency(rowCurrency, rowBalance, row) {
                //for Original Balance
                if (this.dealCurrency && rowCurrency && rowBalance) {
                    HTTP.get('convertCurrency?from=' + rowCurrency + '&to=' + this.dealCurrency + '&amount=' + rowBalance)
                    .then(response => {
                        row.balanceInDealCurrency = response.data
                        store.commit('calculateBalances');
                        row.balanceInDealCurrency;
                        this.params.api.refreshCells();
                        //this.$forceUpdate();
                    })
                }
            }
        }
    });
</script>

<style scoped>
    .currency {
        color: blue;
    }
</style>