// create your cellRenderer as a VueJS component
<style type="text/css" scoped>
    .my-header {
        overflow: hidden;
        text-overflow: ellipsis;
    }
</style>
<template>
    <div class="my-header">
        <label class="">
            <input
                class=""
                type="checkbox"
                :name="params.column.colDef.colId"
                :value="truthy"
                :checked="checked"
                @change="checkboxChanged"/>
                {{ params.name }}
        </label>
    </div>
</template>

<script>
    import Vue from "vue";
    import { store } from '../../../utils/store/store';

    export default Vue.extend({
        data() {
            return {
              params: null,
              truthy: false,
              checked: false
          }
        },
        computed: {
            formData() {
                return store.getters.getFormData;
            },
            isRated() {
                return store.getters.isRated;
            },
            currentRow() {
                return this.params.data;
            }
        },
        mounted() {
            if(this.$store.getters.NonrowData.length !== 0 && this.$store.getters.NonrowData.every(el => el.checked === true)) {
                this.checked = !this.truthy
            } 
            if(this.$store.getters.rowData.length !== 0 && this.$store.getters.rowData.every(el => el.checked === true)) {
                this.checked = !this.truthy 
            }
        },
         methods: {
            checkboxChanged(event) {  
                if(this.params.flag === 'RatedDeals') {
                    this.truthy = !this.truthy;
                    this.checked = this.truthy;
                    this.$store.getters.rowData.forEach((row) => {       
                        row[this.params.column.colDef.colId] = this.truthy;
                    });
                } else if(this.params.flag === 'NotRatedDeals') {
                    this.truthy = !this.truthy;
                    this.checked = this.truthy;
                    this.$store.getters.NonrowData.forEach((row) => {       
                        row[this.params.column.colDef.colId] = this.truthy;
                    });
                } else {
                    this.truthy = !this.truthy;
                    this.checked = this.truthy;
                    this.formData.classInfo.rows.forEach((row) => {
                        if (row.hasOwnProperty(this.params.column.colDef.colId)) {
                            row[this.params.column.colDef.colId] = this.truthy;
                            store.commit('calculateBalances');
                        }
                    });
                }
            },
            updateClassMeta(row) {
                row.updatedBy = row.classId ? this.userId : null;
            }
        }
    });
</script>

<style scoped>
    .currency {
        color: blue;
    }
</style>