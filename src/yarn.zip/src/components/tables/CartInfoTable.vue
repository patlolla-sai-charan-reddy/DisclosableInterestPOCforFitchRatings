<style type="text/css" scoped>
    .table-container th, .table-container td {
        min-width: 125px;
    }
    ul.pagination {
        margin-top: 1rem;
        text-align: center;
    }

    /*Modal --*/
    .header-row {
        margin-bottom: 10px;
        padding: 10px;
    }
    .table-modal-body .row {
        border-bottom: 1px solid #CCC;
    }
    .table-modal-body .row > div, .table-modal-body .summary-row {
        padding: 10px 0;
    }
    .table-modal-body .summary-row {
        border-bottom: none;
    }
    p.key, p.value {
        margin-bottom: 0;
    }
    p.value {
        font-size: 0.9rem;
    }
    footer.modal-footer {
        display: block;
    }
    .modal-footer-button {
        cursor: pointer;
        color: #4F7580;
        font-weight: 700;
        font-size: 1.5rem;
    }
    .modal-footer-button:hover {
        color: #4D4D4D;
    }
</style>
<template>
    <div class="table-container">
        <table class="table">
            <thead>
                <tr>
                    <th>EXPAND</th>
                    <th>SERVICE TYPE/CART TYPE</th>
                    <th>SERVICE ID</th>
                    <th>SERVICE STATUS</th>
                    <th>CART ID</th>
                    <th>CART STATUS</th>
                </tr>
            </thead>
            <paginate
                        tag="tbody"
                        name="cartInfos"
                        ref="paginator"
                        :list="model"
                        :per="perPage">
                <tr v-for="(row, index) in paginated('cartInfos')" :key=" index">
                    <td>
                        <label class="col-form-label" @click="showModals(index)"><i class="fa fa-plus-square-o" aria-hidden="true"></i></label>
                    </td>
                    <td>
                        <label class="col-form-label"> {{ row.serviceType }}</label>
                    </td>
                    <td>
                        <label class="col-form-label"> {{ row.serviceId }}</label>
                    </td>
                    <td>
                        <label class="col-form-label"> {{ row.serviceStatus }}</label>
                    </td>
                    <td>
                        <label class="col-form-label"> {{ row.cartId }}</label>
                    </td>
                    <td>
                        <label class="col-form-label"> {{ row.cartStatus }}</label>
                    </td>
                </tr>
            </paginate>
        </table>
         <paginate-links
            for="cartInfos"
            :classes="{
                    'ul' : ['pagination', 'justify-content-center'],
                    'ul > li': 'page-item',
                    'ul > li > a': 'pagination-link'
                }"
            :limit="2"
            :hide-single-page="true"
            :show-step-links="true"
            @change="onLangsPageChange">
        </paginate-links>

        <!-- Table Modal -->
       <b-modal ref="myModalRef" size="lg">
            <div slot="modal-header">
                <div class="row header-row">
                    <div class="col-sm-10 col-md-10 col-lg-10">
                        <h5>{{ currentRow.serviceId }}</h5>
                    </div>
                    <div class="col-sm-2 col-md-2 col-lg-2">
                        <div class="btn btn-md btn-modal float-right" @click="hideModal">Close</div>
                    </div>
                </div>
            </div>
            <div class="table-modal-body">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-2 col-md-2 col-lg-2">
                            <p class="key">Cart Id</p>
                            <p class="value">{{ currentRow.cartId }}</p>
                        </div>
                        <div class="col-xs-2 col-md-2 col-lg-2">
                            <p class="key">Cart Status</p>
                            <p class="value">{{ currentRow.cartStatus }}</p>
                        </div>
                        <div class="col-xs-2 col-md-2 col-lg-2">
                            <p class="key">Created On</p>
                            <p class="value">{{ currentRow.createdOn }}</p>
                        </div>
                        <div class="col-xs-2 col-md-2 col-lg-2">
                            <p class="key">Cart Effective Date</p>
                            <p class="value">{{ currentRow.cartEffectiveDate }}</p>
                        </div>
                        <div class="col-xs-4 col-md-4 col-lg-4">
                            <p class="key">Cart Comments</p>
                            <p class="value">{{ currentRow.cartComments }}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-2 col-md-2 col-lg-2">
                            <p class="key">Service Id</p>
                            <p class="value">{{ currentRow.serviceId }}</p>
                        </div>
                        <div class="col-xs-2 col-md-2 col-lg-2">
                            <p class="key">Service Status</p>
                            <p class="value">{{ currentRow.serviceStatus }}</p>
                        </div>
                        <div class="col-xs-2 col-md-2 col-lg-2">
                            <p class="key">Service Type/Cart Type</p>
                            <p class="value">{{ currentRow.serviceType }}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-2 col-md-2 col-lg-2">
                            <p class="key">Committee Id</p>
                            <p class="value">{{ currentRow.committeeId }}</p>
                        </div>
                        <div class="col-xs-2 col-md-2 col-lg-2">
                            <p class="key">Committee Purpose</p>
                            <p class="value">{{ currentRow.committeePurpose }}</p>
                        </div>
                        <div class="col-xs-2 col-md-2 col-lg-2">
                            <p class="key">Committee Type</p>
                            <p class="value">{{ currentRow.committeeType }}</p>
                        </div>
                        <div class="col-xs-2 col-md-2 col-lg-2">
                            <p class="key">Committee Date</p>
                            <p class="value">{{ currentRow.committeeDate }}</p>
                        </div>
                        <div class="col-xs-4 col-md-4 col-lg-4">
                            <p class="key">Committee Comments</p>
                            <p class="value">{{ currentRow.comitteeComments }}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-2 col-md-2 col-lg-2">
                            <p class="key">Accouting</p>
                            <p class="value">{{ currentRow.accounting }}</p>
                        </div>
                        <div class="col-xs-2 col-md-2 col-lg-2">
                            <p class="key">Created By</p>
                            <p class="value">{{ currentRow.createdBy }}</p>
                        </div>
                        <div class="col-xs-2 col-md-2 col-lg-2">
                            <p class="key">Publishing</p>
                            <p class="value">{{ currentRow.publishing }}</p>
                        </div>
                    </div>
                    <div class="row summary-row">
                        <p class="key">Summary Reccomendations</p>
                        <p class="value">{{ currentRow.summaryRecommendation }}</p>
                    </div>
                </div>
            </div><!-- END TABLE EDIT MODAL -->
            <div slot="modal-footer" class="w-100">
                <div class="footer-container">
                    <div class="row justify-content-between">
                        <div class="col-4">
                            <div v-if="currentRowIndex !== 0" class="btn btn-lg btn-modal" @click="changeRow(previousRowIndex)">
                                Prev
                            </div>
                        </div>
                        <div v-if="currentRowIndex !== model.length - 1" class="col-4">
                            <div class="btn btn-lg btn-modal pull-right" @click="changeRow(nextRowIndex)">
                                Next
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </b-modal>
    </div>
</template>
<script type="text/javascript">
    export default {
        props: [
            'model'
        ],
        data() {
            return {
                //Modal Model and Pagination
                currentRow: {},
                currentRowIndex: 0,
                previousRowIndex: -1,
                nextRowIndex: 1,
                paginate: ['cartInfos'],
                perPage: 7,
                paginatePage: 0
            }
        },
        computed: {
        },
        watch: {
            currentRowIndex() {
                this.previousRowIndex = this.currentRowIndex - 1;
                this.nextRowIndex = this.currentRowIndex + 1;
            }
        },
        methods: {
            showModals(index) {
                this.currentRowIndex = index + this.perPage * this.paginatePage;
                this.currentRow = this.model[this.currentRowIndex];
                this.$refs.myModalRef.show();
            },
            onLangsPageChange(toPage, fromPage) {
                this.paginatePage = toPage - 1;
            },
            changeRow(index) {
                this.currentRow = this.model[index];
                this.currentRowIndex = index;
                /*if (isPrevious && index === 0) {
                    console.log("first index of the page", index);
                    this.$refs.paginator.goToPage(this.paginatePage - 1)
                } else if (!isPrevious && index === 0) {
                    console.log("last of the page", this.perPage);
                    this.$refs.paginator.goToPage(this.paginatePage + 1)
                }*/
            },
            hideModal() {
                this.$refs.myModalRef.hide();
            }
        },
        components: {
        }
    }
</script>