<style type="text/css" scoped>
    .main-info-fixed {
        position: fixed;
        right: 3px;
    }
</style>

<template>
    <div class="margin-top" :class="{ 'row': !newDeal }">
        <!-- Fieldset to hold disabled state in case of Rated Deal and Read Only user -->
        <div :class="{ 'col-8': !newDeal }">
            <fieldset
                :disabled="rated"
                :class="{ 'form-disabled': rated}">
                <!-- Deal Info -->
                <deal-info :formData="formData" />
                <!-- End Deal Info -->
                <!-- Issuer Info -->
                <issuer-info :formData="formData" />
                <!-- end Issuer Info -->
            </fieldset>
            <!--Rated Sections -->
            <div v-if="rated">
                <!-- 17g5 -->
                <seventeen :formData="formData" />
                <!-- End 17g5 -->
                <!-- 17g5 -->
                <analysts :analysts="formData.dealInfo.analysts" />
                <!-- End 17g5 -->
            </div>
            <!--End Rated Sections -->
            <fieldset
                :disabled="rated"
                :class="{ 'form-disabled': rated}">
                <div class="my-form">
                    <div>
                        <section-header heading="PARTIES TO THE DEAL" section="partiesToDeal"></section-header>
                    </div><!-- End Row -->
                    <parties-table
                        v-show="showPartiesToDeal"
                        :model="formData.partiesToDeal" />
                </div><!-- End Parties to the Deal -->
            </fieldset>
            <div class="my-form">
                <div>
                    <section-header heading="CLASS INFO" section="classInfo"></section-header>
                </div><!-- End Row -->
                <div v-show="showClassInfo">
                    <my-grid :dealCurrency="dealCurrency"
                        :model="formData.classInfo" :flag="showClassInfo">
                    </my-grid>
                    <balance-table :model="formData.classInfo" />
                </div>
            </div><!-- End Class Info -->
            <div v-if="rated" class="my-form">
                <div>
                    <section-header heading="CART INFO" section="cartInfo"></section-header>
                </div><!-- End Row -->
                <cart-info-table v-show="showCartInfo" :model="formData.dealInfo.cartInfos" />
            </div><!-- End Cart Info -->
            <deal-meta :formData="formData"/>
        </div>
        <!-- Main -->
        <div v-if="!newDeal" :class="{ 'col-4': !newDeal }" class="main-info-fixed">
            <main-info :formData="formData" />
        </div>
        <!-- Main -->
        <!-- Field Error Modal -->
        <modal :modal="fieldErrors"></modal>
        <!-- Success Modal -->
        <modal :modal="success"></modal>
        <!-- API Error Modal -->
        <modal :modal="apiError"></modal>
    </div><!-- End Form -->
</template>

<script>
    //sections
    import MainInfo from './sections/MainInfo.vue';
    import IssuerInfo from './sections/IssuerInfo.vue';
    import DealInfo from './sections/DealInfo.vue';
    import Seventeeng5 from './sections/Seventeeng5.vue';
    import Analysts from './sections/Analysts.vue';
    import DealMeta from './sections/DealMeta.vue';

    export default {
        props: {
            formData: {
                type: Object,
                required: true
              }
        },
        data() {
            return {
            }
        },
        computed: {
            newDeal() {
                return this.$store.getters.isNewDeal;
            },
            rated() {
                return this.$store.getters.isRated;
            },
            showPartiesToDeal() {
                return this.$store.getters.showSection('partiesToDeal');
            },
            showClassInfo() {
                return this.$store.getters.showSection('classInfo');
            },
            showCartInfo() {
                return this.$store.getters.showSection('cartInfo');
            },
            fieldErrors() {
                return this.$store.getters.getModal('fieldErrors');
            },
            success() {
                return this.$store.getters.getModal('success');
            },
            apiError() {
                return this.$store.getters.getModal('apiError');
            },
            dealCurrency() {
                return this.$store.getters.getDealCurrency;
            }
        },
        methods: {
        },
        components: {
            'main-info': MainInfo,
            'issuer-info': IssuerInfo,
            'deal-info': DealInfo,
            'seventeen': Seventeeng5,
            'analysts': Analysts,
            'deal-meta': DealMeta,
        }
    }
</script>