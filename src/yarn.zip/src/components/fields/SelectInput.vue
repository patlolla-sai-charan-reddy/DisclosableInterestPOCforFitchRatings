<style type="text/css" scoped>
    select {
        color: #11175e;
        font-size: 0.8rem;
        font-family: "Roboto", sans-serif;
    }
</style>
<template>
    <div class="form-group col-sm-6 style-fix-labels" :class="{ 'has-danger': errors.has('elementId') }">
        <label :for="elementId" class="col-form-label key">{{ placeholder }}</label>
        <span v-if="required" class="required-field">*</span>
        <select
            class="form-control"
            :class="{'input': true, 'form-control-danger': errors.has('elementId') }"
            key="elementId"
            name="elementId"
            :id="elementId"
            v-validate="required"
            data-vv-validate-on="blur"
            @input="changeModelValue">
            <option :value="model" selected disabled hidden>{{ initialValue }}</option>
            <option v-for="option in options" :value="option.id"> {{ option.desc }}</option>
        </select>
        <div v-show="errors.first('elementId')" class="form-control-feedback">This field is required.</div>
    </div>
</template>
<script type="text/javascript">
    export default {
        props: [
            'placeholder',
            'elementId',
            'required',
            'initialValue',
            'model',
            'options'
        ],
        data() {
            return {
            }
        },
        mounted() {
              this.$bus.$on('veeValidate', () => {
                this.$validator.validateAll();
                    if (this.errors.items.length) {
                        this.$bus.$emit('field-errors', true);
                    }
              });
        },
        methods: {
            changeModelValue (event) {
                this.$emit('modelChanged', event);
            }
        },
        components: {
        }
    }
</script>