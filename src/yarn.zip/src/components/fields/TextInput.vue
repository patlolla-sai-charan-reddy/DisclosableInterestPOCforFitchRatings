<template>
    <div class="col-sm-6" :class="{ 'has-danger': errors.has('model') }">
        <label :for="model" class="key col-form-label">{{ placeholder }}</label>
        <span v-if="required" class="required-field">*</span>
        <input
            class="form-control"
            :class="{'input': true, 'form-control-danger': errors.has('model') }"
            type="text"
            key="model"
            name="model"
            v-validate="required"
            :disabled="disabled == 1 ? true : false"
            :value="model"
            @input="changeValue" />
        <div v-show="errors.first('model')" class="form-control-feedback">This field is required.</div>
    </div>
</template>
<script type="text/javascript">
    export default {
         props: {
              placeholder: {
                type: String,
                required: true
              },
              required: {
                type: String
              },
              disabled: {
                type: String
              },
              model: null
        },
        data() {
            return {
            }
        },
        mounted() {
              this.$bus.$on('veeValidate', () => {
                this.$validator.validateAll();
                if (this.errors.has('model')) {
                    this.$bus.$emit('field-errors', true);
                }
              });
        },
        methods: {
            changeValue (event) {
                this.$emit('modelChanged', event.target.value);
            }
        },
        components: {
        }
    }
</script>