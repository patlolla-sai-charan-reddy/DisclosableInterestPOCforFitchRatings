<style type="text/css" scoped>
    .input-error {
        color: #ff3860;
    }
    i.fa-warning {
        position: relative;
        top: -26px;
        right: 10px;
        opacity: 1;
        font-size: 1rem;
    }
    span.input-error {
        display: inline-block;
    }
</style>
<template>
    <div class="has-icon-right" :class="{ 'has-danger': errors.has('companyName') }">
        <input
            type="text"
            class="form-control"
            :class="{'input': true, 'form-control-danger': errors.has('companyName') }"
            autocomplete="off"
            name="companyName"
            key="companyName"
            v-validate="required"
            v-model="companyName"
            @keydown.down="down"
            @keydown.up="up"
            @keydown.enter="hit"
            @keydown.esc="myReset"
            @blur="myReset"
            @input="myUpdate"/>
        <ul v-show="hasItems">
            <li v-for="(item, $item) in items" :class="activeClass($item)" @mousedown="hit"
                @mousemove="setActive($item)">
                <span class="name" v-text="item.name"></span>
                <span class="screen-name" v-text="item.screen_name"></span>
            </li>
        </ul>
        <span v-show="errors.first('companyName')" class="form-control-feedback">Enter a company name.</span>
    </div>
</template>

<script>
    import VueTypeahead from 'vue-typeahead';
    export default {
        extends: VueTypeahead,
        props: {
            companyName: String
        },
      data () {
          return {
              src: 'companies',
              queryParamName: 'companyName',
              //querySearch: this.companyName,
              minChars: 2,
              didClick: true
          }
      },
      computed: {
          querySearch() {
              if (this.companyName !== undefined) {
                  return this.companyName;
              }
          },
          required() {
              return this.$store.getters.required;
          }
      },
      mounted() {
          this.$bus.$on('veeValidate', () => {
          this.$validator.validateAll();
              if (this.errors.items.length) {
                  this.$bus.$emit('field-errors', true);
              }
          });
      },
      methods: {
        // The callback function which is triggered when the user hits on an item
        // (required)
        onHit (item, event) {
            this.companyName = item.name;
            this.didClick = true;
            this.query = item.name;
            this.$emit('updateCompany', item);
        },
        myReset() {
            if (!this.didClick) {
                this.companyName = "";
            }
            this.reset();
        },
        myUpdate() {
            this.didClick = false;
            this.query =  this.companyName;
            this.update();
        }
      }
    };
</script>

<style scoped>
    .Typeahead {
        position: relative;
    }

    .Typeahead__input {
        width: 100%;
        font-size: 14px;
        color: #2c3e50;
        line-height: 1.42857143;
        box-shadow: inset 0 1px 4px rgba(0, 0, 0, .4);
        -webkit-transition: border-color ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;
        transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
        font-weight: 300;
        padding: 12px 26px;
        border: none;
        border-radius: 22px;
        letter-spacing: 1px;
        box-sizing: border-box;
    }

    .Typeahead__input:focus {
        border-color: #4fc08d;
        outline: 0;
        box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 8px #4fc08d;
    }

    .fa-times {
        cursor: pointer;
    }

    i {
        float: right;
        position: relative;
        top: 30px;
        right: 29px;
        opacity: 0.4;
    }

    ul {
        position: absolute;
        padding: 0;
        margin-top: 8px;
        min-width: 100%;
        background-color: #fff;
        list-style: none;
        border-radius: 4px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.25);
        z-index: 1000;
    }

    li {
        padding: 10px 16px;
        border-bottom: 1px solid #ccc;
        cursor: pointer;
    }

    li:first-child {
        border-top-left-radius: 4px;
        border-top-right-radius: 4px;
    }

    li:last-child {
        border-bottom-left-radius: 4px;
        border-bottom-right-radius: 4px;
        border-bottom: 0;
    }

    span {
        display: block;
        color: #2c3e50;
    }

    .active {
        background-color: #3aa373;
    }

    .active span {
        color: white;
    }

    .name {
        font-weight: 700;
        font-size: 18px;
    }

    .screen-name {
        font-style: italic;
    }
</style>