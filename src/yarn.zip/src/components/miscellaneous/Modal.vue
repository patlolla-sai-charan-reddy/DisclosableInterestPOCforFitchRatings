<template>
    <b-modal class="notification-modal" v-model="modal.show" :title="modal.title">
        <div class="d-block text-center">
            <h6>{{ modal.message }}</h6>
        </div>
        <div slot="modal-footer">
            <b-btn class="btn-modal" block @click="closeModal">Close</b-btn>
        </div>
    </b-modal>
</template>
<script type="text/javascript">
    export default {
        props: [
            'modal'
        ],
        data() {
            return {

            }
        },
        methods: {
            closeModal() {
                this.$store.commit('hideModal', this.modal.modalRef);
            }
        }
    }
</script>