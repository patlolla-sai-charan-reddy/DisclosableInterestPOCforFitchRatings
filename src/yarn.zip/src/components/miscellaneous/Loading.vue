<template>
    <div class="my-form erros margin-top">
        <p><i class="fa fa-circle-o-notch fa-spin fa-3x fa-fw"></i> Loading...</p>
    </div>
</template>