<template>
    <div class="clearfix">
        <div
            class="home-container"
            :class="{ 'col-4 pull-right': deal}">
            <div
                class="wrapper"
                :class="{ 'on-new-deal': !deal }">
                <a href="/home" class="button">Home</a>
            </div>
        </div>
    </div>
</template>
<style lang="scss">
    $color: #4dccbd;

    @keyframes sheen {
        0% {
            transform: skewY(-45deg) translateX(0);
        }
        100% {
            transform: skewY(-45deg) translateX(12.5em);
        }
    }
    .home-container {
        margin-top: 12px;
        height: 55px;
        text-align: center;
        padding-left: 15px;
        z-index: 9999;
    }
    .on-new-deal {
        left: 50%;
        margin-left: -63px;
        z-index: 1;
    }
    .wrapper {
        display: block;
        position: fixed;
    }
    .wrapper > a {
        text-decoration: none;
    }
    .button {
        padding: 0.75em 2em;
        text-align: center;
        text-decoration: none;
        color: $color;
        background-color: #F5F5F5;
        cursor: pointer;
        font-size: 18px;
        font-weight: 600;
        display: inline-block;
        border-radius: 0.3em;
        transition: all 0.2s ease-in-out;
        position: relative;
        overflow: hidden;
        &:before {
            content: "";
            background-color: rgba(255,255,255,0.5);
            height: 100%;
            width: 3em;
            display: block;
            position: absolute;
            top: 0;
            left: -4.5em;
            transform: skewX(-45deg) translateX(0);
            transition: none;
      }
        &:hover {
            background-color: $color;
            color: #fff;
            border-bottom: 4px solid darken($color, 10%);
            &:before {
                    transform: skewX(-45deg) translateX(13.5em);
                    transition: all 0.5s ease-in-out;
                }
        }
    }
</style>
<script type="text/javascript">
    export default {
        data() {
            return {

            }
        },
        computed: {
            deal() {
                if(this.$route.name === "BulkEntry" || this.$route.name === "rated" || this.$route.name === "nonrated" || this.$route.name === "DealsSearch") {
                    return false;
                }
                return this.$route.name !== "newDeal";
            },
        }
    }
</script>