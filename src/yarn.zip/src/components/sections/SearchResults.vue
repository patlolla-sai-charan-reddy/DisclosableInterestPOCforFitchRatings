<style type="text/css" scoped>
    .search-results-row, .search-results-row > label {
        cursor: pointer;
    }
    tr.search-results-row:hover {
        background-color: rgba(204, 204, 204, 0.5); /*#CCC*/
    }
</style>
<template>
    <div>
        <v-client-table
            :data="results"
            :columns="columns2"
            :options="options"
            @row-click="navigate"
            @limit="storeLimit"
            @pagination="storePageNumber"
            ref="searchResultsTable">
                <span slot="dealId" slot-scope="props">{{ props.row.dealId }}</span>
                <span slot="dealName" slot-scope="props">{{ formattedName(props.row) }}</span>
                <span slot="dealStatus" slot-scope="props">{{ props.row.dealStatus }}</span>
                <span slot="closingDate" slot-scope="props">{{ formattedDate(props.row.closingDate) }}</span>
                <span slot="includeInReport" slot-scope="props">{{ formattedStatus(props.row.includeInReport) }}</span>
        </v-client-table>
        <div v-if="!results.length">
            <h6>No Deal found.</h6>
        </div>
    </div>
</template>
<script type="text/javascript">
    export default {
        props: [
            'results'
        ],
        data() {
            return {
                columns: [
                    {
                      label: 'Deal ID',
                      field: 'dealId',
                      type: 'number',
                    },
                    {
                      label: 'Deal Name / Working Name',
                      field: 'dealName'
                    },
                    {
                      label: 'Deal Status',
                      field: 'dealStatus'
                    },
                    {
                        label: 'Closing Date',
                        field: 'closingDate',
                        type: 'date',
                        inputFormat: 'YYYY-MM-DD',
                        outputFormat: 'DD-MMM-YYYY',
                    },
                    {
                        label: 'Entity Status',
                        field: 'includeInReport'
                    }
                ],
                columns2: ['dealId', 'dealName', 'dealStatus', 'closingDate', 'includeInReport'],
                options: {
                    skin: 'table-bordered',
                    headings: {
                        dealId: 'Deal ID',
                        dealName: 'Deal Name',
                        dealStatus: 'Deal Status',
                        closingDate: 'Closing Date',
                        includeInReport: 'Entity Status'
                    },
                    filterable: false,
                    orderBy: {
                        column: 'closingDate',
                        ascending: false
                    },
                    sortIcon: {
                        base:'fa',
                        up:'fa-caret-up',
                        down:'fa-caret-down',
                        is:''
                    }
                    //sortable: ['dealId', 'dealName', 'dealStatus', 'closingDate', 'includeInReport']
                }
            }
        },
        computed: {
            recordsPerPage() {
                return this.$store.getters.getSearchPageLimit;
            },
            pageNumber() {
                return this.$store.getters.getSearchPageNumber;
            }
        },
        mounted() {
            if (this.pageNumber) {
                this.$refs.searchResultsTable.setLimit(this.recordsPerPage);
                this.$refs.searchResultsTable.setPage(this.pageNumber);
            }
        },
        watch: {
            pageNumber() {
                this.$refs.searchResultsTable.setPage(this.pageNumber);
            }
        },
        methods: {
            formattedDate(value) {
                if (value) {
                    return value;
                }
            },
            formattedStatus (value) {
                return value = value ? "Active" : "Inactive";
            },
            formattedName (row) {
                if (row.dealName === row.workingName) {
                    return row.dealName;
                } else if (row.workingName) {
                    return row.dealName + " / " + row.workingName;
                } else {
                    return row.dealName;
                }
            },
            navigate(event) {
                this.$router.push({ path: '/deals/' + event.row.dealId })
            },
            storePageNumber(event) {
                this.$store.commit('storeSearchPageNumer', event);
            },
            storeLimit(event) {
                this.$store.commit('storeSearchPageLimit', event);
            },
            goToPage() {
                this.$refs.searchResultsTable.setPage(4);
            }
        }
    }
</script>