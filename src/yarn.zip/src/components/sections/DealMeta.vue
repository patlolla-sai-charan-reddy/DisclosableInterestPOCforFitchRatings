<template>
    <div class="my-form">
        <div>
            <section-header heading="DEAL METADATA" section="dealMeta"></section-header>
        </div><!-- End Row -->
        <div v-show="showSection" class="section-body">
            <div class="form-group row">
                <label class="col-form-label col-sm-2 key">Created By:</label>
                <label class="col-form-label col-sm-4" id="issuingEntity">{{ formData.dealInfo.createdBy }}</label>
                <label class="col-form-label col-sm-2 key">Created Date:</label>
                <label class="col-form-label col-sm-4" id="issuerId">{{ formattedDate(formData.dealInfo.createdTimestamp) }}</label>
            </div><!-- End Row -->
            <div class="form-group row">
                <label class="col-form-label col-sm-2 key">Updated By:</label>
                <label class="col-form-label col-sm-4" id="issuingEntity">{{ formData.dealInfo.updatedBy }}</label>
                <label class="col-form-label col-sm-2 key">Updated Date:</label>
                <label class="col-form-label col-sm-4" id="issuerId">{{ formattedDate(formData.dealInfo.updatedTimestamp) }}</label>
            </div><!-- End Row -->
            <div class="form-group row">
                <label class="col-form-label col-sm-2 key">Created By GWC:</label>
                <label class="col-form-label col-sm-4" id="issuingEntity">{{ formData.dealInfo.createdByGWC }}</label>
                <label class="col-form-label col-sm-2 key">Created Date GWC:</label>
                <label class="col-form-label col-sm-4" id="issuerId">{{ formattedDate(formData.dealInfo.createdTimestampGWC) }}</label>
            </div><!-- End Row -->
            <div class="form-group row">
                <label class="col-form-label col-sm-2 key">Updated By GWC:</label>
                <label class="col-form-label col-sm-4" id="issuingEntity">{{ formData.dealInfo.updatedByGWC }}</label>
                <label class="col-form-label col-sm-2 key">Updated Date GWC:</label>
                <label class="col-form-label col-sm-4" id="issuerId">{{ formattedDate(formData.dealInfo.updatedTimestampGWC) }}</label>
            </div><!-- End Row -->
        </div>
    </div><!-- End Deal Meta -->
</template>
<script type="text/javascript">
    export default {
        props: [
            'formData'
        ],
        data() {
            return {
            }
        },
        computed: {
            showSection() {
                return this.$store.getters.showSection('dealMeta');
            }
        },
        methods: {
            formattedDate(date) {
                if (date) {
                    return this.$moment(date).format('DD-MMM-YYYY');
                }
            }
        },
        components: {
        }
    }
</script>