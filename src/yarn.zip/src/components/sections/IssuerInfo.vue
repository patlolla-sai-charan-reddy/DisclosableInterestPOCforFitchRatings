<template>
    <div class="my-form">
        <div>
            <section-header heading="ISSUER INFO" section="issuerInfo"></section-header>
        </div><!-- End Row -->
        <div v-show="showSection" class="section-body">
        <fieldset disabled>
            <div class="form-group row">
                <my-text-input
                    placeholder="ISSUING ENTITY"
                    required=""
                    :model="formData.dealInfo.issuerName"
                    @modelChanged="formData.dealInfo.issuerName=$event" />
                <my-text-input
                    placeholder="ISSUER ID"
                    required=""
                    :model="formData.dealInfo.issuerId"
                    @modelChanged="formData.dealInfo.issuerId=$event" />
                <span v-show="errors.has('custom')" class="help is-danger">{{ errors.first('custom') }}</span>
            </div><!-- End Row -->
            <div class="form-group row">
                <my-select-input
                    placeholder="ISSUING ENTITY INCORPORATED IN"
                    elementId="issuerEntityCountry"
                    required=""
                    :initialValue="formData.dealInfo.issuerEntityCountry"
                    :model="formData.dealInfo.issuerEntityCountryId"
                    :options="formData.lookUpDetails.issuerEntityCountry"
                    @modelChanged="updateDropdown" />
                <my-text-input
                    placeholder="AGENT ID"
                    required=""
                    :model="formData.dealInfo.agentId"
                    @modelChanged="formData.dealInfo.agentId=$event" />
            </div><!-- End Row -->
        </fieldset>
        </div>

    </div><!-- end General Info -->
</template>
<script type="text/javascript">
    export default {
        props: [
            'formData'
        ],
        data() {
            return {

            }
        },
        computed: {
            showSection() {
                return this.$store.getters.showSection('issuerInfo');
            },
            required() {
                return this.$store.getters.required;
            }
        },
        methods: {
            updateDropdown() {
                this.$store.commit('updateDropdown', event);
            }
        },
        components: {
        }
    }
</script>