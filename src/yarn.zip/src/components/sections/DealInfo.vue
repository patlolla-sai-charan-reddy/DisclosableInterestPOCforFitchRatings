<style type="text/css" scoped>
</style>
<template>
    <div class="my-form">
        <div>
            <section-header heading="Deal Info" section="dealInfo"></section-header>
        </div><!-- End Row -->
        <div v-show="showSection" class="section-body">
            <div class="form-group row">
                <my-text-input
                    placeholder="DEAL NAME"
                    :required="required"
                    :model="formData.dealInfo.dealName"
                    @modelChanged="formData.dealInfo.dealName=$event" />

                <my-text-input
                    placeholder="DEAL ID"
                    required=""
                    disabled="1"
                    :model="formData.dealInfo.dealId"
                    @modelChanged="formData.dealInfo.dealId=$event" />
            </div><!-- End Row -->
            <div class="form-group row">
                <my-text-input
                    placeholder="WORKING NAME"
                    required=""
                    :model="formData.dealInfo.workingName"
                    @modelChanged="formData.dealInfo.workingName=$event" />
                <my-text-input
                    placeholder="DEAL STATUS"
                    required=""
                    disabled="1"
                    :model="formData.dealInfo.dealStatus"
                    @modelChanged="formData.dealInfo.dealStatus=$event" />
            </div><!-- End Row -->
            <div class="form-group row">
                <my-select-input
                    placeholder="MANAGEMENT LINE REGION"
                    elementId="managementLineRegion"
                    :required="required"
                    :initialValue="formData.dealInfo.managementLineRegion"
                    :model="formData.dealInfo.managementLineRegionId"
                    :options="formData.lookUpDetails.managementLineRegion"
                    @modelChanged="updateDropdown" />
                <my-select-input
                    placeholder="MANAGEMENT LINE"
                    elementId="managementLine"
                    :required="required"
                    :initialValue="formData.dealInfo.managementLine"
                    :model="formData.dealInfo.managementLineId"
                    :options="formData.lookUpDetails.managementLine"
                    @modelChanged="updateDropdown" />
            </div><!-- End Row -->
            <div class="form-group row">
                <my-select-input
                    placeholder="DEAL ISSUANCE CURRENCY"
                    elementId="dealIssuanceCurrency"
                    :required="required"
                    :initialValue="formData.dealInfo.dealIssuanceCurrency"
                    :model="formData.dealInfo.dealIssuanceCurrencyId"
                    :options="formData.lookUpDetails.dealIssuanceCurrency"
                    @modelChanged="updateDropdown" />
                <my-select-input
                    placeholder="MARKET SECTOR NAME"
                    elementId="marketSectorName"
                    :required="required"
                    :initialValue="formData.dealInfo.marketSectorName"
                    :model="formData.dealInfo.marketSectorNameId"
                    :options="marketSectorList"
                    @modelChanged="updateDropdown" />
            </div><!-- End Row -->
            <div class="form-group row">
                 <div class="col-sm-6" :class="{ 'has-danger': missingDealSize && dontSubmit }">
                    <label for="model" class="key">DEAL SIZE</label>
                    <span v-if="required" class="required-field">*</span>
                    <money
                        class="form-control form-control-danger"
                        name="dealSize"
                        v-model="formData.dealInfo.dealSize"
                        v-bind="money">
                    </money>
                    <div v-show="missingDealSize && dontSubmit" class="form-control-feedback">Deal Size should be greater than 0.</div>
                </div>
                <div class="col-sm-6">
                    <label for="model" class="key">FITCH RATED AMOUNT</label>
                    <money
                        class="form-control"
                        :class="{'input': true }"
                        v-model="formData.dealInfo.fitchRatedAmount"
                        v-bind="money">
                    </money>
                </div>
            </div><!-- End Row -->
            <div class="form-group row">
                <div class="form-group col-sm-6">
                    <label for="preSaleDate" class="key">LEGAL MATURITY DATE</label>
                    <date-picker
                        id="legalMaturityDate"
                        :value="formData.dealInfo.legalMaturityDate"
                        :config="config"
                        @dp-hide="updateDate">
                    </date-picker>
                </div>

                <div class="form-group col-sm-6 style-fix-labels">
                    <label for="formGroupExampleInput" class="key">ACTUAL MATURITY DATE</label>
                    <date-picker
                        id="actualMaturityDate"
                        :value="formData.dealInfo.actualMaturityDate"
                        :config="config"
                        @dp-hide="updateDate">
                    </date-picker>
                </div>
            </div><!-- End Row -->
            <div class="form-group row">
                <my-select-input
                    placeholder="COUNTRY OF ASSETS"
                    elementId="countryOfAssets"
                    :required="required"
                    :initialValue="formData.dealInfo.countryOfAssets"
                    :model="formData.dealInfo.countryOfAssetsId"
                    :options="formData.lookUpDetails.countryOfAssets"
                    @modelChanged="updateDropdown" />
                <my-select-input
                    placeholder="REPORTING OFFICE"
                    elementId="reportingOffice"
                    required=""
                    :initialValue="formData.dealInfo.reportingOffice"
                    :model="formData.dealInfo.reportingOfficeId"
                    :options="formData.lookUpDetails.reportingOffice"
                    @modelChanged="updateDropdown" />

            </div><!-- End Row -->
            <div class="form-group row row-margin-fix">
                <my-select-input
                    placeholder="DEAL STRUCTURE"
                    elementId="dealStructure"
                    required=""
                    :initialValue="formData.dealInfo.dealStructure"
                    :model="formData.dealInfo.dealStructureId"
                    :options="formData.lookUpDetails.dealStructure"
                    @modelChanged="updateDropdown" />
                <my-select-input
                    placeholder="PURPOSE"
                    elementId="purpose"
                    required=""
                    :initialValue="formData.dealInfo.purpose"
                    :model="formData.dealInfo.purposeId"
                    :options="formData.lookUpDetails.purpose"
                    @modelChanged="updateDropdown" />
            </div><!-- End Row -->
            <div class="form-group row row-margin-fix">
                <my-select-input
                    placeholder="COLLATERAL TYPE"
                    elementId="collateralType"
                    required=""
                    :initialValue="formData.dealInfo.collateralType"
                    :model="formData.dealInfo.collateralTypeId"
                    :options="formData.lookUpDetails.collateralType"
                    @modelChanged="updateDropdown" />
                <my-select-input
                    placeholder="PORTFOLIO TYPE"
                    elementId="portfolioType"
                    required=""
                    :initialValue="formData.dealInfo.portfolioType"
                    :model="formData.dealInfo.portfolioTypeId"
                    :options="formData.lookUpDetails.portfolioType"
                    @modelChanged="updateDropdown" />
            </div><!-- End Row -->
            <div class="form-group row row-margin-fix">
                <div class="col-sm-6">
                    <label for="maxEndOfRevolvingPeriod" class="key">MAX END OF REVOLVING PERIOD (Years)</label>
                    <input class="form-control" :class="{'input': true }" type="number" id="maxEndOfRevolvingPeriod" v-model="formData.dealInfo.maxEndOfRevolvingPeriod"/>
                </div>
                <div class="form-group col-sm-6">
                    <label for="endOfRevolvingPeriod" class="key">END OF REVOLVING PERIOD (DD MM YYYY)</label>
                    <date-picker
                        id="endOfRevolvingPeriod"
                        :value="formData.dealInfo.endOfRevolvingPeriod"
                        :config="config"
                        @dp-hide="updateDate">
                    </date-picker>
                </div>
            </div><!-- End Row -->
            <div class="form-group row row-margin-fix">
                <div class="form-group col-sm-6">
                    <label for="preSalePublishedDate" class="key">PRE-SALE PUBLISHED DATE</label>
                    <date-picker
                        id="preSalePublishedDate"
                        :value="formData.dealInfo.preSalePublishedDate"
                        :config="config"
                        @dp-hide="updateDate">
                    </date-picker>
                </div>
                <my-select-input
                    placeholder="REASON PRE-SALE NOT PUBLISHED"
                    elementId="reasonPreSaleNotPublished"
                    required=""
                    :initialValue="formData.dealInfo.reasonPreSaleNotPublished"
                    :model="formData.dealInfo.reasonPreSaleNotPublishedId"
                    :options="formData.lookUpDetails.reasonPreSaleNotPublished"
                    @modelChanged="updateDropdown" />
            </div><!-- End Row -->
            <div class="form-group row row-margin-fix">
                <div class="form-group col-sm-6" :class="{ 'has-danger': missingClosingDate && dontSubmit }">
                    <label for="closingDate" class="key">CLOSING DATE</label>
                    <span v-if="required" class="required-field">*</span>
                    <date-picker
                        id="closingDate"
                        :value="formData.dealInfo.closingDate"
                        :required="required"
                        v-validate="required"
                        :config="config"
                        @dp-hide="updateDate">
                    </date-picker>
                    <div v-show="missingClosingDate && dontSubmit" class="form-control-feedback">Closing Date is a required field.</div>
                </div>
                <div class="form-group col-sm-6">
                    <label for="preSaleDate" class="key">FIRST PAYMENT DATE</label>
                    <date-picker
                        id="firstPaymentDate"
                        :value="formData.dealInfo.firstPaymentDate"
                        :config="config"
                        @dp-hide="updateDate">
                    </date-picker>
                </div>
            </div><!-- End Row -->
            <div class="form-group row row-margin-fix text-bold">
                <div class="form-check form-check-inline col-sm-6">
                    <label class="form-check-label">
                        <input
                            class="form-check-input"
                            type="checkbox"
                            name="requiresSurveillance"
                            id=""
                            v-model="formData.dealInfo.requiresSurveillance"/>
                        REQUIRES SURVEILLANCE:
                    </label>
                </div>
                <div class="form-check form-check-inline multi-deal">
                    <label class="form-check-label">
                        <input
                            class="form-check-input"
                            type="checkbox"
                            name="multiOriginatorDeal"
                            id=""
                            v-model="formData.dealInfo.multiOriginatorDeal" />
                        MULTI-ORIGINATOR DEAL:
                    </label>
                </div>
            </div><!-- End Row -->
            <div class="form-group row">
                <div class="col-sm-6">
                    <label for="rampUpClosing" class="key">RAMP UP CLOSING %</label>
                    <input class="form-control" :class="{'input': true }" type="number" id="rampUpClosing" v-model="formData.dealInfo.rampUpClosing"/>
                </div>
                <div class="form-group col-sm-6">
                    <label for="preSaleDate" class="key">LAUNCH DATE</label>
                    <date-picker
                        id="launchDate"
                        :value="formData.dealInfo.launchDate"
                        :config="config"
                        @dp-hide="updateDate">
                    </date-picker>
                </div>
            </div><!-- End Row -->
            <div class="form-group row">
                <my-text-input
                    placeholder="SERIES"
                    required=""
                    :model="formData.dealInfo.series"
                    @modelChanged="formData.dealInfo.series=$event" />
                <my-select-input
                    placeholder="Registration"
                    elementId="registration"
                    required=""
                    :initialValue="formData.dealInfo.registration"
                    :model="formData.dealInfo.registrationId"
                    :options="formData.lookUpDetails.registration"
                    @modelChanged="updateDropdown" />
            </div><!-- End Row -->
            <div class="form-group row">
                <my-select-input
                    placeholder="REASON NOT RATED"
                    elementId="reasonNotRated"
                    required=""
                    :initialValue="formData.dealInfo.reasonNotRated"
                    :model="formData.dealInfo.reasonNotRatedId"
                    :options="formData.lookUpDetails.reasonNotRated"
                    @modelChanged="updateDropdown" />
                <div class="form-group col-sm-6" :class="{ 'has-danger': missingPricingDate && dontSubmit }">
                    <label for="pricingDate" class="key col-form-label">PRICING DATE</label>
                    <span v-if="required" class="required-field">*</span>
                    <date-picker
                        id="pricingDate"
                        :value="formData.dealInfo.pricingDate"
                        :required="required"
                        v-validate="required"
                        :config="config"
                        @dp-hide="updateDate">
                    </date-picker>
                    <div v-show="missingPricingDate && dontSubmit" class="form-control-feedback">Pricing Date is a required field.</div>
                </div>
            </div><!-- End Row -->
            <div class="form-group row">
                <div class="form-group col-sm-12">
                    <label for="reasonNotRatedComment" class="key">REASON NOT RATED COMMENT</label>
                    <textarea class="form-control" :class="{'input': true }" id="reasonNotRatedComment" v-model="formData.dealInfo.reasonNotRatedComment" rows="3"></textarea>
                </div>
            </div><!-- End Row -->
            <div class="form-group row row-margin-fix text-bold">
                <div class="form-check form-check-inline col-sm-6">
                    <label class="form-check-label">
                        <input
                            class="form-check-input"
                            type="checkbox"
                            name="requiresSurveillance"
                            id=""
                            v-model="formData.dealInfo.emergingMarket"/>
                        Emerging Market
                    </label>
                </div>
            </div><!-- End Row -->
        </div>
    </div><!-- End Deal Info -->
</template>
<script type="text/javascript">
    export default {
        props: [
            'formData'
        ],
        data() {
            return {
                isInputActive: false,
                dontSubmit: false,
                initialMarketSector: {
                    id: this.formData.dealInfo.marketSectorNameId,
                    desc: this.formData.dealInfo.marketSectorName,
                    extraFields: {
                        MNGMNT_LINE_ID: 999
                    }
                },
                money: {
                    decimal: '.',
                    thousands: ',',
                    prefix: '',
                    suffix: '',
                    precision: 2,
                    masked: false
                }
            }
        },
        computed: {
            showSection() {
                return this.$store.getters.showSection('dealInfo');
            },
            config() {
                return this.$store.getters.getDatepickerConfig;
            },
            required() {
                return this.$store.getters.required;
            },
            rated() {
                return this.$store.getters.isRated;
            },
            dealSize() {
                return this.$store.getters.getDealSize;
            },
            missingDealSize() { if (!this.formData.dealInfo.dealSize) return true},
            missingClosingDate() { if (!this.formData.dealInfo.closingDate) return true},
            missingPricingDate() { if (!this.formData.dealInfo.pricingDate) return true},
            marketSectorList() {
                var selectedManagementLine = this.formData.dealInfo.managementLineId;
                var markets = [];
                this.formData.lookUpDetails.marketSectorNameAll.forEach((item) => {
                    if (item.extraFields.MNGMNT_LINE_ID === selectedManagementLine) {
                        markets.push(item);
                    }
                });
                return markets;
            }
        },
        mounted() {
            //build market sector dropdown
            let marketSectorExists = false,
                managementLine = this.formData.dealInfo.managementLineId,
                markets = [];
            this.formData.lookUpDetails.marketSectorNameAll.map((item) => {
                //check if deal market sector is in the list
                if ((item.id === this.formData.dealInfo.marketSectorNameId)) {
                    marketSectorExists = true;
                    this.formData.dealInfo.marketSectorName = item.desc;
                }
                //filter market sector list
                if (managementLine && (parseInt(item.extraFields.MNGMNT_LINE_ID) === parseInt(managementLine))) markets.push(item);
            });
            //filtered list
            this.marketSectorList.push(...markets);
            //deal market sector
            if (!marketSectorExists) this.marketSectorList.push(this.initialMarketSector);
            //entire list
            if (!managementLine) this.marketSectorList.push(...this.formData.lookUpDetails.marketSectorName);

            //field validation
            this.$bus.$on('veeValidate', () => {
                this.$validator.validateAll();
                if (this.errors.items.length || (!this.rated && this.dealSize <= 0)) {
                    this.dontSubmit = true;
                    this.$bus.$emit('field-errors', true);
                }
            });
        },
        methods: {
            updateDropdown() {
                this.$store.commit('updateDropdown', event);
            },
            updateDate(event) {
                const dateObj = {
                    object: this.formData.dealInfo,
                    key: event.target.id,
                    value: event.target.value
                };
                this.$store.commit('updateDate', dateObj);
            }
        }
    }
</script>