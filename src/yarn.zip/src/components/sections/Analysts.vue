<template>
    <div class="my-form">
        <div>
            <section-header heading="ANALYSTS" section="analysts"></section-header>
        </div><!-- End Row -->

        <div v-show="showSection" class="section-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>ANALYST NAME</th>
                        <th>ANALYST ROLE</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="analyst in analysts">
                        <td> {{ analyst.name }} </td>
                        <td> {{ analyst.role }} </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div><!-- END Analysts Data -->
</template>
<script type="text/javascript">
    export default {
        props: [
            'analysts'
        ],
        data() {
            return {
            }
        },
        computed: {
            showSection() {
                return this.$store.getters.showSection('analysts');
            }
        },
        components: {
        }
    }
</script>