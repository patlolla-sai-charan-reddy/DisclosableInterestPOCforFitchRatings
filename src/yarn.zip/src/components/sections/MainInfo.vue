<style type="text/css">
    .key-label {
        line-height: 1.5em;
    }
</style>
<template>
    <div class="my-form">
        <div>
            <div class="row section-header">
                <h4 class="col-sm-10 section-heading">MAIN INFO</h4>
            </div>
        </div><!-- End Row -->
        <div v-show="showSection" class="section-body">
            <div class="form-group row">
                <my-text-input
                    placeholder="DEAL ID"
                    required=""
                    disabled="1"
                    :model="formData.dealInfo.dealId"
                    @modelChanged="formData.dealInfo.dealId=$event" />
                <my-text-input
                    placeholder="DEAL STATUS"
                    required=""
                    disabled="1"
                    :model="formData.dealInfo.dealStatus"
                    @modelChanged="formData.dealInfo.dealStatus=$event" />
            </div><!-- End Row -->
            <div class="key-label" v-b-tooltip title="Delete this Deal from BRM Tool and QV Report">
                DELETE THIS DEAL:
                <label class="">
                    <input
                        type="checkbox"
                        name="entityStatus"
                        v-model="deleteFromReport"/>
                </label>
            </div>
            <div class="form-group row">
                <my-text-input
                    placeholder="REPLACEMENT DEAL ID"
                    v-show= "deleteFromReport === true"
                    required=""
                    :model="formData.dealInfo.replacementDealId"
                    @modelChanged="formData.dealInfo.replacementDealId=$event" />
            </div><!-- End Row -->
            <div class="form-group row row-margin-fix">
                <div class="form-group col-sm-12">
                    <label for="comments" class="key">COMMENTS</label>
                    <textarea class="form-control" :class="{'input': true }" id="comments" v-model="formData.dealInfo.comments" rows="3"></textarea>
                </div>
            </div><!-- End Row -->
            <div class="row">
                <div class="col-sm-6">
                    <router-link tag="button" class="btn btn-md btn-modal" to="/home">
                        Back to Search
                    </router-link>
                </div>
                <div v-if="!$store.state.readOnly" class="col-sm-6">
                    <button
                        class="btn btn-md btn-modal pull-right"
                        @click="submit">Save</button>
                </div>
            </div><!-- End Row -->
        </div><!-- End Section -->
    </div><!-- end General Info -->
</template>
<script type="text/javascript">
    export default {
        props: [
            'formData'
        ],
        data() {
            return {
            }
        },
        computed: {
            showSection() {
                return this.$store.getters.showSection('mainInfo');
            },
            required() {
                return this.$store.getters.required;
            },
            deleteFromReport: {
                get() {
                    return !this.formData.dealInfo.includeInReport;
                },
                set(value) {
                    this.formData.dealInfo.includeInReport = !value;
                }
            },
            fieldErrors() {
                return this.$store.getters.getModal('fieldErrors');
            },
            success() {
                return this.$store.getters.getModal('success');
            },
            apiError() {
                return this.$store.getters.getModal('apiError');
            }
        },
        mounted() {
            this.$bus.$on('field-errors', (result) => {
                this.$store.state.dontSubmit = true;
            });
        },
        methods: {
            updateDropdown() {
                this.$store.commit('updateDropdown', event);
            },
            closeFieldsModal() {
                this.$refs.invalidFieldsModal.hide()
            },
            closeSuccessModal() {
                this.$refs.successModal.hide()
            },
            closeErrorModal() {
                this.$refs.errorModal.hide()
            },
            submit() {
                //Validate Deal fields
                this.$bus.$emit('veeValidate');

                this.$store.dispatch('storeDeal');
            }
        },
        components: {
        }
    }
</script>