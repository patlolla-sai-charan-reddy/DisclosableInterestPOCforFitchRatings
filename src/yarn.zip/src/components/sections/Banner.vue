<template>
    <div v-if="this.environment !== 'Prod'">
        <span id="forkMe">{{ environment }} Environment</span>
    </div>
</template>

<script type="text/javascript">
    export default {
        data() {
            return {
                environment: ''
            }
        },
        created() {
            //Local
            if (window.location.hostname === "localhost") {
                this.environment = "Local";
            }
            //Dev
            if (window.location.hostname === "brmapps-dev.fitchratings.com") {
                this.environment = "Dev";
            }
            //QA
            if (window.location.hostname === "brmapps-qa.fitchratings.com") {
                this.environment = "QA";
            }
            //QA
            if (window.location.hostname === "brmapps.fitchratings.com") {
                this.environment = "Prod";
            }
        },
    }
</script>

<style type="text/css" scoped>
div {
    background: #333
}
#forkMe {
    top: 3em;
    right: -6em;
    color: #fff;
    display: block;
    position: fixed;
    text-align: center;
    text-decoration: none;
    letter-spacing: .06em;
    background-color: #A00;
    padding: 0.5em 5em 0.4em 5em;
    text-shadow: 0 0 0.75em #444;
    box-shadow: 0 0 0.5em rgba(0,0,0,0.5);
    transform: rotate(45deg) scale(0.75,1);
    font: bold 16px/1.2em Arial, Sans-Serif;
    -webkit-text-shadow: 0 0 0.75em #444;
    -webkit-box-shadow: 0 0 0.5em rgba(0,0,0,0.5);
    -webkit-transform: rotate(45deg) scale(0.75,1);
    z-index:10;
}
#forkMe:before {
    content: '';
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    position: absolute;
    margin: -0.3em -5em;
    transform: scale(0.7);
    -webkit-transform: scale(0.7);
    border: 2px rgba(255,255,255,0.7) dashed;
}
</style>