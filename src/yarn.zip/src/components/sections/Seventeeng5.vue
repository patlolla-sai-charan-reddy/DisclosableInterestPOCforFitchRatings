<template>
    <div class="my-form">
        <div>
            <section-header heading="17g5 DATA" section="seventeenG5"></section-header>
        </div><!-- End Row -->

        <div v-show="showSection" class="section-body">
            <div class="form-group row">
                <div class="form-check form-check-inline col-6">
                    <label class="form-check-label checkbox-label-fix">
                        <input
                            class="form-check-input"
                            type="checkbox"
                            name="ruleEligible"
                            v-model="formData.dealInfo.secRule17g5Eligible">
                            SEC RULE 17g5 ELIGIBLE
                    </label>
                </div>
                <div class="form-group col-sm-6 style-fix-labels">
                    <label for="formGroupExampleInput" class="key">FEE LETTER BACK DATE</label>
                    <date-picker
                        id="feeLetterBackDate"
                        :value="formData.dealInfo.feeLetterBackDate"
                        :config="config"
                        @dp-hide="updateDate">
                    </date-picker>
                </div>
            </div><!-- End Row -->
            <div class="form-group row">
                <my-text-input
                    placeholder="ISSUER TRANSACTION URL"
                    required=""
                    :model="formData.dealInfo.issuerTransactionUrl"
                    @modelChanged="formData.dealInfo.issuerTransactionUrl=$event" />
                <my-text-input
                    placeholder="ISSUER NAME FOR RULE 17g5"
                    required=""
                    :model="formData.dealInfo.issuerNameForRule17g5"
                    @modelChanged="formData.dealInfo.issuerNameForRule17g5=$event" />
            </div><!-- End Row -->
        </div>
    </div><!-- END 17g5 Data -->
</template>
<script type="text/javascript">
    export default {
        props: [
            'formData'
        ],
        data() {
            return {
            }
        },
        computed: {
            showSection() {
                return this.$store.getters.showSection('seventeenG5');
            },
            config() {
                return this.$store.getters.getDatepickerConfig;
            }
        },
        methods: {
            updateDate(event) {
                const dateObj = {
                    object: this.formData.dealInfo,
                    key: event.target.id,
                    value: event.target.value
                };
                this.$store.commit('updateDate', dateObj);
            }
        },
        components: {
        }
    }
</script>