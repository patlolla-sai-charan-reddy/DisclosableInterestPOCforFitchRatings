<style type="text/css" scoped>
    .section-header {
        cursor: pointer;
    }
    .section-heading {
        font-size: 1.5rem;
        font-weight: 300;
        color: #000000;
    }
</style>
<template>
    <div class="row section-header" @click="showhide()">
        <h4 class="col-sm-10 section-heading">{{ heading | toUpperCase}}</h4>
        <div class="col-sm-2">
            <i
                class=" col-sm-4 pull-right"
                :class="{'fa fa-compress': receivedSection, 'fa fa-expand': !receivedSection}"
                aria-hidden="true"></i>
        </div>
    </div>
</template>
<script type="text/javascript">
    export default {
        props: [
            'heading',
            'section'
        ],
        computed: {
            receivedSection() {
                return this.$store.getters.showSection(this.section);
            }
        },
        filters: {
            toUpperCase(value) {
                return value.toUpperCase();
            }
        },
        methods: {
            showhide(e) {
                this.$store.commit('updateSection', this.section);
            }
        }
    }
</script>