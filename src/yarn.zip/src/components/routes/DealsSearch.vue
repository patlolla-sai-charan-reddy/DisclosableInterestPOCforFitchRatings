<template>
    <div class="container">
        <home-button></home-button>
        <div class="search-info">
            <form class="form-home my-form" :class="{ slider: showResults }">
                <div id="background">
                    <p id="bg-text">LIVE PRODUCTION DEALS</p>
                </div>
                <h4 data-v-5676b09e="" class="col-sm-10 section-heading">LIVE PRODUCTION DEALS</h4>
                <div class="section-body">
                    <h4 class="form-text search-text" for="searchInput">Search for your Deal Name/ID below.</h4>
                    <div class="col-sm-12 search-deals-container">
                        <div class="search-deals col-sm-10" :class="{ 'has-danger': errors.has('search') }">
                            <div class="row">
                                <div class="col-sm-11">
                                    <input
                                    id="searchInput"
                                    name="search"
                                    type="text"
                                    class="form-control"
                                    :class="{'input': true, 'form-control-danger': errors.has('search') }"
                                    placeholder="Enter Deal Name/ID"
                                    v-model="searchInput"
                                    v-validate="'required'"
                                    autocomplete="off"
                                    @keydown.enter.prevent="getResults" />
                                </div>
                                <div class="col-sm-1">
                                    <span class="float-right" @click="getResults"><i class="fa fa-search"></i></span>
                                </div>
                            </div>
                            <div v-show="errors.first('search')" class="form-control-feedback">Please enter a deal name or ID.</div>
                        </div>
                        <div class="search-deals col-sm-10">
                            <div class="form-check include-active">
                                <label class="form-check-label">
                                    <input class="form-check-input" type="checkbox" v-model="includeInactive">
                                    Include Inactive Deals
                                </label>
                            </div>
                        </div>
                    </div>
                    <div v-if="!$store.state.readOnly" class="col-sm-12 new-deal-info">
                        <p class="deal-text">Don't see the deal you need?</p>
                        <router-link class="new-deal" to="/newdeal">CREATE A NEW DEAL</router-link>
                    </div>
                </div>
            </form>
            <transition name="fade">
                <div v-if="showResults === 'true'">
                    <div class="my-form">
                        <search-results :results="results"></search-results>
                    </div>
                </div>
                <div v-if="showResults === 'false'" class="my-form">
                    <span>Please try a different search term.</span>
                </div>
            </transition>
        </div>
    </div>
</template>

<style scoped>
    .form-home {
        margin-top: 120px;
        margin-left: auto;
        margin-right: auto;
        width:576px;
        min-height:200px;
        text-align: center;
    }
    .slider {
        transform: translate(0, -100px);
        transition: 2s cubic-bezier(.25,.8,.25,1);
    }
    .my-form {
        box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
    }
    h2, h6, h4 {
        color: #4D4D4D;
        letter-spacing: 0
    }
    h2 {
        margin-bottom: 0;
        font-size: 1.8rem;
        font-weight: 300;
    }
    h4  {
        font-size: 1rem;
        font-weight: 700;
    }
    h6 {
        margin-bottom: 2rem;
        font-weight: 400;
    }
    .form-text {
        font-weight: 700;
    }
    .search-deals-container {
        padding: 0;
    }
    .has-icon-right>.fa {
        display: inline-block;
        font-size: 1rem;
        text-align: center;
        color: #DBDBDB;
        pointer-events: none;
        position: absolute;
        top: 10px;
        z-index: 4;
        right: 60px;
    }
    .search-deals {
        display: inline-block;
        width: 100%;
    }
    .fa-search {
        font-size: 1.5rem;
    }
    .include-active {
        margin-top: 0.5rem;
        text-align: left;
    }
    .deal-text {
        margin-bottom: 0;
        font-weight: 400;
    }
    .new-deal {
      cursor: pointer;
      color: #4F7580;
      font-size: 0.8rem;
      font-weight: 700;
      text-decoration: none;
    }
    .fade-enter-active {
        transition: opacity 2s;
    }
    .fade-enter, .fade-leave-to, .fade-leave-active {
        opacity: 0;
    }
    li {
        cursor: pointer;
    }
    .row-active {
        background-color: #0275d8;
        color: #FFFFFF;
    }
    .row-disabled {
        pointer-events: none;
        cursor: not-allowed;
    }
    .welcome-label {
        color: #FFF;
        margin-bottom: 25px;
    }
    .logged-role {
        color: #FFF;
        margin-bottom: 25px;
    }
    .section-heading {
        font-size: 1.5rem;
        font-weight: 300;
        color: #000;
        text-align: left;
    }
    .section-body {
        margin-top: 20px;
    }
    #background{
        position: absolute;
        display: block;
        min-height: 50%;
        /* min-width: 50%; */
        color: yellow;
        margin-top: 115px;
        opacity: 0.2;
    }
    #bg-text {
        color:lightgrey;
        font-size:43px;
        transform:rotate(343deg);
        -webkit-transform:rotate(343deg);
    }
    .search-text {
        margin-bottom: 20px;
    }
</style>

<script>
    import SearchResults from '../sections/SearchResults.vue';
    import MyRated from '../tables/Components/MyRated.vue';
    import RatedHeaderInput from '../tables/Components/RatedHeaderInput.vue';
    import {HTTP} from '../../utils/calls';
    import {router} from '../../utils/router.js';

    export default {
        data() {
            return {
                //showResults: "",
                includeInactive: false,
                pager: {
                    term: "",
                    total: 0,
                    pages: 0,
                    currentPage: 0,
                    last:0
                },
            }
        },
        computed: {
            user() {
                return this.$store.getters.getUser.toUpperCase();
            },
            userRole() {
                return this.$store.getters.getUserRole;
            },
            searchInput: {
                get() {
                    return this.$store.state.searchTerm;
                },
                set(value) {
                    this.$store.dispatch('updateSearchTerm', value);
                }
            },
            showResults() {
                return this.$store.getters.showResults;
            },
            results() {
                return this.$store.getters.getSearchResults;
            },
        },
        methods: {
            getResults() {
                this.$validator.validateAll().then(result => {
                    if (result) {
                        var apiUrl = 'deals?dealIdentifier=' + this.searchInput + "&includeInactive=" + this.includeInactive;
                        this.pager.term = this.searchInput;
                        this.$store.dispatch('fetchResults', apiUrl);
                    }
                    return;
                });
            }
        },
        created() {
        },
        components: {
            'search-results': SearchResults,
            MyRated,
            RatedHeaderInput
        }
    }
</script>
