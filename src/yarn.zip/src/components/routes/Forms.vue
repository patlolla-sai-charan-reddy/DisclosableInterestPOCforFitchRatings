<template>
    <div>
        <home-button></home-button>
        <!-- Banner -->
        <banner></banner>
        <!-- Loaded -->
        <div v-if="ready">
             <fieldset :disabled="readOnly" :class="{ 'form-disabled': readOnly }">
                <my-form :formData="formData"></my-form>
            </fieldset>
        </div><!-- End loaded -->

        <!-- Loading -->
        <loading v-else></loading>
    </div><!--END Forms Container -->
</template>
<script type="text/javascript">
    import axios from 'axios';
    import {HTTP} from '../../utils/calls';
    export default {
        props: [],
        data() {
            return {
            }
        },
        computed: {
            ready() {
                return this.$store.getters.getFormsStatus;
            },
            formData() {
                return this.$store.getters.getFormData;
            },
            readOnly() {
                return this.$store.getters.isReadOnly;
            }
        },
        created() {
            const dealId = this.$route.params.id;
            this.$store.dispatch('fetchDeal', dealId);
        },
        mounted() {
            this.$bus.$on('field-errors', (result) => {
                this.$store.state.dontSubmit = true;
            });
        },
        methods: {
            submit() {
                //Validate Deal Fields
                this.$bus.$emit('veeValidate');

                this.$store.dispatch('storeDeal');
            }
        },
        components: {
        }
    }
</script>