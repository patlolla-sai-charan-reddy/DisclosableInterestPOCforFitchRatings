<template>
    <div class="container">
        <home-button></home-button>
        <div class="my-form search-criteria">
            <div>
                <section-header heading="Search Criteria" section="dealInfo"></section-header>
            </div><!-- End Row -->
            <div class="section-body" v-show="showSection">
                <div class="setMargin row">
                    <my-text-input
                        placeholder="DEAL STATUS"
                        required=""
                        disabled="1"
                        :model="label"
                        @modelChanged="updateDealStatus"
                    />
                </div>
                <div class="form-group row">
                    <div class="form-group col-sm-6">
                        <label for="preSaleDate" class="key">CLOSING DATE - FROM: </label>
                        <date-picker
                            id="closingDateFrom"
                            :value="currentRow.closingDateFrom || initialclosingDateFrom"
                            :config="config"
                            @dp-hide="updateDate($event, currentRow)">
                        </date-picker>
                    </div>
                    <div class="form-group col-sm-6 style-fix-labels">
                        <label for="formGroupExampleInput" class="key">CLOSING DATE - TO: </label>
                        <date-picker
                            id="closingDateTo"
                            :value="currentRow.closingDateTo || initialclosingDateTo"
                            :config="config"
                            @dp-hide="updateDate($event, currentRow)">
                        </date-picker>
                    </div>
                </div><!-- End Row -->
                 <div class="form-group row">
                    <div class="form-group col-sm-6">
                        <label for="preSaleDate" class="key">PRICING DATE - FROM: </label>
                        <date-picker
                            id="pricingDateFrom"
                            :value="currentRow.pricingDateFrom || initialpricingDateFrom"
                            :config="config"
                            @dp-hide="updateDate($event, currentRow)">
                        </date-picker>
                    </div>
                    <div class="form-group col-sm-6 style-fix-labels">
                        <label for="formGroupExampleInput" class="key">PRICING DATE - TO: </label>
                        <date-picker
                            id="pricingDateTo"
                            :value="currentRow.pricingDateTo || initialPricingDateTo"
                            :config="config"
                            @dp-hide="updateDate($event, currentRow)">
                        </date-picker>
                    </div>
                </div><!-- End Row -->
                <div class="form-group row">
                    <my-select-input
                        elementId=""
                        placeholder="MANAGEMENT LINE REGION"
                        :initialValue="mgntLineInitial"
                        required=""
                        :options="managementLineRegion"
                        @modelChanged="updateMgmtRegion"
                    />
                    <my-select-input
                        elementId=""
                        placeholder="MARKET SECTOR"
                        :initialValue="marketSectorInitial"
                        required=""
                        :options="marketSectorNameAll"
                        @modelChanged="updateSectorRegion"
                    />
                </div><!-- End Row -->
                <div class="form-group row">
                    <my-select-input
                        elementId=""
                        placeholder="MANAGEMENT LINE"
                        :initialValue="managementLineDropdownInitial"
                        required=""
                        :options="managementLine"
                        @modelChanged="updateMgmt"
                    />
                </div><!-- End Row -->
                <!-- Field Error Modal -->
                <modal :modal="fieldErrors"></modal>
                <!-- Success Modal -->
                <modal :modal="success"></modal>
                <!-- API Error Modal -->
                <modal :modal="apiError"></modal>
                <!-- nullSearch Modal -->
                <modal :modal="nullSearch"></modal>
                <!-- publish Modal -->
                <modal :modal="publish"></modal>
                <!-- saved Modal -->
                <modal :modal="saved"></modal>
                <!-- dynamic Modal -->
                <modal :modal="dynamic"></modal>
            </div>
        </div>
        <div class="row search-deal">
            <button class="button seatch-btn-1" @click="searchRatedData">Search</button>
            <button class="button create-btn-1" @click="createNewTableSearch">Create New Deals</button>
        </div>
        <div class="non-rated-loading" v-if="showSpinner === 'true'">
            <loading></loading>
        </div>
        <div>
            <div class="my-form search-table-data" v-if="nonRatedTableView === 'true'">
                <div class="test-header">
                    Page Size:
                    <select v-on:change="onPageSizeChanged()" id="page-size">
                        <option value="10" selected="">10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                </div>
                <ag-grid-vue style="height: 540px;"
                    class="ag-theme-fresh"
                    @grid-ready="onReady"
                    :gridOptions="gridOptions"
                    :columnDefs="columnDefs"
                    :rowData="NonrowData"
                    :enableColResize="true"
                    :suppressColumnVirtualisation="true"
                    :enableSorting="true"
                    :enableFilter="true"
                    enableRangeSelection="true"
                    rowHeight="40"
                    headerHeight="40"
                    :paginationAutoPageSize="true"
                    :pagination="true"
                    :enableCellChangeFlash="true"
                >
                </ag-grid-vue>
            </div>
            <div class="my-form search-table-data" v-if="createNewTable === 'true'">
                <div class="test-header">
                    Page Size:
                    <select v-on:change="onPageSizeChanged()" id="page-size">
                        <option value="10" selected="">10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                </div>
                <ag-grid-vue style="height: 550px;"
                    class="ag-theme-fresh"
                    @grid-ready="onReady"
                    :gridOptions="gridOptions"
                    :columnDefs="columnDefs"
                    :rowData="NonrowData"
                    :enableColResize="true"
                    :suppressColumnVirtualisation="true"
                    :enableSorting="true"
                    :enableFilter="true"
                    enableRangeSelection="true"
                    rowHeight="40"
                    headerHeight="40"
                    :paginationAutoPageSize="true"
                    :pagination="true"
                    :enableCellChangeFlash="true"
                >
                </ag-grid-vue>
            </div>
            <div v-if="nonRatedTableView === 'true' || createNewTable === 'true'">
                <!--<button class="btn-2 button" @click="addNewRow">Add New Row</button>-->
                <button class="btn-1 button" @click="saveInStagingArea">Save in Staging Area</button>
                <button class="btn-2 button" @click="publishInStagingArea">Publish</button>
            </div>
        </div>
    </div>
</template>

<style lang="scss">
    $color: #4dccbd;

    .search-criteria {
        margin-top: 20px;
    }
    .nested-table {
        display: none;
    }
    .deal-status {
        display: inline;
    }
    .search-deal {
        padding-left: 15px
    }
    .non-rated-loading {
        margin-top: 40px;
    }
    .cd-1 {
        padding-right: 0px;
    }
    .cd-2 {
         padding-left: 0px;
    }
    .search-table-data {
        margin-top: 40px;
    }
    .setMargin {
        margin-bottom: 30px;
    }
    .search-btn {
        padding: 12px;
        border: none;
        outline: none;
        border-radius: 4px;
        cursor: pointer;
        margin-bottom: 20px;
    }
    .seatch-btn-1, .create-btn-1 {
        margin-top: 20px;
    }
    .seatch-btn-1 {
        margin-right: 15px;
    }
    #chase {
        border: 1px solid #a9a9a9;
        color: black;
    }
    .nested-table {
        margin-bottom: 30px;
    }
    #selectOption {
        width: 100%;
        padding: 0.375rem 0.75rem;
    }
    .textOverlap {
        line-height: 1.6;
    }
    .forDownIcon {
        position: absolute;
        right: 16px;
        top: 1px;
        padding: 6.2px;
        background-color: #aaa;
    }
    .pricingDate {
        margin-left: 10px;
    }
    .button {
        text-align: center;
        text-decoration: none;
        color: $color;
        background-color: #F5F5F5;
        cursor: pointer;
        font-size: 18px;
        font-weight: 600;
        display: inline-block;
        border-radius: 0.3em;
        transition: all 0.2s ease-in-out;
        position: relative;
        overflow: hidden;
        &:before {
            content: "";
            background-color: rgba(255,255,255,0.5);
            height: 100%;
            width: 3em;
            display: block;
            position: absolute;
            top: 0;
            left: -4.5em;
            transform: skewX(-45deg) translateX(0);
            transition: none;
      }
        &:hover {
            background-color: $color;
            color: #fff;
            border-bottom: 4px solid darken($color, 10%);
            &:before {
                    transform: skewX(-45deg) translateX(13.5em);
                    transition: all 0.5s ease-in-out;
                }
        }
    }
    .modal {
        color: black;
    }
    #app > div > div:nth-child(4) > div.my-form > div > div > div.ag-root-wrapper-body.ag-layout-normal > div.ag-root.ag-font-style.ag-layout-normal {
        height: 106% !important;
    }
    .start-section {
        margin-top: 18px;
    }
    .test-header {
        margin-bottom: 15px;
        text-align: right;
    }
    #app > div > div:nth-child(4) > div.my-form.search-table-data > div.ag-theme-fresh > div > div.ag-paging-panel.ag-font-style {
        margin-top: 10px;
    }  
    #app > div > div:nth-child(4) > div.my-form.search-table-data > div.ag-theme-fresh > div > div.ag-paging-panel.ag-font-style {
        padding:19px;
    }
</style>

<script type="text/javascript">
    import {AgGridVue} from 'ag-grid-vue';
    import RatedHeaderInput from '../tables/Components/RatedHeaderInput.vue';
    import HeaderInput from '../tables/Components/HeaderInput.vue';
    import HeaderCheckbox from '../tables/Components/HeaderCheckbox.vue';
    import ClassSelect from '../tables/Components/ClassSelect.vue';
    import Checkbox from '../tables/Components/Checkbox.vue';
    import MyInput from '../tables/Components/MyInput.vue';
    import MyRated from '../tables/Components/MyRated.vue';
    import {HTTP} from '../../utils/calls';

    export default {
        props: {
            type: {
                type: Boolean
            },
            dealCurrency: {
                //type: Number
            },
            model: {
                type: Object
            },
            flag: {}
        },
        data() {
            return {
                currentRow: {},
                showGrid: false,
                colIds: [],
                dealDetails: null,
                initialclosingDateFrom: '',
                initialclosingDateTo: '',
                initialpricingDateFrom: '',
                initialPricingDateTo: '',
                managementLineRegion: null,
                managementLine: [],
                marketSectorNameAll: null,
                dealStatusInitial: 'NON RATED',
                dealStatusInitialId: '',
                mgntLineInitial: '',
                marketSectorInitial: '',
                managementLineDropdownInitial: '',
                errorMessage: '',
                store: {},
                label: 'NOT RATED',
                columnDefs: null,
                newRow: {
                    DEAL_ID : null,
                    MANAGEMENT_LINE_REGION : '',
                    COUNTRY_OF_ASSETS : '',
                    DEAL_ISSUANCE_CURRENCY : '',
                    PRICING_DATE : null,
                    MANAGEMENT_LINE : '',
                    SUB_SECTOR : '',
                    MARKET_SECTOR_NAME : '',
                    CLASS_NAME : '',
                    DEAL_NAME : '',
                    FITCH_RATED_AMOUNT : '',
                    ORIGINATOR : '',
                    ASSET_MANAGER : '',
                    ARRANGER : '',
                    SPONSOR_OF_THE_SPV : '',
                    PUBLICLY_RATED_BY_FITCH : false,
                    INCLUDE_IN_REPORT : false,
                    MOODYS_RATED : false,
                    SP_RATED : false,
                    DBRS_RATED : false,
                    KROLL_RATED : false,
                    MORNINGSTAR_RATED : false,
                    SCOPE_RATED: false,
                    REGISTRATION : '',
                    JURISDICTION : '',
                    REASON_NOT_RATED : '',
                    REASON_NOT_RATED_COMMENT : ''
                },
                gridApi: null,
                gridOptions: null,
                emptyRowData: []
            }
        },
        computed: {
            config() {
                return this.$store.getters.getDatepickerConfig;
            },
            showRatedResults() {
                return this.$store.getters.showRatedResults;
            },
            showNotRatedResults() {
                return this.$store.getters.showNotRatedResults;
            },
            fieldErrors() {
                return this.$store.getters.getModal('fieldErrors');
            },
            success() {
                return this.$store.getters.getModal('success');
            },
            apiError() {
                return this.$store.getters.getModal('apiError');
            },
            dynamic() {
                return  this.$store.getters.getModal('dynamic');
            },
            nullSearch() {
				return this.$store.getters.getModal('nullSearch');
            },
            publish() {
				return this.$store.getters.getModal('publish');
            },
            saved() {
				return this.$store.getters.getModal('saved');
			},
            showSection() {
                return this.$store.getters.showSection('dealInfo');
            },
            NonrowData() {
                return this.$store.getters.NonrowData
            },
            showSpinner() {
				return this.$store.getters.showSpinner;
			},
            nonRatedTableView() {
                return this.$store.getters.nonRatedTableView;
            },
            createNewTable() {
                return this.$store.getters.createNewTable;
            }
        },
        created() {
            const workId =  {
                "workId": this.$route.params.id ? this.$route.params.id : 0
            } 

            HTTP.post('/lookupStage', workId)
                .then(response => {
                    this.dealDetails = response.data.lookUpDataDetails.dealStatus.filter(el => el.desc !== 'NOT RATED');
                    this.managementLineRegion = response.data.lookUpDataDetails.managementLineRegion;
                    this.marketSectorNameAll = this.removeDuplicates(response.data.lookUpDataDetails.marketSectorNameAll, 'desc');
                    this.managementLine = response.data.lookUpDataDetails.managementLine;
                    
                    if (Array.isArray(response.data.lookUpDataDetails.searchFilter) && response.data.lookUpDataDetails.searchFilter && this.$route.params.id) {
                        
                        for(var i = 0; i < response.data.lookUpDataDetails.searchFilter.length; i++) {
                            
                            this.mgntLineInitial = response.data.lookUpDataDetails.searchFilter["0"].extraFields.managementLineRegion !== "" ?response.data.lookUpDataDetails.managementLineRegion.filter(el => el.id == response.data.lookUpDataDetails.searchFilter["0"].extraFields.managementLineRegion)[0].desc : '';
                            
                            this.marketSectorInitial =  response.data.lookUpDataDetails.searchFilter[0].extraFields.marketSectorName !== "" ? response.data.lookUpDataDetails.marketSectorNameAll.filter(el => el.id == response.data.lookUpDataDetails.searchFilter[0].extraFields.marketSectorName)[0].desc : '';

                            this.managementLineDropdownInitial = response.data.lookUpDataDetails.searchFilter["0"].extraFields.managementLine !== "" ?response.data.lookUpDataDetails.managementLine.filter(el => el.id == response.data.lookUpDataDetails.searchFilter["0"].extraFields.managementLine)[0].desc : '';
                            
                            this.initialclosingDateFrom =  response.data.lookUpDataDetails.searchFilter["0"].extraFields.closingDateFrom !== "" ?response.data.lookUpDataDetails.searchFilter["0"].extraFields.closingDateFrom : '';

                                
                            this.initialclosingDateTo = response.data.lookUpDataDetails.searchFilter[0].extraFields.closingDateTo !== "" ?response.data.lookUpDataDetails.searchFilter[0].extraFields.closingDateTo : '';
                                
                            this.initialpricingDateFrom = response.data.lookUpDataDetails.searchFilter[0].extraFields.pricingDateFrom ? response.data.lookUpDataDetails.searchFilter[0].extraFields.pricingDateFrom: '';
                            
                            this.initialPricingDateTo = response.data.lookUpDataDetails.searchFilter[0].extraFields.pricingDateTo !== "" ?response.data.lookUpDataDetails.searchFilter[0].extraFields.pricingDateTo: '';

                            this.store.mgmtLineRegion =  response.data.lookUpDataDetails.searchFilter["0"].extraFields.managementLineRegion;
                            this.store.managementLine = response.data.lookUpDataDetails.searchFilter["0"].extraFields.managementLine;
                            this.store.marketSector = response.data.lookUpDataDetails.searchFilter["0"].extraFields.marketSectorName;
                            this.store.dealStatus =  response.data.lookUpDataDetails.searchFilter["0"].extraFields.dealStatus;
                            this.store.closingDateStart =  response.data.lookUpDataDetails.searchFilter["0"].extraFields.closingDateFrom;
                            this.store.closingDateEnd = response.data.lookUpDataDetails.searchFilter["0"].extraFields.closingDateTo;
                            this.store.priceDateStart = response.data.lookUpDataDetails.searchFilter["0"].extraFields.pricingDateFrom;
                            this.store.priceDateEnd = response.data.lookUpDataDetails.searchFilter["0"].extraFields.pricingDateTo;
                            
                        }
                    }
                })
                .catch(error => {
                    console.log("error", error.response);
                })
            
            if(this.$route.params.id) {
                this.$store.dispatch('fetchForNotRatedResults', workId);
            }
        },

        methods:  {
            onPageSizeChanged(newPageSize) {
                var value = document.getElementById("page-size").value;
                this.gridOptions.api.paginationSetPageSize(Number(value));
            },
            createColumnDefs() {
                this.columnDefs = [
                    {
                        headerName: 'SFWC',
                        //headerGroupComponentFramework: HeaderGroupComponent,
                        children: [
                            {
                                colId: "checked",
                                width:40,
                                headerComponentParams: { name: '', flag: 'NotRatedDeals'},
                                headerComponentFramework: HeaderCheckbox,
                                cellRendererFramework: Checkbox,
                            },
                            {
                                colId: 'DEAL_ID',
                                field:'DEAL_ID',
                                width: 140,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Deal ID'},
                                cellRendererFramework: MyRated,
                                //editable: true
                            }
                        ]
                    },
                    {
                        headerName: 'Market Placement',
                        //headerGroupComponentFramework: HeaderGroupComponent,
                        children: [
                            {
                                colId: 'MANAGEMENT_LINE_REGION',
                                field:'MANAGEMENT_LINE_REGION',
                                width: 200,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Region'},
                                cellRendererFramework: MyInput, 
                                editable: true                         
                            },
                            {
                                colId: 'COUNTRY_OF_ASSETS',
                                field:'COUNTRY_OF_ASSETS',
                                width: 200,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Country'},
                                cellRendererFramework: MyInput,
                                editable: true
                            }, 
                            {
                                colId: 'DEAL_ISSUANCE_CURRENCY',
                                field:'DEAL_ISSUANCE_CURRENCY',
                                width: 200,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'DEAL ISSUANCE CURRENCY'},
                                cellRendererFramework: MyInput,
                                editable: true
                            }
                        ]
                    },
                    {
                        headerName: 'Timing',
                        children: [
                            {
                                colId: 'PRICING_DATE',
                                field:'PRICING_DATE',
                                width: 140,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Pricing Date (YYYY-MM-DD)'},
                                cellRendererFramework: MyInput,
                                editable: true
                            }
                        ]
                    },
                    {
                        headerName: 'Transaction Type',
                        children: [
                            {
                                colId: 'MANAGEMENT_LINE',
                                field:'MANAGEMENT_LINE',
                                width: 200,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Management Line'},
                                cellRendererFramework: MyInput,
                                editable: true
                            },
                            {
                                colId: 'MARKET_SECTOR_NAME',
                                field:'MARKET_SECTOR_NAME',
                                width: 200,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'MARKET SECTOR (Level 1)'},
                                cellRendererFramework: MyInput,
                                editable: true
                            },
                            {
                                colId: 'SUB_SECTOR',
                                field:'SUB_SECTOR',
                                width: 200,
                                headerComponentFramework: RatedHeaderInput,
                                headerComponentParams: { name: 'MARKET SECTOR (Level 2)'},
                                cellRendererFramework: MyRated,
                                editable: true
                            }
                        ]
                    },
                    {
                        headerName: 'Issuance',
                        children: [
                            {
                                colId: 'CLASS_NAME',
                                field:'CLASS_NAME',
                                width: 140,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Class Name'},
                                cellRendererFramework: MyInput,
                                editable: true
                            },
                            {
                                colId: 'DEAL_NAME',
                                field:'DEAL_NAME',
                                width: 140,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Deal Name'},
                                cellRendererFramework: MyInput,
                                editable: true
                            },
                            
                            {
                                colId: 'FITCH_RATED_AMOUNT',
                                field:'FITCH_RATED_AMOUNT',
                                width: 200,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Amount (MM)'},
                                cellRendererFramework: MyInput,
                                editable: true
                            },
                        ]
                    },
                    {
                        headerName: 'Parties to the Transaction',
                        children: [
                            {
                                colId: 'SPONSOR_OF_THE_SPV',
                                field:'SPONSOR_OF_THE_SPV',
                                width: 140,
                                headerComponentFramework: RatedHeaderInput,
                                headerComponentParams: { name: 'Sponsor of SPV'},
                                cellRendererFramework: MyInput,
                                editable: true
                            },
                            {
                                colId: 'ORIGINATOR',
                                field:'ORIGINATOR',
                                width: 140,
                                headerComponentFramework: RatedHeaderInput,
                                headerComponentParams: { name: 'Originator'},
                                cellRendererFramework: MyInput,
                                editable: true
                            },
                            {
                                colId: 'ASSET_MANAGER',
                                field:'ASSET_MANAGER',
                                width: 140,
                                headerComponentFramework: RatedHeaderInput,
                                headerComponentParams: { name: 'Assert Manager'},
                                cellRendererFramework: MyInput,
                                editable: true
                            },
                            {
                                colId: 'ARRANGER',
                                field:'ARRANGER',
                                width: 140,
                                headerComponentFramework: RatedHeaderInput,
                                headerComponentParams: { name: 'Arranger'},
                                cellRendererFramework: MyInput,
                                editable: true
                            }
                        ]
                    },
                    {
                        headerName: 'Rating Agencies',
                        children: [
                            {
                                colId: 'INCLUDE_IN_REPORT',
                                field:'INCLUDE_IN_REPORT',
                                width: 200,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Include in Report'},
                                cellRendererFramework: MyInput,
                                editable: true
                            },
                            {
                                colId: 'PUBLICLY_RATED_BY_FITCH',
                                field:'PUBLICLY_RATED_BY_FITCH',
                                width: 200,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Fitch'},
                                cellRendererFramework: MyInput,
                                editable: true
                            },
                            {
                                colId: 'MOODYS_RATED',
                                field:'MOODYS_RATED',
                                width: 140,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Moodys'},
                                cellRendererFramework: MyInput,
                                editable: true
                            },
                            {
                                colId: 'SP_RATED',
                                field:'SP_RATED',
                                width: 140,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'S&P'},
                                cellRendererFramework: MyInput,
                                editable: true
                            },
                            {
                                colId: 'DBRS_RATED',
                                field:'DBRS_RATED',
                                width: 140,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'DBRS'},
                                cellRendererFramework: MyInput,
                                editable: true
                            },
                            {
                                colId: 'KROLL_RATED',
                                field:'KROLL_RATED',
                                width: 140,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Kroll'},
                                cellRendererFramework: MyInput,
                                editable: true
                            },
                            {
                                colId: 'MORNINGSTAR_RATED',
                                field:'MORNINGSTAR_RATED',
                                width: 200,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Morn'},
                                cellRendererFramework: MyInput,
                                editable: true
                            },
                            {
                                colId: 'SCOPE_RATED',
                                field:'SCOPE_RATED',
                                width: 200,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Scope'},
                                cellRendererFramework: MyInput,
                                editable: true
                            }
                        ]
                    },
                    {
                        headerName: '',
                        children: [
                            {
                                colId: 'REGISTRATION',
                                field:'REGISTRATION',
                                width: 200,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Placement Type'},
                                cellRendererFramework: MyRated,
                                editable: true
                            },
                            {
                                colId: 'JURISDICTION',
                                field:'JURISDICTION',
                                width: 140,
                                headerComponentFramework: HeaderInput,
                                headerComponentParams: { name: 'Jurisdiction'},
                                cellRendererFramework: MyRated,
                                editable: true
                            },
                            {
                                colId: 'REASON_NOT_RATED',
                                field:'REASON_NOT_RATED',
                                width: 200,
                                headerComponentFramework: RatedHeaderInput,
                                headerComponentParams: { name: 'Reasons Not Rated'},
                                cellRendererFramework: MyRated,
                                editable: true
                            },
                            {
                                colId: 'REASON_NOT_RATED_COMMENT',
                                field:'REASON_NOT_RATED_COMMENT',
                                width: 140,
                                headerComponentFramework: RatedHeaderInput,
                                headerComponentParams: { name: 'Reasons Not Rated Comment'},
                                cellRendererFramework: MyRated,
                                editable: true
                            }
                        ]
                    }
                    
                ];
            },
            onReady(params) {
                this.gridOptions.columnApi.getAllColumns().forEach((column) => {
                    this.colIds.push(column.colId);
                });
                params.api.paginationGoToPage(4);
                
            },
            resizeColumns() {
                this.gridOptions.columnApi.autoSizeColumns(this.colIds);
            },
            removeDuplicates(sectorName, prop) {
                var filteredSector = [];
                var lookupObject  = {};

                for(var i in sectorName) {
                    lookupObject[sectorName[i][prop]] = sectorName[i];
                }

                for(i in lookupObject) {
                    filteredSector.push(lookupObject[i]);
                }
                return filteredSector;
            }, 
            updateDate(event, row) {
                const dateObj = {
                    object: row,
                    key: event.target.id,
                    value: event.target.value
                };

                if(dateObj.key === 'closingDateFrom') {
                    this.store.closingDateStart = dateObj.value;
                } else if (dateObj.key === 'closingDateTo') {
                    this.store.closingDateEnd = dateObj.value;
                } else if (dateObj.key === 'pricingDateFrom') {
                    this.store.priceDateStart = dateObj.value;
                } else if (dateObj.key === 'pricingDateTo') {
                    this.store.priceDateEnd = dateObj.value;
                }
            },
            updateDealStatus(event, row) {
                this.store.dealStatus = event.target.value;
            },
            updateMgmtRegion(event, row) {
                this.store.mgmtLineRegion = event.target.value;
            },
            updateMgmt(event, row) {
                this.store.managementLine = event.target.value;
            },
            updateSectorRegion(event, row) {
                this.store.marketSector = event.target.value;
            },
            searchRatedData() {
                if(this.store.dealStatus !== undefined || this.store.mgmtLineRegion !== undefined || this.store.marketSector !== undefined || this.store.closingDateStart !== undefined ||  this.store.closingDateEnd !== undefined || this.store.priceDateStart  !== undefined || this.store.priceDateEnd !== undefined ||  this.store.managementLine !== undefined) {
                    this.$store.dispatch('fetchForNotRatedResults', this.store);
                }
            },
            createNewTableSearch() {
                this.$store.dispatch('fetchNewTable');
            },
            saveInStagingArea() {
                var saveArea = [];
                this.gridOptions.rowData.map(el => saveArea.push(
                    {
                        recordStatus: el.recordStatus,
                        checked: el.checked,
                        ID: el.ID,
                        DEAL_ID: el.DEAL_ID,
                        MANAGEMENT_LINE_REGION: el.MANAGEMENT_LINE_REGION,
                        COUNTRY_OF_ASSETS: el.COUNTRY_OF_ASSETS,
                        DEAL_ISSUANCE_CURRENCY: el.DEAL_ISSUANCE_CURRENCY,
                        PRICING_DATE: el.PRICING_DATE,
                        MANAGEMENT_LINE: el.MANAGEMENT_LINE,
                        MARKET_SECTOR_NAME: el.MARKET_SECTOR_NAME,
                        DEAL_NAME: el.DEAL_NAME,
                        FITCH_RATED_AMOUNT: el.FITCH_RATED_AMOUNT,
                        REASON_NOT_RATED: el.REASON_NOT_RATED,
                        REASON_NOT_RATED_COMMENT: el.REASON_NOT_RATED_COMMENT,
                        PUBLICLY_RATED_BY_FITCH:  String(el.PUBLICLY_RATED_BY_FITCH).toLowerCase() === 'y' ? true :  String(el.PUBLICLY_RATED_BY_FITCH).toLowerCase() === 'n' ? false : String(el.PUBLICLY_RATED_BY_FITCH).toLowerCase(),
                        INCLUDE_IN_REPORT:  String(el.INCLUDE_IN_REPORT).toLowerCase() === 'y' ? true :  String(el.INCLUDE_IN_REPORT).toLowerCase() === 'n' ? false : String(el.INCLUDE_IN_REPORT).toLowerCase(),
                        MOODYS_RATED:  String(el.MOODYS_RATED).toLowerCase() === 'y' ? true :  String(el.MOODYS_RATED).toLowerCase() === 'n' ? false : String(el.MOODYS_RATED).toLowerCase(),
                        SP_RATED:  String(el.SP_RATED).toLowerCase() === 'y' ? true :  String(el.SP_RATED).toLowerCase() === 'n' ? false : String(el.SP_RATED).toLowerCase(),
                        DBRS_RATED:  String(el.DBRS_RATED).toLowerCase() === 'y' ? true :  String(el.DBRS_RATED).toLowerCase() === 'n' ? false : String(el.DBRS_RATED).toLowerCase(),
                        KROLL_RATED:  String(el.KROLL_RATED).toLowerCase() === 'y' ? true :  String(el.KROLL_RATED).toLowerCase() === 'n' ? false : String(el.KROLL_RATED).toLowerCase(),
                        MORNINGSTAR_RATED:  String(el. MORNINGSTAR_RATED).toLowerCase() === 'y' ? true :  String(el. MORNINGSTAR_RATED).toLowerCase() === 'n' ? false : String(el. MORNINGSTAR_RATED).toLowerCase(),
                        SCOPE_RATED:  String(el.SCOPE_RATED).toLowerCase() === 'y' ? true :  String(el.SCOPE_RATED).toLowerCase() === 'n' ? false : String(el.SCOPE_RATED).toLowerCase(),
                        REGISTRATION: el.REGISTRATION,
                        JURISDICTION: el.JURISDICTION,
                        CLASS_NAME: el.CLASS_NAME,
                        ORIGINATOR: el.ORIGINATOR,
                        ARRANGER: el.ARRANGER,
                        SPONSOR_OF_THE_SPV: el.SPONSOR_OF_THE_SPV,
                        ASSET_MANAGER: el.ASSET_MANAGER,
                        SUB_SECTOR: el.SUB_SECTOR
                    }
                ))

                let loadNextView = {
                   "stagingData": saveArea,
                   "updatedBy": localStorage.getItem('user_id'),
                   "dealStatus": this.store.dealStatus,
                   "mgmtLineRegion": this.store.mgmtLineRegion,
                   "managementLine": this.store.managementLine,
                   "marketSector": this.store.marketSector,
                   "closingDateStart": this.store.closingDateStart,
                   "closingDateEnd": this.store.closingDateEnd,
                   "priceDateStart": this.store.priceDateStart,
                   "priceDateEnd": this.store.priceDateEnd,
                   "dealType": "Not Rated",
                   "workId": this.$route.params.id ? this.$route.params.id : 0
                }

                this.$store.dispatch('sendNotRatedDeals', loadNextView);
            },
            publishInStagingArea() {
                var saveArea = [];
                this.gridOptions.rowData.map((el,i) => saveArea.push(
                    {
                        recordStatus: el.recordStatus,
                        index: i,
                        checked: el.checked,
                        ID: el.ID,
                        DEAL_ID: el.DEAL_ID,
                        MANAGEMENT_LINE_REGION: el.MANAGEMENT_LINE_REGION,
                        COUNTRY_OF_ASSETS: el.COUNTRY_OF_ASSETS,
                        DEAL_ISSUANCE_CURRENCY: el.DEAL_ISSUANCE_CURRENCY,
                        PRICING_DATE: el.PRICING_DATE,
                        MANAGEMENT_LINE: el.MANAGEMENT_LINE,
                        MARKET_SECTOR_NAME: el.MARKET_SECTOR_NAME,
                        DEAL_NAME: el.DEAL_NAME,
                        FITCH_RATED_AMOUNT: el.FITCH_RATED_AMOUNT,
                        REASON_NOT_RATED: el.REASON_NOT_RATED,
                        REASON_NOT_RATED_COMMENT: el.REASON_NOT_RATED_COMMENT,
                        PUBLICLY_RATED_BY_FITCH:  String(el.PUBLICLY_RATED_BY_FITCH).toLowerCase() === 'y' ? true :  String(el.PUBLICLY_RATED_BY_FITCH).toLowerCase() === 'n' ? false : String(el.PUBLICLY_RATED_BY_FITCH).toLowerCase(),
                        INCLUDE_IN_REPORT:  String(el.INCLUDE_IN_REPORT).toLowerCase() === 'y' ? true :  String(el.INCLUDE_IN_REPORT).toLowerCase() === 'n' ? false : String(el.INCLUDE_IN_REPORT).toLowerCase(),
                        MOODYS_RATED:  String(el.MOODYS_RATED).toLowerCase() === 'y' ? true :  String(el.MOODYS_RATED).toLowerCase() === 'n' ? false : String(el.MOODYS_RATED).toLowerCase(),
                        SP_RATED:  String(el.SP_RATED).toLowerCase() === 'y' ? true :  String(el.SP_RATED).toLowerCase() === 'n' ? false : String(el.SP_RATED).toLowerCase(),
                        DBRS_RATED:  String(el.DBRS_RATED).toLowerCase() === 'y' ? true :  String(el.DBRS_RATED).toLowerCase() === 'n' ? false : String(el.DBRS_RATED).toLowerCase(),
                        KROLL_RATED:  String(el. KROLL_RATED).toLowerCase() === 'y' ? true :  String(el. KROLL_RATED).toLowerCase() === 'n' ? false : String(el. KROLL_RATED).toLowerCase(),
                        MORNINGSTAR_RATED:  String(el.MORNINGSTAR_RATED).toLowerCase() === 'y' ? true :  String(el.MORNINGSTAR_RATED).toLowerCase() === 'n' ? false : String(el.MORNINGSTAR_RATED).toLowerCase(),
                        SCOPE_RATED:  String(el.SCOPE_RATED).toLowerCase() === 'y' ? true :  String(el.SCOPE_RATED).toLowerCase() === 'n' ? false : String(el.SCOPE_RATED).toLowerCase(),
                        REGISTRATION: el.REGISTRATION,
                        JURISDICTION: el.JURISDICTION,
                        CLASS_NAME: el.CLASS_NAME,
                        ORIGINATOR: el.ORIGINATOR,
                        ARRANGER: el.ARRANGER,
                        SPONSOR_OF_THE_SPV: el.SPONSOR_OF_THE_SPV,
                        ASSET_MANAGER: el.ASSET_MANAGER,
                        SUB_SECTOR: el.SUB_SECTOR
                    }
                ))

                let getClassInfos = {
                    "stagingData": saveArea.filter(el => el.checked),
                    "updatedBy": localStorage.getItem('user_id'),
                    "dealType": "Not Rated",
                    "workId": this.$route.params.id ? this.$route.params.id : 0
                }
                this.$store.dispatch('publishNotRatedDeals', getClassInfos);
            },
            addNewRow() {
                HTTP.get('nextClassId')
                    .then(response => {
                        this.newRow.DEAL_ID = response.data;
                        this.columnDefs.push(Object.assign({}, this.newRow)); // imp
                    })
                    .catch(error => {
                        this.$root.$emit('bv::show::modal','errorModal');
                    });
            }
        },
        mounted() {
            this.gridApi = this.gridOptions.api;
        },
        beforeMount() {
            this.gridOptions = {
                components:{
                }
            };
            this.createColumnDefs();
            this.showGrid = true;
            this.gridOptions = {
                
            }
            this.rowSelection = "multiple";
            this.paginationPageSize = 10;
            this.paginationNumberFormatter = params => {
                return "[" + params.value.toLocaleString() + "]";
            };
        },
        components: {
            AgGridVue,
            HeaderInput,
            RatedHeaderInput,
            HeaderCheckbox,
            Checkbox,
            ClassSelect,
            MyInput,
            MyRated
        }
    }
</script>