<template>
    <div class="container">
        <home-button></home-button>
        <div class="my-form search-criteria">
            <div>
                <section-header heading="Search Criteria" section="dealInfo"></section-header>
            </div><!-- End Row -->
            <div class="section-body" v-show="showSection">
                <div>
                    <div class="setMargin row">
                        <my-select-input
                            elementId=""
                            placeholder="DEAL STATUS: "
                            :initialValue="dealStatusInitial"
                            :options="dealDetails"
                            required=""
                            @modelChanged="updateDealStatus"
                        />
                    </div>
                    <div class="form-group row">
                        <div class="form-group col-sm-6">
                            <label for="preSaleDate" class="key">CLOSING DATE - FROM: </label>
                            <date-picker
                                id="closingDateFrom"
                                :value="currentRow.closingDateFrom || initialclosingDateFrom"
                                :config="config"
                                @dp-hide="updateDate($event, currentRow)">
                            </date-picker>
                        </div>

                        <div class="form-group col-sm-6 style-fix-labels">
                            <label for="formGroupExampleInput" class="key">CLOSING DATE - TO: </label>
                            <date-picker
                                id="closingDateTo"
                                :value="currentRow.closingDateTo || initialclosingDateTo "
                                :config="config"
                                @dp-hide="updateDate($event, currentRow)">
                            </date-picker>
                        </div>
                    </div><!-- End Row -->
                    <div class="form-group row">
                        <div class="form-group col-sm-6">
                            <label for="preSaleDate" class="key">PRICING DATE - FROM: </label>
                            <date-picker
                                id="pricingDateFrom"
                                :value="currentRow.pricingDateFrom || initialpricingDateFrom"
                                :config="config"
                                @dp-hide="updateDate($event, currentRow)">
                            </date-picker>
                        </div>

                        <div class="form-group col-sm-6 style-fix-labels">
                            <label for="formGroupExampleInput" class="key">PRICING DATE - TO: </label>
                            <date-picker
                                id="pricingDateTo"
                                :value="currentRow.pricingDateTo || initialPricingDateTo"
                                :config="config"
                                @dp-hide="updateDate($event, currentRow)">
                            </date-picker>
                        </div>
                    </div><!-- End Row -->
                    <div class="form-group row">
                        <my-select-input
                            elementId=""
                            placeholder="MANAGEMENT LINE REGION"
                            :initialValue="mgntLineInitial"
                            required=""
                            :options="managementLineRegion"
                            @modelChanged="updateMgmtRegion"
                        />
                        <my-select-input
                            elementId=""
                            placeholder="MARKET SECTOR"
                            :initialValue="marketSectorInitial"
                            required=""
                            :options="marketSectorNameAll"
                            @modelChanged="updateSectorRegion"
                            />
                    </div><!-- End Row -->
                    <div class="form-group row">
                        <my-select-input
                            elementId=""
                            placeholder="MANAGEMENT LINE"
                            :initialValue="managementLineDropdownInitial"
                            required=""
                            :options="managementLine"
                            @modelChanged="updateMgmt"
                        />
                    </div><!-- End Row -->
                    <!-- Field Error Modal -->
                    <modal :modal="fieldErrors"></modal>
                    <!-- Success Modal -->
                    <modal :modal="success"></modal>
                    <!-- API Error Modal -->
                    <modal :modal="apiError"></modal>
					<!-- nullSearch Modal -->
        			<modal :modal="nullSearch"></modal>
                    <!-- publish Modal -->
        			<modal :modal="publish"></modal>
                    <!-- saved Modal -->
        			<modal :modal="saved"></modal>
                    <!-- dynamic Modal -->
                    <modal :modal="dynamic"></modal>
                </div>
            </div>
        </div>
        <div class="search-button-area">
            <button class="search-btn col-lg-2 button" @click="searchForData">Search</button>
        </div>
		<div class="loading-area" v-if="showRatedTable === 'false' && showSpinner === 'true'">
		 	<loading></loading>
		</div>
        <div class="my-form loading-area" v-if="showRatedTable === 'true' && showRatedResults === 'true'">
            <div class="test-header">
                Page Size:
                <select v-on:change="onPageSizeChanged()" id="page-size">
                    <option value="10" selected="">10</option>
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                </select>
            </div>
            <ag-grid-vue style="height: 500px"
                class="ag-theme-fresh"
                @grid-ready="onReady"
                :gridOptions="gridOptions"
                :columnDefs="columnDefs"
                :rowSelection="rowSelection"
                enableRangeSelection="true"
                :rowData="rowData"
                :enableColResize="true"
                :suppressColumnVirtualisation="true"
                :enableSorting="true"
                :enableFilter="true"
                rowHeight="40"
                headerHeight="40"
                :paginationAutoPageSize="true"
                :pagination="true"
                :enableCellChangeFlash="true"
            >
            </ag-grid-vue>
        </div>
        <div class="search-button " v-if="showRatedTable === 'true' && showRatedResults === 'true'">
            <button class="btn-1 button" @click="saveInStagingArea">Save in Staging Area</button>
            <button class="btn-2 button" @click="publishInStagingArea">Publish</button>
        </div>
    </div>  
</template>

<style lang="scss">
    $color: #4dccbd;

    .search-criteria {
        margin-top: 20px;
    }
    .nested-table {
        display: none;
    }
    .deal-status {
        display: inline;
    }
	.search-button-area {
		margin-top: 4%;
	}
    .cd-1 {
        padding-right: 0px;
    }
    .cd-2 {
        padding-left: 0px;
    }
    .setMargin {
        margin-bottom: 30px;
    }
    .search-btn {
        padding: 12px;
        border: none;
        outline: none;
        border-radius: 4px;
        cursor: pointer;
        margin-bottom: 20px;
    }
	.loading-area {
		margin-top: 2%;
	}
    .nested-table {
        margin-bottom: 30px;
    }
    #selectOption {
        width: 100%;
        padding: 0.375rem 0.75rem;
    }
    .textOverlap {
        line-height: 1.6;
    }
    .forDownIcon {
        position: absolute;
        right: 16px;
        top: 1px;
        padding: 6.2px;
        background-color: #aaa;
    }
    .pricingDate {
        margin-left: 10px;
    }
    .button {
        text-align: center;
        text-decoration: none;
        color: $color;
        background-color: #F5F5F5;
        cursor: pointer;
        font-size: 18px;
        font-weight: 600;
        display: inline-block;
        border-radius: 0.3em;
        transition: all 0.2s ease-in-out;
        position: relative;
        overflow: hidden;
        &:before {
            content: "";
            background-color: rgba(255,255,255,0.5);
            height: 100%;
            width: 3em;
            display: block;
            position: absolute;
            top: 0;
            left: -4.5em;
            transform: skewX(-45deg) translateX(0);
            transition: none;
      }
        &:hover {
            background-color: $color;
            color: #fff;
            border-bottom: 4px solid darken($color, 10%);
            &:before {
                    transform: skewX(-45deg) translateX(13.5em);
                    transition: all 0.5s ease-in-out;
                }
        }
    }
    .modal {
        color: black;
    }
    #app > div > div:nth-child(4) > div.ag-theme-fresh > div > div.ag-root-wrapper-body.ag-layout-normal > div.ag-root.ag-font-style.ag-layout-normal {
        height: 109% !important;
    }
    .search-button {
        margin-top: 10px;
        margin-bottom: 10px
    }
    #app > div > div:nth-child(4) > div > div > div.ag-paging-panel.ag-font-style {
        align-items: center;
        border-top: 1px solid #BDC3C7;
        color: rgba(0, 0, 0, 0.54);
        display: flex;
        height: 32px;
        justify-content: flex-end;
        padding: 0 12px;
    }
    #app > div > div:nth-child(4) > div > div > div.ag-paging-panel.ag-font-style > span.ag-paging-row-summary-panel {
        margin-left: 16px;
    }
    .test-header {
        margin-bottom: 15px;
        text-align: right;
    }
    #app > div > div:nth-child(4) > div.ag-theme-fresh > div > div.ag-paging-panel.ag-font-style {
        margin-top: 22px;
    }    
</style>

<script type="text/javascript">
    import {AgGridVue} from 'ag-grid-vue';
    import RatedHeaderInput from '../tables/Components/RatedHeaderInput.vue';
    import MyInput from '../tables/Components/MyInput.vue';
    import HeaderInput from '../tables/Components/HeaderInput.vue';
    import MyRated from '../tables/Components/MyRated.vue';
    import HeaderCheckbox from '../tables/Components/HeaderCheckbox.vue';
    import ClassSelect from '../tables/Components/ClassSelect.vue';
    import Checkbox from '../tables/Components/Checkbox.vue';
    import {HTTP} from '../../utils/calls';


    export default {
        props: {
            type: {
                type: Boolean
            },
            dealCurrency: {
                //type: Number
            },
            model: {
                type: Object
            },
            flag: {}
        },
        data() {
            return {
                currentRow: {},
                showGrid: false,
                colIds: [],
                dealDetails: [],
                initialclosingDateFrom: '',
                initialclosingDateTo: '',
                initialpricingDateFrom: '',
                initialPricingDateTo: '',
                managementLineRegion: [],
                managementLine: [],
                marketSectorNameAll: [],
                dealStatusInitial: '',
                dealStatusInitialId: '',
                mgntLineInitial: '',
                managementLineDropdownInitial: '',
                marketSectorInitial: '',
                store: {},
                columnDefs: null,
                paginationPageSize: null,
                paginationNumberFormatter: null,
                newRow: {
                    dealId: '',
                    activeFlag: true,
                },
                rowSelection: "multiple",
            }
        },
        computed: {
            config() {
                return this.$store.getters.getDatepickerConfig;
            },
            showRatedResults() {
                return this.$store.getters.showRatedResults;
            },
            rowData() {
                return this.$store.getters.rowData;
            },
            fieldErrors() {
                return this.$store.getters.getModal('fieldErrors');
            },
            success() {
                return this.$store.getters.getModal('success');
            },
            apiError() {
                return this.$store.getters.getModal('apiError');
            },
            dynamic() {
                return  this.$store.getters.getModal('dynamic');
            },
			nullSearch() {
				return this.$store.getters.getModal('nullSearch');
            },
            publish() {
				return this.$store.getters.getModal('publish');
            },
            saved() {
				return this.$store.getters.getModal('saved');
			},
            showSection() {
                return this.$store.getters.showSection('dealInfo');
			},
			showSpinner() {
				return this.$store.getters.showSpinner;
			},
			showRatedTable() {
				return this.$store.getters.showRatedTable;
			}
        },
         created() {
            const workId =  {
                "workId": this.$route.params.id ? this.$route.params.id : 0
            } 
            HTTP.post('/lookupStage', workId)
                .then(response => {
                    this.dealDetails = response.data.lookUpDataDetails.dealStatus.filter(el => el.desc !== 'NOT RATED');
                    this.managementLineRegion = response.data.lookUpDataDetails.managementLineRegion;
                    this.managementLine = response.data.lookUpDataDetails.managementLine;
                    this.marketSectorNameAll = this.removeDuplicates(response.data.lookUpDataDetails.marketSectorNameAll, 'desc');
                    
                    if (Array.isArray(response.data.lookUpDataDetails.searchFilter) && response.data.lookUpDataDetails.searchFilter && this.$route.params.id) {
                        
                        for(var i = 0; i < response.data.lookUpDataDetails.searchFilter.length; i++) {
                        
                            this.dealStatusInitial = response.data.lookUpDataDetails.searchFilter["0"].extraFields.dealStatus !== "" ?response.data.lookUpDataDetails.dealStatus.filter(el => el.id == response.data.lookUpDataDetails.searchFilter["0"].extraFields.dealStatus)[0].desc : '';
                            
                            this.mgntLineInitial = response.data.lookUpDataDetails.searchFilter["0"].extraFields.managementLineRegion !== "" ?response.data.lookUpDataDetails.managementLineRegion.filter(el => el.id == response.data.lookUpDataDetails.searchFilter["0"].extraFields.managementLineRegion)[0].desc : '';

                            this.managementLineDropdownInitial = response.data.lookUpDataDetails.searchFilter["0"].extraFields.managementLine !== "" ?response.data.lookUpDataDetails.managementLine.filter(el => el.id == response.data.lookUpDataDetails.searchFilter["0"].extraFields.managementLine)[0].desc : '';
                            
                            this.marketSectorInitial =  response.data.lookUpDataDetails.searchFilter[0].extraFields.marketSectorName !== "" ? response.data.lookUpDataDetails.marketSectorNameAll.filter(el => el.id == response.data.lookUpDataDetails.searchFilter[0].extraFields.marketSectorName)[0].desc : '';
                            
                            this.initialclosingDateFrom =  response.data.lookUpDataDetails.searchFilter["0"].extraFields.closingDateFrom !== "" ?response.data.lookUpDataDetails.searchFilter["0"].extraFields.closingDateFrom : '';

                                
                            this.initialclosingDateTo = response.data.lookUpDataDetails.searchFilter[0].extraFields.closingDateTo !== "" ?response.data.lookUpDataDetails.searchFilter[0].extraFields.closingDateTo : '';
                                
                            this.initialpricingDateFrom = response.data.lookUpDataDetails.searchFilter[0].extraFields.pricingDateFrom ? response.data.lookUpDataDetails.searchFilter[0].extraFields.pricingDateFrom: '';
                            
                            this.initialPricingDateTo = response.data.lookUpDataDetails.searchFilter[0].extraFields.pricingDateTo !== "" ?response.data.lookUpDataDetails.searchFilter[0].extraFields.pricingDateTo: '';

                            this.store.mgmtLineRegion =  response.data.lookUpDataDetails.searchFilter["0"].extraFields.managementLineRegion
                            this.store.managementLine = response.data.lookUpDataDetails.searchFilter["0"].extraFields.managementLine;
                            this.store.marketSector = response.data.lookUpDataDetails.searchFilter["0"].extraFields.marketSectorName;
                            this.store.dealStatus =  response.data.lookUpDataDetails.searchFilter["0"].extraFields.dealStatus;
                            this.store.closingDateStart =  response.data.lookUpDataDetails.searchFilter["0"].extraFields.closingDateFrom;
                            this.store.closingDateEnd = response.data.lookUpDataDetails.searchFilter["0"].extraFields.closingDateTo;
                            this.store.priceDateStart = response.data.lookUpDataDetails.searchFilter["0"].extraFields.pricingDateFrom;
                            this.store.priceDateEnd = response.data.lookUpDataDetails.searchFilter["0"].extraFields.pricingDateTo;
                            
                        }
                    }
                })
                .catch(error => {
                    console.log("error", error.response);
                })

            if(this.$route.params.id) {

                this.$store.dispatch('fetchRatedResults', workId);
                //this.showRatedTable = 'true';
            }
        },

        methods:  {
            onReady(params) {
                this.gridOptions.columnApi.getAllColumns().forEach((column) => {
                    this.colIds.push(column.colId);
                });

                params.api.paginationGoToPage(4);
            },
            onPageSizeChanged(newPageSize) {
                var value = document.getElementById("page-size").value;
                this.gridOptions.api.paginationSetPageSize(Number(value));
            },
            resizeColumns() {
                this.gridOptions.columnApi.autoSizeColumns(this.colIds);
            },
            removeDuplicates(sectorName, prop) {
                var filteredSector = [];
                var lookupObject  = {};

                for(var i in sectorName) {
                    lookupObject[sectorName[i][prop]] = sectorName[i];
                }

                for(i in lookupObject) {
                    filteredSector.push(lookupObject[i]);
                }
                return filteredSector;
            }, 
            updateDate(event, row) {
                const dateObj = {
                    object: row,
                    key: event.target.id,
                    value: event.target.value
                };


                if(dateObj.key === 'closingDateFrom') {
                    this.store.closingDateStart = dateObj.value;
                } else if (dateObj.key === 'closingDateTo') {
                    this.store.closingDateEnd = dateObj.value;
                } else if (dateObj.key === 'pricingDateFrom') {
                    this.store.priceDateStart = dateObj.value;
                } else if (dateObj.key === 'pricingDateTo') {
                    this.store.priceDateEnd = dateObj.value;
                }
            },
            updateDropdown(event, row) {
               // this.$store.commit('updateDropdown', event);
            },
            updateDealStatus(event, row) {
                //this.$store.commit('updateDropdown', event);
                this.store.dealStatus = event.target.value;
            },
            updateMgmtRegion(event, row) {
                this.store.mgmtLineRegion = event.target.value;
            },
            updateMgmt(event, row) {
                this.store.managementLine = event.target.value;
            },
            updateSectorRegion(event, row) {
                this.store.marketSector = event.target.value;
            },
            searchForData() {
                if(this.store.dealStatus !== undefined || this.store.mgmtLineRegion !== undefined || this.store.marketSector !== undefined || this.store.closingDateStart !== undefined ||  this.store.closingDateEnd !== undefined || this.store.priceDateStart  !== undefined || this.store.priceDateEnd !== undefined ||  this.store.managementLine !== undefined) {
                   // this.showRatedTable = 'true';
                    this.$store.dispatch('fetchRatedResults', this.store);
                }
            },
            saveInStagingArea() {
                var saveArea = [];
                this.gridOptions.rowData.map(el => saveArea.push(
                    {
                        checked: el.checked,
                        className: el.className,
                        dbrsRated: String(el.dbrsRated).toLowerCase() === 'y' ? true :  String(el.dbrsRated).toLowerCase() === 'n' ? false : String(el.dbrsRated).toLowerCase(),
                        dealId: el.dealId,
                        dealName: el.dealName,
                        fitchRated: String(el.fitchRated).toLowerCase() === 'y' ? true :  String(el.fitchRated).toLowerCase() === 'n' ? false : String(el.fitchRated).toLowerCase(),
                        id: el.id,
                        includeInReport: String(el.includeInReport).toLowerCase() === 'y' ? true :  String(el.includeInReport).toLowerCase() === 'n' ? false : String(el.includeInReport).toLowerCase(),
                        moodysRated: String(el.moodysRated).toLowerCase() === 'y' ? true :  String(el.moodysRated).toLowerCase() === 'n' ? false : String(el.moodysRated).toLowerCase(),
                        mrngStarRated: String(el.mrngStarRated).toLowerCase() === 'y' ? true :  String(el.mrngStarRated).toLowerCase() === 'n' ? false : String(el.mrngStarRated).toLowerCase(),
                        krollRated: String(el.krollRated).toLowerCase() === 'y' ? true :  String(el.krollRated).toLowerCase() === 'n' ? false : String(el.krollRated).toLowerCase(),
                        pricingDate: el.pricingDate,
                        registration: el.registration,
                        scopeRated: String(el.scopeRated).toLowerCase() === 'y' ? true :  String(el.scopeRated).toLowerCase() === 'n' ? false : String(el.scopeRated).toLowerCase(),
                        snpRated: String(el.snpRated).toLowerCase() === 'y' ? true :  String(el.snpRated).toLowerCase() === 'n' ? false : String(el.snpRated).toLowerCase(),
                    }
                ))

                let loadNextView = {
                   "stagingData": saveArea,
                   "updatedBy": localStorage.getItem('user_id'),
                   "dealStatus": this.store.dealStatus,
                   "mgmtLineRegion": this.store.mgmtLineRegion,
                   "managementLine": this.store.managementLine,
                   "marketSector": this.store.marketSector,
                   "closingDateStart": this.store.closingDateStart,
                   "closingDateEnd": this.store.closingDateEnd,
                   "priceDateStart": this.store.priceDateStart,
                   "priceDateEnd": this.store.priceDateEnd,
                   "dealType": "Rated",
                   "workId": this.$route.params.id ? this.$route.params.id : 0
                }
                this.$store.dispatch('sendRatedDeals', loadNextView);
            },
            publishInStagingArea() {
                var saveArea = [];
                this.gridOptions.rowData.map((el, i) => saveArea.push(
                    {
                        checked: el.checked,
                        index: i,
                        className: el.className,
                        dbrsRated: String(el.dbrsRated).toLowerCase() === 'y' ? true :  String(el.dbrsRated).toLowerCase() === 'n' ? false : String(el.dbrsRated).toLowerCase(),
                        dealId: el.dealId,
                        dealName: el.dealName,
                        fitchRated: String(el.fitchRated).toLowerCase() === 'y' ? true :  String(el.fitchRated).toLowerCase() === 'n' ? false : String(el.fitchRated).toLowerCase(),
                        id: el.id,
                        includeInReport: String(el.includeInReport).toLowerCase() === 'y' ? true :  String(el.includeInReport).toLowerCase() === 'n' ? false : String(el.includeInReport).toLowerCase(),
                        moodysRated: String(el.moodysRated).toLowerCase() === 'y' ? true :  String(el.moodysRated).toLowerCase() === 'n' ? false : String(el.moodysRated).toLowerCase(),
                        mrngStarRated: String(el.mrngStarRated).toLowerCase() === 'y' ? true :  String(el.mrngStarRated).toLowerCase() === 'n' ? false : String(el.mrngStarRated).toLowerCase(),
                        krollRated: String(el.krollRated).toLowerCase() === 'y' ? true :  String(el.krollRated).toLowerCase() === 'n' ? false : String(el.krollRated).toLowerCase(),
                        pricingDate: el.pricingDate,
                        registration: el.registration,
                        scopeRated: String(el.scopeRated).toLowerCase() === 'y' ? true :  String(el.scopeRated).toLowerCase() === 'n' ? false : String(el.scopeRated).toLowerCase(),
                        snpRated: String(el.snpRated).toLowerCase() === 'y' ? true :  String(el.snpRated).toLowerCase() === 'n' ? false : String(el.snpRated).toLowerCase(),
                    }
                ))
                let getClassInfos = {
                    "stagingData": saveArea.filter(el => el.checked),
                    "updatedBy": localStorage.getItem('user_id'),
                    "dealType": "Rated",
                    "workId": this.$route.params.id ? this.$route.params.id : 0
                }
                this.$store.dispatch('publishRatedDeals', getClassInfos);
            }
        },
        mounted() {
            this.gridApi = this.gridOptions.api;
            this.gridColumnApi = this.gridOptions.columnApi;
        },
        beforeMount() {
            this.columnDefs = [
                {
                    colId: "checked",
                    width:40,
                    headerComponentParams: { name: '', flag: 'RatedDeals'},
                    headerComponentFramework: HeaderCheckbox,
                    cellRendererFramework: Checkbox,
                },
                {
                    colId: 'dealId',
                    field:'dealId',
                    width: 140,
                    headerComponentParams: { name: 'Deal Id'},
                    cellRendererFramework: MyRated,
                },
                {
                    colId: 'dealName',
                    field:'dealName',
                    width: 140,
                    headerComponentParams: { name: 'Deal Name'},
                    cellRendererFramework: MyRated
                },
                {
                    colId: 'className',
                    field:'className',
                    width: 140,
                    headerComponentParams: { name: 'Class Name'},
                    cellRendererFramework: MyRated,
                },
                
                {
                    colId: 'fitchRated',
                    field:'fitchRated',
                    width: 140,
                    headerComponentParams: { name: 'Fitch'},
                    cellRendererFramework: MyInput,
                    headerComponentFramework: HeaderInput,
                    editable: true
                },
                {
                    colId: 'moodysRated',
                    field:'moodysRated',
                    width: 140,
                    headerComponentParams: { name: 'Moodys'},
                    cellRendererFramework: MyInput,
                    headerComponentFramework: HeaderInput,
                    editable: true
                },
                {
                    colId: 'snpRated',
                    field:'snpRated',
                    width: 140,
                    headerComponentParams: { name: 'S&P'},
                    cellRendererFramework: MyInput,
                    headerComponentFramework: HeaderInput,
                    editable: true
                },
                {
                    colId: 'dbrsRated',
                    field:'dbrsRated',
                    width: 140,
                    headerComponentParams: { name: 'DBRS'},
                    headerComponentFramework: HeaderInput,
                    cellRendererFramework: MyInput,
                    editable: true
                },
                {
                    colId: 'mrngStarRated',
                    field:'mrngStarRated',
                    width: 140,
                    headerComponentParams: { name: 'Morningstar'},
                    cellRendererFramework: MyInput,
                    headerComponentFramework: HeaderInput,
                    editable: true
                },
                {
                    colId: 'krollRated',
                    field:'krollRated',
                    width: 140,
                    headerComponentFramework: HeaderInput,
                    headerComponentParams: { name: 'Kroll'},
                    cellRendererFramework: MyInput,
                    editable: true
                },
                {
                    colId: 'scopeRated',
                    field:'scopeRated',
                    width: 140,
                    headerComponentFramework: HeaderInput,
                    headerComponentParams: { name: 'Scope'},
                    cellRendererFramework: MyInput,
                    editable: true
                },
                {
                    colId: 'includeInReport',
                    field:'includeInReport',
                    width: 140,
                    headerComponentParams: { name: 'Include in MS'},
                    cellRendererFramework: MyInput,
                },
                {
                    colId: 'pricingDate',
                    field:'pricingDate (YYYY-MM-DD)',
                    width: 140,
                    headerComponentParams: { name: 'Pricing Date'},
                    cellRendererFramework: MyInput
                },
                
            ];

            this.gridOptions = {
                
            }
            this.rowSelection = "multiple";
            this.paginationPageSize = 10;
            this.paginationNumberFormatter = params => {
                return "[" + params.value.toLocaleString() + "]";
            };
           // this.rowData = this.$store.getters.getRatedResults;
        },
        components: {
            AgGridVue,
            RatedHeaderInput,
            HeaderInput,
            HeaderCheckbox,
            Checkbox,
            ClassSelect,
            MyInput,
            MyRated
        }
    }
</script>