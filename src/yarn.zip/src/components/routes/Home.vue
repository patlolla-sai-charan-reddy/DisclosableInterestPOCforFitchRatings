<style scoped>
    .form-home {
        margin-top: 200px;
        margin-left: auto;
        margin-right: auto;
        width:576px;
        min-height:200px;
        text-align: center;
    }
    .slider {
        transform: translate(0, -100px);
        transition: 2s cubic-bezier(.25,.8,.25,1);
    }
    .my-form {
        box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
    }
    h2, h6, h4 {
        color: #4D4D4D;
        letter-spacing: 0
    }
    h2 {
        margin-bottom: 0;
        font-size: 1.8rem;
        font-weight: 300;
    }
    h4  {
        font-size: 1rem;
        font-weight: 700;
    }
    h6 {
        margin-bottom: 2rem;
        font-weight: 400;
    }
    .form-text {
        font-weight: 700;
    }
    .search-deals-container {
        padding: 0;
    }
    .has-icon-right>.fa {
        display: inline-block;
        font-size: 1rem;
        text-align: center;
        color: #DBDBDB;
        pointer-events: none;
        position: absolute;
        top: 10px;
        z-index: 4;
        right: 60px;
    }
    .search-deals {
        display: inline-block;
        width: 100%;
    }
    .fa-search {
        font-size: 1.5rem;
    }
    .include-active {
        margin-top: 0.5rem;
        text-align: left;
    }
    .deal-text {
        margin-bottom: 0;
        font-weight: 400;
    }
    .new-deal {
      cursor: pointer;
      color: #4F7580;
      font-size: 0.8rem;
      font-weight: 700;
      text-decoration: none;
    }
    .fade-enter-active {
        transition: opacity 2s;
    }
    .fade-enter, .fade-leave-to, .fade-leave-active {
        opacity: 0;
    }
    li {
        cursor: pointer;
    }
    .row-active {
        background-color: #0275d8;
        color: #FFFFFF;
    }
    .row-disabled {
        pointer-events: none;
        cursor: not-allowed;
    }
    .welcome-label {
        margin-bottom: 25px;
    }
    .logged-role {
        margin-bottom: 25px;
    }
    .landing-buttons {
        margin-left: auto;
        margin-right: auto;
        width: 100%;
        min-height: 267px;
        text-align: center;
        color: black;
    }
    .landing-button-1 .btn-11, .landing-button-2 .btn-22 {
        height: 166px;
        background: black;
        opacity: 0.3;
        color: white;
        padding: 10px;
        border: none;
        cursor: pointer;
    }
    .landing-button-1 .btn-11:hover, .landing-button-2 .btn-22:hover {
        opacity: 0.8;
        transform: scale(1);
        transition:all 0.2s;
    }
    .create-structure {
        padding-bottom: 3%;
        background: lightgray;
        opacity: 0.4;
        color: black;
        opacity: 0.5;
        cursor: pointer;
        font-weight: 600;
    }
    .create-structure:hover {
        opacity: 0.9;
        transition: all 0.5s;
    }
    .search-space {
        margin-right: 20px;
        margin-left: 35px;
    }
    .for-label {
        text-align: left;
        margin-top: 19px;
        font-size: 14px;
        margin-bottom: 85px;
    }
    .icon {
        float: right;
        margin-right: 20px;
        font-size: 40px;
    }
</style>

<template>
    <div class="container form-home my-form">
        <!-- Banner -->
        <banner></banner>
        <div class="landing-buttons">
            <h2 class="welcome-label">WELCOME, {{ user }}</h2>
            <h6 class="logged-role">You are logged in as <span class="fitch-red key">{{ userRole }}</span> user.</h6>
            <div class="landing-area row">
                <div class="create-structure search-space col-5" @click="loadSearch()">
                    <p class="for-label">LIVE PRODUCTION DEALS</p>
                    <i class="fa fa-chevron-circle-right icon" aria-hidden="true"></i>
                </div>
                <div class="create-structure col-5" @click="loadNextViews()">
                    <p class="for-label">BULK ENTRY / STAGING AREA</p>
                    <i class="fa fa-chevron-circle-right icon" aria-hidden="true"></i>
                </div>
            </div>

        </div>    
    </div>
</template>
<script>
    import SearchResults from '../sections/SearchResults.vue';
    import {AgGridVue} from 'ag-grid-vue';
    import MyRated from '../tables/Components/MyRated.vue';
    import RatedHeaderInput from '../tables/Components/RatedHeaderInput.vue';
    import {HTTP} from '../../utils/calls';
    import {router} from '../../utils/router.js';

    export default {
        data() {
            return {
                //showResults: "",
                includeInactive: false,
                pager: {
                    term: "",
                    total: 0,
                    pages: 0,
                    currentPage: 0,
                    last:0
                },
            }
        },
        computed: {
            user() {
                return this.$store.getters.getUser.toUpperCase();
            },
            userRole() {
                return this.$store.getters.getUserRole;
            },
        },
        methods: {

            loadSearch() {
                this.$store.dispatch('fetchStagingArea', 'loadSearchView');
            },
            loadNextViews() {     
                this.$store.dispatch('fetchStagingArea', 'loadNextView');
            },
        },
        components: {
            'search-results': SearchResults,
            RatedHeaderInput
        }
    }
</script>