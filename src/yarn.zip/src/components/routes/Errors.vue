<style type="text/css" scoped>
.errors {
    margin: 75px auto;
    width: 50%;
}
a {
    cursor: pointer;
    color: #4F7580;
    font-weight: 600;
}
a:hover {
    color: #4F7580;
    text-decoration: none;
}
</style>

<template>
    <div class="my-form errors">
        <div v-if="status === 401">
            <p>Please login.</p>
        </div>
        <div v-if="status === 403">
            <p>You do not have permission to use this tool. Please contact your manager to request access through Hitachi.</p>
        </div>
        <div v-if="status === 404">
            <p>This page doesn't exist.</p>
        </div>
        <div v-if="status === 500">
            <p>Sorry, try again later.</p>
        </div>
        Go to <a href="/home">Marketshare Home</a>
    </div>
</template>

<script type="text/javascript">
    export default {
        data() {
            return {

            }
        },
        computed: {
            status() {
                return parseInt(this.$route.params.status);
            }
        },
        mounted() {
            if (this.status === 403) {
                localStorage.clear();
            }
        }
    }
</script>