<style type="text/css"></style>
<template>
    <div class="container">
        <home-button></home-button>
        <!-- Banner -->
        <banner></banner>
        <!-- Loaded -->
        <div v-if="ready">
            <my-form :formData="formData"></my-form>

            <!-- Form Buttons -->
            <div class="row margin-bottom">
                <div class="col-sm-6">
                    <router-link tag="button" class="btn btn-lg btn-form" to="/home">
                        Back to Search
                    </router-link>
                </div>
                <div class="col-sm-6">
                    <button class="btn btn-lg btn-form pull-right" @click="submit">Save</button>
                </div>
            </div><!--End row -->
        </div>

        <!-- Loading -->
        <loading v-else></loading>
    </div><!--END New Deal Container -->
</template>
<script type="text/javascript">
    import axios from 'axios';
    import {HTTP} from '../../utils/calls';
    export default {
        props: [],
        data() {
            return {
                dealSubmitted: false,
                emptyForm: {
                    dealInfo: {
                        actualMaturityDate: null,
                        activeFlag: null,
                        agentId: null,
                        analysts: [],
                        cartInfos: [],
                        classInfos: [],
                        closingDate: null,
                        collateralType: null,
                        collateralTypeId: null,
                        comments: null,
                        countryOfAssets: null,
                        countryOfAssetsId: null,
                        createdBy: null,
                        createdByGWC: null,
                        dealId: null,
                        dealIssuanceCurrency: null,
                        dealIssuanceCurrencyId: null,
                        dealName: null,
                        dealSize: "",
                        dealStatus: null,
                        dealStatusId: null,
                        dealStructure: null,
                        dealStructureId: null,
                        endOfRevolvingPeriod: null,
                        feeLetterBackDate: null,
                        firstPaymentDate: null,
                        fitchRatedAmount: "",
                        id: null,
                        includeInReport: true,
                        issuerEntityCountry: null,
                        issuerEntityCountryId: null,
                        issuerId: null,
                        issuerName: null,
                        issuerNameForRule17g5: null,
                        issuerTransactionUrl: null,
                        launchDate: null,
                        legalMaturityDate: null,
                        managementLine: null,
                        managementLineId: null,
                        managementLineRegion: null,
                        managementLineRegionId: null,
                        marketSectorName: null,
                        marketSectorNameId: null,
                        maxEndOfRevolvingPeriod: null,
                        multiOriginatorDeal: false,
                        partiesToDeal: [],
                        portfolioType: null,
                        portfolioTypeId: null,
                        preSalePublishedDate: null,
                        pricingDate: null,
                        purpose: null,
                        purposeId: null,
                        rampUpClosing: null,
                        reasonNotRated: null,
                        reasonNotRatedComment: null,
                        reasonNotRatedId: null,
                        reasonPreSaleNotPublished: null,
                        reasonPreSaleNotPublishedId: null,
                        registration: null,
                        registrationId: null,
                        replacementDealId: null,
                        reportingOffice: null,
                        reportingOfficeId: null,
                        requiresSurveillance: false,
                        secRule17g5Eligible: null,
                        series: null,
                        updatedBy: null,
                        updatedByGWC: null,
                        workingName: null
                    }, //End dealInfo
                    classInfo: {
                        currency: [],
                        jurisdiction: [],
                        rows: []
                    },
                    lookUpDetails: {},
                    partiesToDeal: {
                        companyRole: [],
                        rows: []
                    }
                }
            }
        },
        computed: {
            ready() {
                return this.$store.getters.getFormsStatus;
            },
            formData() {
                return this.$store.state.formData;
            },
            userId() {
                return this.$store.getters.getUserId;
            },
            fieldErrors() {
                return this.$store.getters.getModal('fieldErrors');
            },
            success() {
                return this.$store.getters.getModal('success');
            },
            apiError() {
                return this.$store.getters.getModal('apiError');
            }
        },
        created() {
            //reset Form Data
            this.$store.commit('resetFormData', this.emptyForm);

            this.$store.dispatch('fetchNewDeal');

            /*const getNextDealId = function() {
                return HTTP.get('nextDealId');
            }.bind(this);
            const getLookup = function() {
                return HTTP.get('lookup');
            }.bind(this);

            axios.all([getNextDealId(), getLookup()])
                .then(axios.spread((dealId, lookup) => {
                    //dealId
                    this.$store.state.formData.dealInfo.id = dealId.data.substring(4);
                    this.$store.state.formData.dealInfo.dealId = dealId.data;
                    this.$store.state.formData.dealInfo.dealStatus = "NOT RATED";
                    this.$store.state.formData.dealInfo.dealStatusId = 5;

                    //lookup
                    this.$store.state.formData.lookUpDetails = lookup.data.lookUpDataDetails;
                    this.$store.state.formData.classInfo.bondType = lookup.data.lookUpDataDetails.classBondType;
                    this.$store.state.formData.classInfo.classType = lookup.data.lookUpDataDetails.classType;
                    this.$store.state.formData.classInfo.currency = lookup.data.lookUpDataDetails.dealIssuanceCurrency;
                    this.$store.state.formData.classInfo.jurisdiction = lookup.data.lookUpDataDetails.jurisdiction;
                    this.$store.state.formData.classInfo.registration = lookup.data.lookUpDataDetails.registration;
                    this.$store.state.formData.partiesToDeal.companyRole = lookup.data.lookUpDataDetails.companyRole;
                    this.$store.state.formData.lookUpDetails.marketSectorName = lookup.data.lookUpDataDetails.marketSectorNameAll;

                    //render the form
                    this.ready = true;
                }))
                .catch(error => {
                    if (error.response.status === 401) {
                        this.$router.push('/api/login');
                    } else {
                        this.$router.push({ name: 'error', params: { status: error.response.status }})
                    }
                })*/
        },
        mounted() {
            this.$bus.$on('field-errors', (result) => {
                this.$store.state.dontSubmit = true;
            });
        },
        methods: {
            submit() {
                this.$store.commit('updateNewDealModelSave');

                //Validate Deal fields
                this.$bus.$emit('veeValidate');

                this.$store.dispatch('storeDeal', true);

                /*//validate ClassInfos
                this.$store.state.formData.dealInfo.classInfos.forEach(function(item) {
                    if (!item.name || !item.registrationId || !item.originalBalance || !item.currencyId || !item.jurisdictionId || !item.pricingDate) {
                        this.$store.state.classInfoErrors = true;
                        return;
                    }
                }.bind(this));

                //validate entire form
                if (this.$store.state.dontSubmit || this.$store.state.classInfoErrors) {
                    this.$store.state.dontSubmitClass = true;
                    this.$refs.invalidFieldsModal.show()
                } else {
                    //parties
                    this.$store.commit('processPartieForSave');

                    HTTP.put('deals', this.$store.state.formData.dealInfo)
                        .then(response => {
                            //this.dealSubmitted = true;
                            //redirect to new deal
                            this.$router.push({ path: '/deals/' + this.$store.state.formData.dealInfo.dealId })
                        })
                        .catch(error => {
                            //this.$root.$emit('bv::show::modal','errorModal');
                            this.$refs.errorModal.show()
                        });
                }

                //reset dontSubmit
                this.$store.state.dontSubmit = false;
                this.$store.state.classInfoErrors = false;*/
            }
        },
        components: {
        }
    }
</script>