<style type="text/css" scoped>
    div {
        margin: 75px auto;
        width: 50%;
    }
</style>
<template>
    <div class="my-form">
        <h1>Hello!</h1>
    </div>
</template>