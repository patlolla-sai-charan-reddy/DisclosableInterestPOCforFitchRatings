<template>
<div class="container">
        <home-button></home-button>
        <div class="selection-section">
            <div class="next-view-info form-home my-form">
                <h4 data-v-5676b09e="" class="col-sm-10 section-heading">BULK ENTRY - STAGING AREA</h4>
                <div class="section-body">           
                    <div class="landing-area row">
                        <div class="create-structure search-space col-5" @click="updateRated()">
                            <p class="for-label">RATED DEALS</p>
                            <i class="fa fa-chevron-circle-right icon" aria-hidden="true"></i>
                        </div>
                        <div class="create-structure col-5" @click="updateNonRated()">
                            <p class="for-label">UNRATED / NEW DEALS</p>
                            <i class="fa fa-chevron-circle-right icon" aria-hidden="true"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="loading-area" v-if="showProgress === 'true'">
            <loading></loading>
        </div>
        <div class="bulkEntry-table" v-if="showProgress === 'false'">
            <div class="my-form forBulkEntry">
                <section-header heading="MY UNPUBLISHED WORK IN PROGRESS DATA" section="publishedInfo"></section-header>
                <div class="section-body">
                    <v-client-table
                        :data="rowData"
                        v-show="showSection"
                        :columns="columns2"
                        :options="options"
                        @row-click="navigate"
                        @limit="storeLimit"
                        @pagination="storePageNumber"
                        ref="searchResultsTable">
                            <span slot="id" slot-scope="props">{{ props.row.id }}</span>
                            <span slot="workId" slot-scope="props">{{ props.row.workId }}</span>
                            <span slot="createdBy" slot-scope="props">{{ props.row.createdBy }}</span>
                            <span slot="updatedBy" slot-scope="props">{{ props.row.updatedBy }}</span>
                            <span slot="createdTime" slot-scope="props">{{ props.row.createdTime }}</span>
                            <span slot="updatedTime" slot-scope="props">{{ props.row.updatedTime }}</span>
                            <span slot="dealType" slot-scope="props">{{ props.row.dealType }}</span>
                    </v-client-table>
                </div>
            </div>
        </div>
        <div class="bulkEntry-table" v-if="showProgress === 'false'">
            <div class="my-form forBulkEntry">
                <section-header heading="MY PUBLISHED WORK" section="publishedCompletedInfo"></section-header>
                <div class="section-body">
                    <v-client-table
                        :data="rowCompletedData"
                        v-show="showCompleted"
                        :columns="columns2"
                        :options="options"
                        @row-click="navigatePublished"
                        @limit="storeLimit"
                        @pagination="storePageNumber"
                        ref="searchResultsTable">
                            <span slot="id" slot-scope="props">{{ props.row.id }}</span>
                            <span slot="workId" slot-scope="props">{{ props.row.workId }}</span>
                            <span slot="createdBy" slot-scope="props">{{ props.row.createdBy }}</span>
                            <span slot="updatedBy" slot-scope="props">{{ props.row.updatedBy }}</span>
                            <span slot="createdTime" slot-scope="props">{{ props.row.createdTime }}</span>
                            <span slot="updatedTime" slot-scope="props">{{ props.row.updatedTime }}</span>
                            <span slot="dealType" slot-scope="props">{{ props.row.dealType }}</span>
                    </v-client-table>
                </div>
            </div>
        </div>
    </div>
</template>

<style scoped>
    .welcome-label {
        color: #FFF;
        margin-bottom: 25px;
    }
    .logged-role {
        color: #FFF;
        margin-bottom: 25px;
    }
    .landing-buttons {
        margin-left: auto;
        margin-right: auto;
        width: 100%;
        min-height: 267px;
        text-align: center;
        color: black;
    }
    .loading-area {
        margin-top: 5%;
    }
    .landing-button-1, .landing-button-2 {
        display:inline;
    }
    .next-view-info {
        color:black
    }
    .selection-section {
        width: 50%;
        margin: 0 auto;
        margin-top: 5%;
    }
    .bulkEntry-table {
        margin-top: 5%;
    }
    .search-results-row, .search-results-row > label {
        cursor: pointer;
    }
    tr.search-results-row:hover {
        background-color: rgba(204, 204, 204, 0.5); /*#CCC*/
    }
    .section-heading {
        font-size: 1.5rem;
        font-weight: 300;
        color: #000;
    }
    .landing-buttons {
        margin-left: auto;
        margin-right: auto;
        width: 100%;
        min-height: 267px;
        text-align: center;
        color: black;
    }
    .landing-button-1 .btn-11, .landing-button-2 .btn-22 {
        height: 166px;
        background: black;
        opacity: 0.3;
        color: white;
        border: none;
        cursor: pointer;
        min-width: 25px;
    }
    .landing-button-1 .btn-11 {
        padding: 50px;
    }
    .landing-button-2 .btn-22 {
        padding: 10px;
    }
    .landing-button-1 .btn-11:hover, .landing-button-2 .btn-22:hover {
        opacity: 0.8;
        transform: scale(1);
        transition:all 0.2s;
    }
    .create-structure {
        padding-bottom: 3%;
        background: lightgray;
        opacity: 0.4;
        color: black;
        opacity: 0.5;
        cursor: pointer;
        font-weight: 600;
    }
    .create-structure:hover {
        opacity: 0.9;
        transition: all 0.5s;
    }
    .search-space {
        margin-right: 25px;
        margin-left: 25px;
    }
    .for-label {
        text-align: left;
        margin-top: 19px;
        font-size: 14px;
        margin-bottom: 85px;
    }
    .icon {
        float: right;
        margin-right: 20px;
        font-size: 40px;
    }
</style>

<script>
    import SearchResults from '../sections/SearchResults.vue';
    import MyRated from '../tables/Components/MyRated.vue';
    import RatedHeaderInput from '../tables/Components/RatedHeaderInput.vue';
    import {HTTP} from '../../utils/calls';
    import {router} from '../../utils/router.js';

    export default {
        data() {
            return {
                //showResults: "",
                includeInactive: false,
                pager: {
                    term: "",
                    total: 0,
                    pages: 0,
                    currentPage: 0,
                    last:0
                },
                columnDefs: null,
                showProgress: 'false',
                rowData: [],
                rowCompletedData: [],
                columns: [
                    {
                      label: 'ID',
                      field: 'id',
                      type: 'number',
                    },
                    {
                      label: 'Work Id',
                      field: 'workId'
                    },
                    {
                      label: 'Created By',
                      field: 'createdBy'
                    },
                    {
                      label: 'Updated By',
                      field: 'updateddBy'
                    },
                    {
                        label: 'Created Time',
                        field: 'createdTime',
                        type: 'date',
                        inputFormat: 'YYYY-MM-DD',
                        outputFormat: 'DD-MMM-YYYY',
                    },
                    {
                        label: 'Updated Time',
                        field: 'updatedTime',
                        type: 'date',
                        inputFormat: 'YYYY-MM-DD',
                        outputFormat: 'DD-MMM-YYYY',
                    },
                    {
                        label: 'Deal Type',
                        field: 'dealType'
                    }
                ],
                columns2: ['id', 'workId', 'createdBy', 'updatedBy', 'createdTime', 'updatedTime', 'dealType'],
                options: {
                    skin: 'table-bordered',
                    headings: {
                        id: 'ID',
                        workId: 'Work ID',
                        createdBy: 'Created By',
                        updatedBy: 'Updated By',
                        createdTime: 'Created Time',
                        updatedTime: 'Updated Time',
                        dealType: 'Deal Type'
                    },
                    filterable: false,
                    sortIcon: {
                        base:'fa',
                        up:'fa-caret-up',
                        down:'fa-caret-down',
                        is:''
                    }
                    //sortable: ['dealId', 'dealName', 'dealStatus', 'closingDate', 'includeInReport']
                }
            }
        },
        computed: {
            showRated() {
                return this.$store.getters.showRated;
            },
            showNonRated() {
                return this.$store.getters.showNonRated;
            },
            showStagingArea() {
                return this.$store.getters.showStagingArea;
            },
            recordsPerPage() {
                return this.$store.getters.getSearchPageLimit;
            },
            pageNumber() {
                return this.$store.getters.getSearchPageNumber;
            },
            showSection() {
                return this.$store.getters.showSection('publishedInfo');
            },
            showCompleted() {
                return this.$store.getters.showSection('publishedCompletedInfo');
            }
        },
        mounted() {
            if (this.pageNumber) {
                this.$refs.searchResultsTable.setLimit(this.recordsPerPage);
                this.$refs.searchResultsTable.setPage(this.pageNumber);
            }
        },
        watch: {
            pageNumber() {
                this.$refs.searchResultsTable.setPage(this.pageNumber);
            }
        },
        methods: {
            updateRated() {
                this.$store.dispatch('fetchStagingArea', 'updateRated');
            },
            updateNonRated() {
                this.$store.dispatch('fetchStagingArea', 'loadNonrated');
            },
            navigate(event) {
                this.$router.push({ path: '/bulkupdate/' + event.row.dealType.toLowerCase().replace('not rated', 'unrated') + '/' + event.row.workId})
            },
            navigatePublished(event) {
                this.$router.push({ path: '/bulkupdate/' + event.row.dealType.toLowerCase().replace('not rated', 'unrated') + '/' + event.row.workId + '/published'})
            },
            storeLimit(event) {
                this.$store.commit('storeSearchPageLimit', event);
            },
            storePageNumber(event) {
                this.$store.commit('storeSearchPageNumer', event);
            },
        },
        created() {
            
        },
        mounted() {
            this.showProgress = 'true';
            HTTP.get('/fetchWorkDetails')
                .then(response => {
                    
                    if(Array.isArray(response.data) && response.data.length === 0) {
                        this.showTable = false;
                        this.showProgress = 'false';
                    } else {
                        this.showTable = true;
                        let getDetails = response.data;
                        let captureDetails = [];

                        getDetails.map((el, i) => {
                            captureDetails.push({
                                id: i + 1,
                                workId: el.workId,
                                createdBy: el.createdBy,
                                updatedBy: el.updatedBy,
                                createdTime: el.createdTime,
                                updatedTime: el.updatedTime,
                                dealType: el.dealType
                            })
                        })
                        this.rowData = captureDetails;
                        this.showProgress = 'false';
                    }
                })
                .catch(error => {
                    this.showProgress = 'false';
                    commit('onApiError', error);
                })
            
            HTTP.get('/getPubDeals')
                .then(response => {
                    
                    if(Array.isArray(response.data) && response.data.length === 0) {
                        this.showTable = false;
                        this.showProgress = 'false';
                    } else {
                        this.showTable = true;
                        let getDetails = response.data;
                        let captureDetails = [];

                        getDetails.map((el, i) => {
                            captureDetails.push({
                                id: i + 1,
                                workId: el.workId,
                                createdBy: el.createdBy,
                                updatedBy: el.updatedBy,
                                createdTime: el.createdTime,
                                updatedTime: el.updatedTime,
                                dealType: el.dealType
                            })
                        })
                        this.rowCompletedData = captureDetails;
                        this.showProgress = 'false';
                    }
                })
                .catch(error => {
                    this.showProgress = 'false';
                    commit('onApiError', error);
                })
        },
        beforeMount() {
           // this.rowData = this.$store.getters.getRatedResults;
        },
        components: {
            'search-results': SearchResults,
            MyRated,
            RatedHeaderInput
        }
    }
</script>