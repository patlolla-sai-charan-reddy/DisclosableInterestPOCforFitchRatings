<style src="../css/style.css"/>
<template>
    <div id="app">
        <router-view></router-view>
    </div>
</template>

<script>
    import Auth from '../utils/Auth';
    export default {
        created() {
            if (this.$router.currentRoute.name !== "hello") {

                //Auth.login();
                this.$store.dispatch('tryLogin');

                //Determine Read Only user
                /*var getRoles = this.$store.getters.getUserRole;

                if (getRoles.includes('ADMIN')) {
                    return
                } else if (getRoles.includes('FULL')) {
                    return
                } else if (getRoles.includes('READ')) {
                    this.$store.state.readOnly = this.$store.getters.getUserRole.includes('READ') ? true : false;
                    return
                } else {
                    this.$router.push({ name: 'error', params: { status: 403 }})
                    return
                }*/
            }
        },
        components: {
        }
    }
</script>