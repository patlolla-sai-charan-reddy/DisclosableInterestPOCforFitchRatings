/**
    * @desc this file is the entry to point to bootstrap the Marketshare Application
    * @author Ashwini Singh
    * @version 1.1.0
*/

//Dependencies

//Libraries
import Vue from 'vue';
import { store } from './utils/store/store';
import VueRouter from 'vue-router';
import axios from 'axios';
import BootstrapVue from 'bootstrap-vue'
import moment from 'moment';


//Form Fields
import VeeValidate from 'vee-validate';
import {ServerTable, ClientTable, Event} from 'vue-tables-2';
import VuePaginate from 'vue-paginate';
import money from 'v-money';
import datePicker from 'vue-bootstrap-datetimepicker';
import Multiselect from 'vue-multiselect';
//Local files
import App from './components/App.vue';
import {isLocal, apiPrefix} from './utils/env';
import Auth from './utils/Auth';
import { HTTP } from './utils/calls';
import {router} from './utils/router'
import HomeButton from './components/miscellaneous/HomeButton.vue';
import RatedDeals from './components/routes/RatedDeals.vue';
import NonRatedDeals from './components/routes/NonRatedDeals.vue';
import Banner from './components/sections/Banner.vue';
import Loading from './components/miscellaneous/Loading.vue';
import Modal  from './components/miscellaneous/Modal.vue';
import MyForm from './components/MyForm.vue';
import SectionHeader from './components/sections/SectionHeader.vue';
import MyTextInput from './components/fields/TextInput.vue';
import MySelectInput from './components/fields/SelectInput.vue';
//Tables
import BalanceTable from './components/tables/BalanceTable.vue';
import CartInfoTable from './components/tables/CartInfoTable.vue';
import ClassInfoTable from './components/tables/ClassInfoTable.vue';
import PartiesTable from './components/tables/PartiesTable.vue';

import MyInput from './components/tables/Components/MyInput.vue';


//Styles
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'
import 'eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css'
import 'vue-multiselect/dist/vue-multiselect.min.css'
import 'ag-grid/dist/styles/ag-grid.css'
import 'ag-grid/dist/styles/ag-theme-fresh.css'

import "ag-grid-enterprise";
import { LicenseManager } from "ag-grid-enterprise";
LicenseManager.setLicenseKey(
  "Fitch_Ratings_BRM_Tool_1Devs_1Deployment_16_April_2020__MTU4Njk5MTYwMDAwMA==f1cb19ebf52b2f3b0c697e0e1da5f327"
);



require('font-awesome/css/font-awesome.css');




//Use Libs
Vue.use(VueRouter);
Vue.use(BootstrapVue);
Vue.prototype.$moment = moment

//Use Form Fields
Vue.use(VeeValidate, {fieldsBagName: 'formFields'});
Vue.use(ClientTable);
Vue.use(VuePaginate);
Vue.use(money, {precision: 4});
Vue.use(datePicker);
Vue.use(Multiselect);




Vue.prototype.$http = HTTP;

Vue.component('home-button', HomeButton);
Vue.component('banner', Banner);
Vue.component('loading', Loading);
Vue.component('modal', Modal);
Vue.component('my-form', MyForm);
Vue.component('section-header', SectionHeader);
Vue.component('my-text-input', MyTextInput);
Vue.component('my-select-input', MySelectInput);
Vue.component('parties-table', PartiesTable);
Vue.component('class-info-table', ClassInfoTable);
Vue.component('my-grid', ClassInfoTable);
Vue.component('balance-table', BalanceTable);
Vue.component('cart-info-table', CartInfoTable);
Vue.component('rated-deals', RatedDeals);
Vue.component('non-rated-deals', NonRatedDeals);
Vue.component('my-input', MyInput);




new Vue({
    el: '#app',
    store: store,
    router: router,
    render: h => h(App)
});