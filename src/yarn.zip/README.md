1. `yarn install` to install all the dependencies
2. `yarn build` to build
3. `yarn start` opens the app in browser on the port 8090