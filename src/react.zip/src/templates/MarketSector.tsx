import React from 'react'
import { graphql } from 'gatsby'

import Main from '../components/main'
import SEO from '../components/seo'
import Hero from '../components/hero'
import Contacts from '../components/contacts'
import Entities from '../components/entities'
import Highlight from '../components/highlight'
import KeyPoint from '../components/keypoint'
import Ratings from '../components/ratings'
import Research from '../components/research'
import Videos from '../components/videos'
import Events from '../components/events'
import Podcasts from '../components/podcasts'

type ContentfulMarketSector = {
  slug: string
  title: string
  ratingsDisplayed: number
  researchDisplayed: number
  videosDisplayed: number
  eventsDisplayed: number
  podcastsDisplayed: number
  banner: {
    title: string
    abstract: {
      abstract: string
    }
    image: {
      file: {
        url: string
      }
    }
  }
}

type Query = {
  contentfulMarketSector: ContentfulMarketSector
}

export interface Props {
  data: Query
}

export default ({
  data: {
    contentfulMarketSector: {
      slug,
      title,
      banner,
      ratingsDisplayed,
      researchDisplayed,
      videosDisplayed,
      eventsDisplayed,
      podcastsDisplayed
    }
  }
}: Props) => {
  const sectionDisplay = {
    ratingsDisplayed,
    researchDisplayed,
    videosDisplayed,
    eventsDisplayed,
    podcastsDisplayed
  }
  let sections

  // TODO introduce re-orderable sections
  if (slug === 'corporates') {
    sections = [
      { component: Ratings, name: 'ratings' },
      {
        component: KeyPoint,
        name: 'KeyPoint',
        props: {
          heading: 'Rating Criteria',
          abstract:
            'We have 1,100 leading analysts in 50 offices over 24 countries.',
          link: 'http://fitchratings.com',
          label: 'Learn More'
        }
      },
      { component: Research, name: 'research' },
      { component: Highlight, name: 'highlight' },
      { component: Entities, name: 'entities' },
      { component: Contacts, name: 'contacts' },
      { component: Events, name: 'events' },
      {
        component: KeyPoint,
        name: 'keyPoint',
        props: {
          image: {
            url:
              '//images.ctfassets.net/03fbs7oah13w/1LjdNWi46Yq1W5HcTivtNa/4ebffa67ba4198cc3f75f6d13b33dba4/fr-page-header-credit-outlook-2019.jpg'
          },
          heading: 'Experience Credit Outlooks 2019',
          abstract:
            'We have 1,100 leading analysts in 50 offices over 24 countries.',
          link: 'http://fitchratings.com',
          label: 'Learn More'
        }
      },
      { component: Videos, name: 'videos' }
    ]
  } else {
    sections = [
      { component: Ratings, name: 'ratings' },
      { component: Research, name: 'research' },
      { component: Videos, name: 'videos' },
      { component: Events, name: 'events' },
      { component: Podcasts, name: 'podcasts' },
      { component: Contacts, name: 'contacts' }
    ]
  }

  return (
    <Main>
      <SEO title={title} keywords={[`market sector`, title]} />
      <article>
        <Hero title={title} banner={banner} {...sectionDisplay} />
        {sections.map(section => {
          const TagName = section.component
          return (
            <TagName
              limit={sectionDisplay[`${section.name.toLowerCase()}Displayed`]}
              {...section.props}
            />
          )
        })}
      </article>
    </Main>
  )
}

export const query = graphql`
  query($slug: String!) {
    contentfulMarketSector(slug: { eq: $slug }) {
      slug
      title
      ratingsDisplayed
      researchDisplayed
      videosDisplayed
      eventsDisplayed
      podcastsDisplayed
      banner {
        ...imageFields
        title
        abstract {
          abstract
        }
      }
    }
  }
  fragment imageFields on ContentfulBanner {
    image {
      file {
        url
      }
    }
  }
`
