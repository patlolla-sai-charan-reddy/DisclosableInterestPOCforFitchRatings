import React, { ComponentType } from 'react'
import { cx } from 'emotion'
import { gql } from 'apollo-boost'
import { ChildDataProps, graphql } from 'react-apollo'
import { RouteComponentProps } from '@reach/router'

// eslint-disable-next-line import/no-extraneous-dependencies
import {
  RatingHeader,
  RatingHeaderProps,
  Paragraphs,
  MarketingTags,
  Social,
  Analysts,
  RatingKey,
  IssuerLists,
  IssuerContents,
  EmbeddedRatings,
  RelatedContents,
  columnLeftLMR,
  columnMainLMR,
  columnRightLMR,
  article,
  aside,
  content,
  wrapper1
} from 'fitch_storybook'

import Dynamic from '../components/dynamic'
import Main from '../components/main'
import SEO from '../components/seo'

type InputProps = { slug: string }
// TODO: create proper response types
type Response = { getRAC: RatingHeaderProps }
type Variables = { id: number }
type ChildProps = ChildDataProps<InputProps, Response, Variables>

type Props = {
  slug: string
}

const withRAC = graphql<InputProps, Response, Variables, ChildProps>(
  gql`
    query RAC($id: Int!) {
      getRAC(id: $id) {
        title
        companyDesc
        reportType
        origin
        publishedDate
        paragraphs {
          name
          header
          subHeader
          showHeader
          content
        }
        marketing {
          sectors {
            name
            url
          }
          regions {
            name
            url
          }
        }
        analysts {
          type
          firstName
          lastName
          title
          phoneNumber
          address
        }
        embeddedRatings {
          rows {
            title
            level
            typeAbbr
            typeDesc
            ratingCode
            watchOutlookCode
            ratingAction
            recoveryRating
            priorRatingCode
            priorWatchOutlookCode
          }
        }
        issuers {
          title
          issuerId
        }
      }
      getSectorContentForRAC(id: $id) {
        title
        dbDocId
      }
      getIssuerContentForRAC(id: $id) {
        title
        dbDocId
      }
    }
  `,
  {
    options: ({ slug }) => ({
      variables: { id: parseInt(slug, 10) }
    })
  }
)

const Body = ({
  loading,
  error,
  getRAC,
  getSectorContentForRAC,
  getIssuerContentForRAC
}: ChildProps) => {
  if (loading) return <p>Loading...</p>
  if (error) return <p>Error :(</p>

  const { sectors, regions } = getRAC.marketing
  const marketingTags = [...sectors, ...regions]

  // TODO Tidy up TypeScript types
  const leadParagraphIndex = getRAC.paragraphs.findIndex(
    (e: object) => e.name === 'LEAD PARAGRAPH'
  )

  const leadParagraph =
    leadParagraphIndex > -1
      ? getRAC.paragraphs.splice(leadParagraphIndex, 1)
      : null

  return (
    <article className={article}>
      <div className={cx(wrapper1, content)}>
        <RatingHeader {...getRAC} />
        <div>
          <div className={columnLeftLMR}>
            <Social />
          </div>
          <div className={columnMainLMR}>
            {leadParagraph && <Paragraphs items={leadParagraph} />}
            <EmbeddedRatings rows={getRAC.embeddedRatings.rows} />
            <Paragraphs items={getRAC.paragraphs} />
            <MarketingTags items={marketingTags} />
          </div>
          <aside className={cx(aside, columnRightLMR)}>
            <IssuerLists items={getRAC.issuers} />
            <RelatedContents items={getSectorContentForRAC} />
            <IssuerContents items={getIssuerContentForRAC} />
            <Analysts items={getRAC.analysts} />
            <RatingKey />
          </aside>
        </div>
      </div>
    </article>
  )
}

const RAC = withRAC(({ data }: ChildProps) => (
  <Main>
    <SEO title="" keywords={[`market sector`, `rating`]} />
    <Body {...data} />
  </Main>
))

export const DynamicRAC: ComponentType<RouteComponentProps> = ({
  slug
}: Props) => (
  <Dynamic>
    <RAC slug={slug} />
  </Dynamic>
)

export default DynamicRAC
