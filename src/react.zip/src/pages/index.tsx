import React from 'react'
import { Link, graphql } from 'gatsby'

import Main from '../components/main'
import SEO from '../components/seo'

type Collection = {
  node: {
    id: string
    title: string
    slug: string
  }
}

// TODO: graphql2ts
type Query = {
  site: {
    siteMetadata: {
      title: string
      description: string
    }
  }
  allContentfulMarketSector: {
    edges: Collection[]
  }
}

type Props = {
  data: Query
}

export const query = graphql`
  query {
    site {
      siteMetadata {
        title
        description
      }
    }
    allContentfulMarketSector {
      edges {
        node {
          id
          title
          slug
        }
      }
    }
  }
`

export default ({ data }: Props) => (
  <Main>
    <SEO title="Home" keywords={[`gatsby`, `application`, `react`]} />
    <article className="mw5 mw7-ns center pa3 ph5-ns">
      <h1>
        Welcome to&nbsp;
        {data.site.siteMetadata.title}
      </h1>
      <p>{data.site.siteMetadata.description}</p>
      <hr />
      <h2>Market Sectors:</h2>
      <ul>
        {data.allContentfulMarketSector.edges.map(({ node }) => (
          <li key={node.id}>
            <Link to={node.slug}>{node.title}</Link>
          </li>
        ))}
      </ul>
    </article>
  </Main>
)
