import React from 'react'
import { Router } from '@reach/router'
import RAC from '../templates/RAC'
import NotFound from './404'

export default () => (
  <Router>
    <RAC path="/research/:slug" />
    <NotFound default />
  </Router>
)
