import React, { ComponentType } from 'react'
import { RouteComponentProps } from '@reach/router'

import Main from '../components/main'
import SEO from '../components/seo'

const NotFoundPage: ComponentType<RouteComponentProps> = () => (
  <Main>
    <SEO title="404: Not found" />
    <article className="mw5 mw7-ns center pa3 ph5-ns">
      <h1>Not Found</h1>
      <p>The requested page could not be found.</p>
    </article>
  </Main>
)

export default NotFoundPage
