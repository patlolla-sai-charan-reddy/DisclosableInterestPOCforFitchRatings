import React from 'react'
import { gql } from 'apollo-boost'
import { ChildDataProps, graphql } from 'react-apollo'

// eslint-disable-next-line import/no-extraneous-dependencies
import { Research } from 'fitch_storybook'

import Dynamic from './dynamic'

type RAC = {
  dbDocId: number
  title: string
  publishedDate: string
  reportType: string
}

type Response = {
  getRACs: {
    rows: RAC[]
  }
}

type Props = {
  limit: number
}

const withRACs = graphql<{}, Response, {}, ChildProps>(gql`
  {
    getRACs(sector: "05*") {
      rows {
        dbDocId
        title
        publishedDate
      }
    }
  }
`)

type ChildProps = ChildDataProps<{}, Response>

const ResearchComponent = withRACs(({ data, limit }: ChildProps) => {
  const { loading, error, getRACs } = data

  if (loading) return <p>Loading...</p>
  if (error || !getRACs) return <p>Server error</p>

  const items = getRACs.rows.map(row => ({
    ...row
  }))

  return <Research items={items.slice(0, limit)} />
})

export default ({ limit }: Props) => (
  <Dynamic>
    <ResearchComponent limit={limit} />
  </Dynamic>
)
