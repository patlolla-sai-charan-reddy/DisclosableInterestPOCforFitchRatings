import React from 'react'

// eslint-disable-next-line import/no-extraneous-dependencies
import { Hero, HeroProps } from 'fitch_storybook'

type ContentfulMarketSector = {
  title: string
  ratingsDisplayed: number
  researchDisplayed: number
  videosDisplayed: number
  eventsDisplayed: number
  podcastsDisplayed: number
  banner: {
    title: string
    abstract: {
      abstract: string
    }
    image: {
      file: {
        url: string
      }
    }
  }
}

type Props = {
  title: string
  banner: {
    title: string
    abstract: {
      abstract: string
    }
    image: {
      file: {
        url: string
      }
    }
  }
  ratingsDisplayed: number
  researchDisplayed: number
  videosDisplayed: number
  eventsDisplayed: number
  podcastsDisplayed: number
}

type SectionProps = {
  title: string
  number: string
}

const createSectionLinks = ({
  ratingsDisplayed,
  researchDisplayed,
  videosDisplayed,
  eventsDisplayed,
  podcastsDisplayed
}: Partial<ContentfulMarketSector>): SectionProps => {
  const sections: SectionProps[] = []
  let sectionIndex = 1

  const addZero = (i: number) => {
    let j = i
    if (i < 10) {
      j = `0${i}`
    }
    return j.toString()
  }

  const addSection = (i: number, title: string) => {
    sectionIndex += 1
    sections.push({ number: addZero(i), title })
  }

  if (ratingsDisplayed) addSection(sectionIndex, 'Ratings')
  if (researchDisplayed) addSection(sectionIndex, 'Research')
  if (videosDisplayed) addSection(sectionIndex, 'Video')
  if (eventsDisplayed) addSection(sectionIndex, 'Events')
  if (podcastsDisplayed) addSection(sectionIndex, 'Podcasts')

  return sections
}

const parseHeroProps = ({
  title,
  banner,
  ratingsDisplayed,
  researchDisplayed,
  videosDisplayed,
  eventsDisplayed,
  podcastsDisplayed
}: Partial<ContentfulMarketSector>): HeroProps => {
  return {
    title,
    abstract: banner && banner.abstract.abstract,
    image: { url: banner && banner.image.file.url },
    sections: createSectionLinks({
      ratingsDisplayed,
      researchDisplayed,
      videosDisplayed,
      eventsDisplayed,
      podcastsDisplayed
    })
  }
}

export default ({
  title,
  banner,
  ratingsDisplayed,
  researchDisplayed,
  videosDisplayed,
  eventsDisplayed,
  podcastsDisplayed
}: Props) => {
  const props = parseHeroProps({
    title,
    banner,
    ratingsDisplayed,
    researchDisplayed,
    videosDisplayed,
    eventsDisplayed,
    podcastsDisplayed
  })

  return <Hero {...props} />
}
