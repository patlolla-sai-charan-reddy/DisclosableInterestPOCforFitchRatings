import React, { ReactNode } from 'react'
import { StaticQuery, graphql } from 'gatsby'
import { css } from 'emotion'
import { Location } from '@reach/router'

// eslint-disable-next-line import/no-extraneous-dependencies
import { c2, ff1, fs1, lh1, main, mpb2 } from 'fitch_storybook'
import SiteFooter from './siteFooter'
import SiteHeader from './siteHeader'

const globalStyles = css`
  box-sizing: border-box;
  font-family: ${ff1};
  font-size: ${fs1};
  line-height: ${lh1};
  color: ${c2};
  -webkit-font-smoothing: antialiased;

  * {
    box-sizing: inherit;

    &:before,
    &:after {
      box-sizing: inherit;
    }
  }

  * a {
    font-size: inherit;
    text-decoration: none;
    transition: all 350ms ease;
  }

  p,
  ul,
  ol,
  table {
    margin-bottom: ${mpb2};
  }

  ul,
  ol,
  ul li,
  ol li {
    margin: 0px;
    padding: 0px;
    list-style-image: none;
    list-style-type: none;
  }
`

export type Props = {
  children: ReactNode
}

// TODO: Tidy up the soltion for changing the header props based on page type
export default ({ children }: Props) => (
  <StaticQuery
    query={graphql`
      query SiteTitleQuery {
        site {
          siteMetadata {
            title
          }
        }
      }
    `}
    render={() => (
      <div className={globalStyles}>
        <Location>
          {({ location }) => {
            const siteHeaderProps = {
              href: 'http://www.fitchratings.com',
              hasHeader: true,
              image: {
                url:
                  'https://your.fitchratings.com/rs/732-CKH-767/images/fitch-ratings-email-logo-white.png',
                title: 'Fitch Ratings Logo'
              }
            }
            if (location.pathname.includes('research')) {
              siteHeaderProps.hasHeader = false
              siteHeaderProps.image.url =
                'https://your.fitchratings.com/rs/732-CKH-767/images/fitch-ratings-email-logo.png'
            }

            return <SiteHeader {...siteHeaderProps} />
          }}
        </Location>

        <main className={main}>{children}</main>
        <SiteFooter />
      </div>
    )}
  />
)
