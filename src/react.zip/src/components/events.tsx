import React from 'react'
import { useStaticQuery, graphql } from 'gatsby'

// eslint-disable-next-line import/no-extraneous-dependencies
import { Events, EventsProps } from 'fitch_storybook'

type ContentfulEvent = {
  node: {
    title: string
    startDate: string
    endDate: string
    address: string
    region: string
    country: string
    eventType: string
    slug: string
    locationName: string
    locationCoordinates: {
      lat: number
      lon: number
    }
    image: {
      title: string
      file: {
        url: string
      }
    }
  }
}

type Query = {
  allContentfulEvent: {
    edges: ContentfulEvent[]
  }
}

type Props = {
  limit: number
}

const GET_EVENTS_QUERY = graphql`
  {
    allContentfulEvent {
      edges {
        node {
          title
          startDate
          endDate
          address
          region
          country
          eventType
          slug
          locationName
          locationCoordinates {
            lat
            lon
          }
          image {
            title
            file {
              url
            }
          }
        }
      }
    }
  }
`

const parseEventsProps = ({
  allContentfulEvent: { edges }
}: Query): EventsProps =>
  edges.map(({ node }: ContentfulEvent) => ({
    title: node.title,
    startDate: node.startDate,
    endDate: node.endDate,
    address: node.address,
    region: node.region,
    country: node.country,
    eventType: node.eventType,
    slug: node.slug,
    locationName: node.locationName,
    locationCoordinates: {
      lat: node.locationCoordinates.lat,
      lon: node.locationCoordinates.lon
    },
    image: {
      url: node.image.file.url,
      title: node.image.title
    }
  }))

export default ({ limit }: Props) => {
  const data = useStaticQuery(GET_EVENTS_QUERY)
  const items = parseEventsProps(data).slice(0, limit)

  return <Events items={items} />
}
