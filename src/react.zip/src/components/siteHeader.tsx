import React from 'react'

// eslint-disable-next-line import/no-extraneous-dependencies
import { SiteHeader, SiteHeaderProps } from 'fitch_storybook'

export default ({ hasHeader, image, href }: SiteHeaderProps) => (
  <SiteHeader image={image} href={href} hasHeader={hasHeader} />
)
