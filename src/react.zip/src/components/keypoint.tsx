import React from 'react'

// eslint-disable-next-line import/no-extraneous-dependencies
import { KeyPoint, KeyPointProps } from 'fitch_storybook'

export default (props: KeyPointProps) => <KeyPoint {...props} />
