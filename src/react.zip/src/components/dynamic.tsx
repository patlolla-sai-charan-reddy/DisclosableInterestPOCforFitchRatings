import fetch from 'node-fetch'
import React, { ReactNode } from 'react'
import ApolloClient from 'apollo-boost'
import { ApolloProvider } from 'react-apollo'

const client = new ApolloClient({
  fetch,
  uri: process.env.GATSBY_APOLLO
})

export type Props = {
  children: ReactNode
}

export default ({ children }: Props) => (
  <ApolloProvider client={client}>{children}</ApolloProvider>
)
