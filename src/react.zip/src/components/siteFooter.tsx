import React from 'react'

// eslint-disable-next-line import/no-extraneous-dependencies
import { SiteFooter } from 'fitch_storybook'

export default () => <SiteFooter />
