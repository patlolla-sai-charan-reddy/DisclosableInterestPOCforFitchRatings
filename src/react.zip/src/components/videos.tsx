import React from 'react'
import { useStaticQuery, graphql } from 'gatsby'

// eslint-disable-next-line import/no-extraneous-dependencies
import { Videos, VideosProps } from 'fitch_storybook'

type ContentfulVideo = {
  node: {
    embedId: string
    abstract: {
      abstract: string
    }
    slug: string
    title: string
    image: {
      file: {
        url: string
      }
    }
  }
}

type Query = {
  allContentfulVideo: {
    edges: ContentfulVideo[]
  }
}

type Props = {
  limit: number
}

const GET_VIDEOS_QUERY = graphql`
  {
    allContentfulVideo {
      edges {
        node {
          embedId
          abstract {
            abstract
          }
          slug
          title
          image {
            file {
              url
            }
          }
        }
      }
    }
  }
`

const parseVideosProps = ({
  allContentfulVideo: { edges }
}: Query): VideosProps =>
  edges.map(({ node }: ContentfulVideo) => ({
    embedId: node.embedId,
    abstract: node.abstract.abstract,
    slug: node.slug,
    title: node.title,
    image: {
      url: node.image.file.url
    }
  }))

export default ({ limit }: Props) => {
  const data = useStaticQuery(GET_VIDEOS_QUERY)
  const items = parseVideosProps(data).slice(0, limit)

  return <Videos items={items} />
}
