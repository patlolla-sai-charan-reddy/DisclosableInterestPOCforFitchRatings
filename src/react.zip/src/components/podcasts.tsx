import React from 'react'
import { useStaticQuery, graphql } from 'gatsby'

// eslint-disable-next-line import/no-extraneous-dependencies
import { Podcasts, PodcastsProps } from 'fitch_storybook'

type ContentfulPodcast = {
  node: {
    embedId: string
    title: string
    slug: string
    abstract: {
      abstract: string
    }
  }
}

type Query = {
  allContentfulPodcast: {
    edges: ContentfulPodcast[]
  }
}

type Props = {
  limit: number
}

const GET_PODCASTS_QUERY = graphql`
  {
    allContentfulPodcast {
      edges {
        node {
          embedId
          title
          slug
          abstract {
            abstract
          }
        }
      }
    }
  }
`

const parsePodcastsProps = ({
  allContentfulPodcast: { edges }
}: Query): PodcastsProps =>
  edges.map(({ node }: ContentfulPodcast) => ({
    ...node,
    abstract: node.abstract.abstract
  }))

export default ({ limit }: Props) => {
  const data = useStaticQuery(GET_PODCASTS_QUERY)
  const items = parsePodcastsProps(data).slice(0, limit)

  return <Podcasts items={items} />
}
