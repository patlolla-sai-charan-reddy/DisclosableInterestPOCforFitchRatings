import React from 'react'

// eslint-disable-next-line import/no-extraneous-dependencies
import { Highlight } from 'fitch_storybook'

export default () => {
  const props = {
    label: 'LEARN MORE',
    title: 'What we do and why we love it',
    abstract:
      'Take a peek into Fitch Solutions and learn about our customer-centric approach to building products and solutions, and how we solve client problems through our research, technology and expertise.',
    link: 'http://fitchratings.com',
    image: {
      url:
        'https://your.fitchratings.com/rs/732-CKH-767/images/global-leveraged-finance-2.jpg',
      title: 'Fitch Ratings'
    }
  }
  return <Highlight {...props} />
}
