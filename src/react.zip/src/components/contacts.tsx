import React from 'react'
import { useStaticQuery, graphql } from 'gatsby'

// eslint-disable-next-line import/no-extraneous-dependencies
import { Persons, PersonsProps } from 'fitch_storybook'

type ContentfulPerson = {
  node: {
    firstName: string
    lastName: string
    headshot: {
      url: string
    }
  }
}

type Query = {
  allContentfulPerson: {
    edges: ContentfulPerson[]
  }
}

type Props = {
  limit: number
}

const GET_PEOPLE_QUERY = graphql`
  {
    allContentfulPerson {
      edges {
        node {
          firstName
          lastName
          headshot {
            file {
              url
            }
          }
        }
      }
    }
  }
`

const parsePeopleProps = ({
  allContentfulPerson: { edges }
}: Query): PersonsProps =>
  edges.map(({ node }: ContentfulPerson) => ({
    ...node,
    headshot: node.headshot
  }))

export default ({ limit }: Props) => {
  const data = useStaticQuery(GET_PEOPLE_QUERY)
  const items = parsePeopleProps(data).slice(0, limit)

  return <Persons items={items} />
}
