// prefer default export if available
const preferDefault = m => m && m.default || m

exports.components = {
  "component---src-templates-market-sector-tsx": () => import("D:\\Users\\sareddy\\Desktop\\RWR\\react\\src\\templates\\MarketSector.tsx" /* webpackChunkName: "component---src-templates-market-sector-tsx" */),
  "component---cache-dev-404-page-js": () => import("D:\\Users\\sareddy\\Desktop\\RWR\\react\\.cache\\dev-404-page.js" /* webpackChunkName: "component---cache-dev-404-page-js" */),
  "component---src-pages-404-tsx": () => import("D:\\Users\\sareddy\\Desktop\\RWR\\react\\src\\pages\\404.tsx" /* webpackChunkName: "component---src-pages-404-tsx" */),
  "component---src-pages-index-tsx": () => import("D:\\Users\\sareddy\\Desktop\\RWR\\react\\src\\pages\\index.tsx" /* webpackChunkName: "component---src-pages-index-tsx" */),
  "component---src-pages-research-tsx": () => import("D:\\Users\\sareddy\\Desktop\\RWR\\react\\src\\pages\\research.tsx" /* webpackChunkName: "component---src-pages-research-tsx" */)
}

exports.data = () => import(/* webpackChunkName: "pages-manifest" */ "D:\\Users\\sareddy\\Desktop\\RWR\\react\\.cache\\data.json")

