"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

exports.__esModule = true;
exports.default = void 0;

var _mitt = _interopRequireDefault(require("mitt"));

const emitter = (0, _mitt.default)();
var _default = emitter;
exports.default = _default;