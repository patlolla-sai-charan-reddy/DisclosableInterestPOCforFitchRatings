module.exports = [{
      plugin: require('D:/Users/sareddy/Desktop/RWR/react/node_modules/gatsby-plugin-offline/gatsby-browser.js'),
      options: {"plugins":[]},
    },{
      plugin: require('D:/Users/sareddy/Desktop/RWR/react/gatsby-browser.js'),
      options: {"plugins":[]},
    }]
