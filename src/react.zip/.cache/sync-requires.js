const { hot } = require("react-hot-loader/root")

// prefer default export if available
const preferDefault = m => m && m.default || m


exports.components = {
  "component---src-templates-market-sector-tsx": hot(preferDefault(require("D:\\Users\\sareddy\\Desktop\\RWR\\react\\src\\templates\\MarketSector.tsx"))),
  "component---cache-dev-404-page-js": hot(preferDefault(require("D:\\Users\\sareddy\\Desktop\\RWR\\react\\.cache\\dev-404-page.js"))),
  "component---src-pages-404-tsx": hot(preferDefault(require("D:\\Users\\sareddy\\Desktop\\RWR\\react\\src\\pages\\404.tsx"))),
  "component---src-pages-index-tsx": hot(preferDefault(require("D:\\Users\\sareddy\\Desktop\\RWR\\react\\src\\pages\\index.tsx"))),
  "component---src-pages-research-tsx": hot(preferDefault(require("D:\\Users\\sareddy\\Desktop\\RWR\\react\\src\\pages\\research.tsx")))
}

