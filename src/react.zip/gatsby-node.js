/**
 * Implement Gatsby's Node APIs in this file.
 *
 * See: https://www.gatsbyjs.org/docs/node-apis/
 */
const path = require('path')

module.exports.createPages = async ({ graphql, actions: { createPage } }) => {
  const { data } = await graphql(`
    {
      allContentfulMarketSector {
        edges {
          node {
            slug
          }
        }
      }
    }
  `)

  data.allContentfulMarketSector.edges.forEach(({ node: { slug } }) => {
    createPage({
      path: slug,
      component: path.resolve('./src/templates/MarketSector.tsx'),
      context: { slug }
    })
  })
}
