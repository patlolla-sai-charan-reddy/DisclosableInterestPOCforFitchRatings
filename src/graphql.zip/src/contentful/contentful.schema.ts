import { makeExecutableSchema, makeRemoteExecutableSchema } from 'graphql-tools'
import { HttpLink } from 'apollo-boost'
import { setContext } from 'apollo-link-context'
import fetch from 'isomorphic-fetch'
import * as typeDefs from './contentful.types.graphql'

const {
  CONTENTFUL_API_URL,
  CONTENTFUL_SPACE,
  CONTENTFUL_ENVIRONMENT,
  CONTENTFUL_ACCESS_TOKEN
} = process.env

const http = new HttpLink({
  fetch,
  uri: `${CONTENTFUL_API_URL}/${CONTENTFUL_SPACE}/environments/${CONTENTFUL_ENVIRONMENT}`
})

// Setup authorization connection to Contentful with appropriate access token.
const link = setContext(async () => {
  return {
    headers: {
      Authorization: `Bearer ${CONTENTFUL_ACCESS_TOKEN}`
    }
  }
}).concat(http)

// Instantiate a schema ready for querying against.
const schema = makeExecutableSchema({ typeDefs })

// Delegate requests to the underlying service via link, i.e. Contentful.
export default makeRemoteExecutableSchema({
  schema,
  link
})
