import 'dotenv-safe/config'
import { ApolloServer, mergeSchemas } from 'apollo-server'
import depthLimit from 'graphql-depth-limit'
import AppModule from './modules'
import contentfulSchema from './contentful/contentful.schema'

const { APOLLO_INTROSPECTION, APOLLO_PLAYGROUND, APOLLO_DEBUG } = process.env

const { schema, context } = AppModule

const server = new ApolloServer({
  schema: mergeSchemas({
    schemas: [schema, contentfulSchema]
  }),
  context,
  validationRules: [depthLimit(5)],
  introspection: Boolean(APOLLO_INTROSPECTION),
  playground: Boolean(APOLLO_PLAYGROUND),
  debug: Boolean(APOLLO_DEBUG)
})

server.listen().then(({ url }) => {
  console.info(`🚀  Server ready at ${url}`)
})
