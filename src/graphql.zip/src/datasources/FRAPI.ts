/* eslint no-unused-vars: ["off", { "vars": "local" }] */
// import { RESTDataSource } from 'apollo-datasource-rest'
import { Injectable } from '@graphql-modules/di'
import fs from 'fs'
import path from 'path'

// TODO: Extend RESTDatasource in future!

// WARNING: ExperimentalWarning: The fs.promises API is experimental
const mock = async filename =>
  fs.promises.readFile(
    path.resolve(__dirname, 'mocks', `${filename}.json`),
    'utf-8'
  )

@Injectable()
export default class FRAPI {
  getRAC = async (id: Number) => {
    const data = await mock('10059819')
    return JSON.parse(data as string)
  }

  getRACs = async (sector: String) => {
    const data = await mock('ratings-for-sector-sovereigns')
    return JSON.parse(data as string)
  }

  getIssuerContentForRAC = async (id: Number) => {
    const data = await mock('issuer-content-example')
    return JSON.parse(data as string)
  }

  getSectorContentForRAC = async (id: Number) => {
    const data = await mock('sector-content-example')
    return JSON.parse(data as string)
  }
}
