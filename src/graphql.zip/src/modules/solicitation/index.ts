import { GraphQLModule } from '@graphql-modules/core'
import * as typeDefs from './solicitation.graphql'
import resolvers from './resolvers'
import SolicitationProvider from './solicitation.provider'

const SolicitationModule = new GraphQLModule({
  typeDefs,
  resolvers,
  providers: [SolicitationProvider],
  resolverValidationOptions: { requireResolversForResolveType: false }
})

export default SolicitationModule
