/* eslint class-methods-use-this: 0 */

import { Injectable } from '@graphql-modules/di'
import lo from 'lodash'

@Injectable()
export default class SolicitationProvider {
  buildSolList(composites) {
    const solicitationVO = lo.find(composites, c => c.name === 'solicitationVO')

    const val = {
      rows: [],
      count: 0
    }

    if (
      !lo.hasIn(solicitationVO, 'content') ||
      !lo.hasIn(solicitationVO, 'content.solicitationVOList')
    ) {
      return val
    }

    const items = solicitationVO.content.solicitationVOList.map(us => {
      const { solicitTypeDesc: typeDesc, rtngDesc, bondName, isin } = us
      return {
        typeDesc,
        rtngDesc,
        bondName,
        isin
      }
    })

    val.rows = items
    val.count = items.length

    return val
  }
}
