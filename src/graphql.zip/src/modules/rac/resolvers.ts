import { GraphQLDate } from 'graphql-iso-date'
import GraphQLJSON from 'graphql-type-json'
import lo from 'lodash'
import FRAPI from '../../datasources/FRAPI'
import RACProvider from './rac.provider'

export default {
  Query: {
    getRAC: async (_, { id }, context) => {
      const api = context.injector.get(FRAPI)
      const response = await api.getRAC(id)
      const racProvider = context.injector.get(RACProvider)

      if (!lo.hasIn(response, 'data') || !lo.hasIn(response, 'columnHeaders')) {
        return []
      }

      const apiSource: any = lo.first(response.data)

      if (lo.isUndefined(apiSource) || lo.isEmpty(apiSource)) {
        return []
      }

      const { columnHeaders } = response

      const { title, dbDocID: dbDocId, docType, publishDate } = apiSource
      const { fcReportType: reportType } = apiSource
      const { disclosure, disclaimer, copyright } = apiSource
      const { companyDesc, origin } = apiSource

      const {
        analystContactsList,
        criteriaReportList,
        mediaContactsList,
        marketing,
        documentContentList,
        solicitationVO,
        embeddedRatingList,
        primaryReportList,
        entitiesList,
        issuerTaggingList
      } = apiSource

      return {
        title,
        publishedDate: new Date(publishDate),
        companyDesc,
        origin,
        dbDocId,
        docType,
        reportType,
        disclosure,
        disclaimer,
        copyright,
        composites: [
          {
            name: 'analystContactsList',
            content: analystContactsList
          },
          {
            name: 'mediaContactsList',
            content: mediaContactsList
          },
          {
            name: 'criteriaReportList',
            content: criteriaReportList
          },
          {
            name: 'marketing',
            content: marketing
          },
          {
            name: 'documentContentList',
            content: documentContentList
          },
          {
            name: 'solicitationVO',
            content: solicitationVO
          },
          {
            name: 'embeddedRatingList',
            content: embeddedRatingList
          },
          {
            name: 'primaryReportList',
            content: primaryReportList
          },
          {
            name: 'entitiesList',
            content: entitiesList
          },
          {
            name: 'issuerTaggingList',
            content: issuerTaggingList
          }
        ],
        disclosableOrDisqualifying: racProvider.getDisclosableOrDisqualifyingText(
          apiSource,
          columnHeaders
        )
      }
    },
    getRACs: async (_, { sector }, context) => {
      const api = context.injector.get(FRAPI)
      const response = await api.getRACs(sector)

      if (!lo.hasIn(response, 'data')) {
        return {
          rows: [],
          count: 0
        }
      }

      const listing = response.data.map(r => {
        const { title, dbDocID: dbDocId, docType, publishUTCDate } = r
        const { fcReportType: reportType, abstract } = r

        return {
          title,
          dbDocId,
          docType,
          publishedDate: new Date(publishUTCDate),
          reportType,
          abstract
        }
      })

      return {
        rows: listing,
        count: listing.length
      }
    }
  },
  GraphQLDate,
  GraphQLJSON
}
