/* eslint class-methods-use-this: 0 */
import { Injectable } from '@graphql-modules/di'
import lo from 'lodash'
@Injectable()
export default class RACProvider {
  getDisclosableOrDisqualifyingText(rac: any, columnHeaders: any) {
    const keys = [
      'isDisclosableEUFlag',
      'isDisclosableNonEUFlag',
      'isDisqualifyingEUFlag',
      'isDisqualifyingNonEUFlag'
    ]
    const index = lo.find(keys, k => {
      return rac[k] === true
    })
    const textValueProperty = lo.lowerFirst(
      lo.replace(lo.replace(index as string, 'Flag', 'Text'), 'is', '')
    )
    return columnHeaders[textValueProperty]
  }

  getEndorsementPolicy() {
    return '<p class="endorsement-policy" id="endorsement_policy" style="display: block;"><span class="endorsementTitle">Endorsement Policy</span>Fitch\'s approach to ratings endorsement so that ratings produced outside the EU may be used by regulated entities within the EU for regulatory purposes, pursuant to the terms of the EU Regulation with respect to credit rating agencies, can be found on the <a href="https://www.fitchratings.com/regulatory" target="new">EU Regulatory Disclosures</a> page. The endorsement status of all International ratings is provided within the entity summary page for each rated entity and in the transaction detail pages for all structured finance transactions on the Fitch website. These disclosures are updated on a daily basis.</p>'
  }

  getSolicitationStatus() {
    return 'The ratings above were solicited and assigned or maintained at the request of the rated entity/issuer or a related third party. Any exceptions follow below.'
  }

  getAdditionalDisclosures(dbDocId) {
    return `<ul><li><a href="/site/dodd-frank-disclosure/${dbDocId}" target="_blank" rel="noopener noreferrer"></a><a href="#solicitation">Solicitation Status</a><a href="/site/regulatory">Endorsement Policy</a></li></ul>`
  }
}
