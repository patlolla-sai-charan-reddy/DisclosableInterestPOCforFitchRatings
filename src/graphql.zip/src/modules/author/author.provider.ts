/* eslint class-methods-use-this: 0 */
import { Injectable } from '@graphql-modules/di'
import 'reflect-metadata'
import lo from 'lodash'

@Injectable()
export default class AuthorProvider {
  /**
   * Build Analysts from RAC object passed in
   *
   * @param rac
   * @returns Array<Object>
   */
  buildAnalysts(composites): Array<Object> {
    const analystContactsList = lo.find(
      composites,
      c => c.name === 'analystContactsList'
    )

    if (!lo.hasIn(analystContactsList, 'content')) {
      return []
    }

    const analysts = analystContactsList.content.map(a => {
      const {
        type,
        firstName,
        lastName,
        employeeNumber,
        title: t,
        phoneNumber
      } = a
      const {
        companyLocation = '',
        companyStreetAddress = '',
        companyDesc = ''
      } = lo.first(a.analystAddress) || {}

      return {
        type,
        firstName,
        lastName,
        employeeNumber,
        title: t,
        phoneNumber,
        address: lo.join(
          [companyDesc, companyStreetAddress, companyLocation],
          ' '
        )
      }
    })

    return analysts
  }

  /**
   * Build out Media Contacts listing from passed in RAC.
   *
   * @param rac
   * @returns Array<Object>
   */
  buildMediaContacts(composites: any): Array<Object> {
    const mediaContactsList = lo.find(
      composites,
      c => c.name === 'mediaContactsList'
    )

    const mediaContacts = mediaContactsList.content.map(mc => {
      const { email, phone, location } = mc
      return {
        firstName: mc.fName,
        lastName: mc.lName,
        email,
        phone,
        location
      }
    })

    return mediaContacts
  }
}
