/* eslint class-methods-use-this: 0 */
import { Injectable } from '@graphql-modules/di'
import lo from 'lodash'

@Injectable()
export default class RelatedProvider {
  buildIssuerContent(issuerContent: any): Array<Object> {
    const listing = issuerContent.data.map(ic => {
      const { title, dbDocID: dbDocId, fcReportType } = ic

      return {
        title,
        dbDocId,
        fcReportType
      }
    })
    return listing
  }

  buildSectorContent(sectorContent: any): Array<Object> {
    return this.buildIssuerContent(sectorContent)
  }

  buildIssuers(composites: any): Array<Object> {
    const issuerTaggingList = lo.find(
      composites,
      c => c.name === 'issuerTaggingList'
    )

    if (!lo.hasIn(issuerTaggingList, 'content')) {
      return []
    }

    const issuers = issuerTaggingList.content.map(i => {
      const { grpNm, grpID: issuerId } = i
      return {
        title: grpNm,
        issuerId
      }
    })
    return issuers
  }
}
