import FRAPI from '../../datasources/FRAPI'
import RelatedProvider from './related.provider'

export default {
  Query: {
    getIssuerContentForRAC: async (_, { id }, context) => {
      const issuerContent = await context.injector
        .get(FRAPI)
        .getIssuerContentForRAC(id)
      return context.injector
        .get(RelatedProvider)
        .buildIssuerContent(issuerContent)
    },
    getSectorContentForRAC: async (_, { id }, context) => {
      const sectorContent = await context.injector
        .get(FRAPI)
        .getSectorContentForRAC(id)
      return context.injector
        .get(RelatedProvider)
        .buildSectorContent(sectorContent)
    }
  }
}
