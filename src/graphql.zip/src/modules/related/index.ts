import { GraphQLModule } from '@graphql-modules/core'
import FRAPI from '../../datasources/FRAPI'
import * as typeDefs from './related.graphql'
import resolvers from './resolvers'
import RelatedProvider from './related.provider'

const RelatedModule = new GraphQLModule({
  typeDefs,
  resolvers,
  providers: [RelatedProvider, FRAPI],
  resolverValidationOptions: { requireResolversForResolveType: false }
})

export default RelatedModule
