import { GraphQLUrl } from 'graphql-url'
import MarketingProvider from './marketing.provider'

export default {
  RAC: {
    marketing: async (rac, _, context) => {
      const data = context.injector
        .get(MarketingProvider)
        .buildMarketingTags(rac.composites)
      const { sectors, regions } = data
      return {
        sectors,
        regions
      }
    },
    canonicalUrl: async (rac, _, context) => {
      const data = context.injector
        .get(MarketingProvider)
        .buildMarketingTags(rac.composites)
      return data.canonicalUrl
    }
  },
  GraphQLUrl
}
