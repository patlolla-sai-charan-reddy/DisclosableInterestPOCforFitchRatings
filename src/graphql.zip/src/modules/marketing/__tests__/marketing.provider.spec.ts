import 'reflect-metadata'
import MarketingProvider from '../marketing.provider'

/**
 * 1. Test with known structure we get back object as we expect
 * 2. With no composite found, we are safe
 * 3. With composite and no value on composite we are safe
 */

const example = {
  sectors: [
    {
      name: 'Corporate Finance',
      url: 'http://example.com'
    },
    {
      name: 'Banks',
      url: 'http://example.com'
    },
    {
      name: 'Structured Finance',
      url: 'http://example.com'
    }
  ],
  regions: [
    {
      name: 'Australia/Oceania',
      url: 'http://example.com'
    }
  ],
  canonicalUrl: '/structured-finance/'
}

const fixture1 = {
  composites: [
    {
      name: 'marketing',
      content: {
        mappedMarketSectors: [
          'Corporate Finance',
          'Banks',
          'Structured Finance'
        ],
        canonicalUrl: '/structured-finance/',
        regions: ['Australia/Oceania'],
        language: 'English'
      }
    }
  ]
}

const fixture2 = {
  composites: {
    name: 'marketing',
    content: []
  }
}

const fixture3 = {
  composites: {
    name: 'marketing'
  }
}

describe('Marketing Module provider testsuite', () => {
  test('buildMarketingTags: Should return defined output', async () => {
    const p = new MarketingProvider()
    const output = p.buildMarketingTags(fixture1.composites)
    expect(output).toBeTruthy()
  })

  test('buildMarketingTags: Should return an array with 1 AcceptableCriteria Object matching known spec', async () => {
    const P = new MarketingProvider()
    const output = P.buildMarketingTags(fixture1.composites)
    expect(output).toMatchObject(example)
  })

  test('buildMarketingTags: With no composite found, return {"count": 0, "rows": []}', async () => {
    const p = new MarketingProvider()
    const output = p.buildMarketingTags('')
    expect(output).toMatchObject({
      sectors: [],
      regions: [],
      canonicalUrl: ''
    })
  })

  test('buildMarketingTags: With composite and no content', async () => {
    const p = new MarketingProvider()
    const output = p.buildMarketingTags(fixture2)
    expect(output).toMatchObject({
      sectors: [],
      regions: [],
      canonicalUrl: ''
    })
  })

  test('buildMarketingTags: With composite, name and no content key/value returns []', async () => {
    const p = new MarketingProvider()
    const output = p.buildMarketingTags(fixture3)
    expect(output).toMatchObject({
      sectors: [],
      regions: [],
      canonicalUrl: ''
    })
  })
})
