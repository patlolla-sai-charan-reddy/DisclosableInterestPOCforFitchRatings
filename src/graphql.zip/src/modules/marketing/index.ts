import { GraphQLModule } from '@graphql-modules/core'
import * as typeDefs from './marketing.graphql'
import resolvers from './resolvers'
import MarketingProvider from './marketing.provider'

const MarketingModule = new GraphQLModule({
  typeDefs,
  resolvers,
  providers: [MarketingProvider],
  resolverValidationOptions: { requireResolversForResolveType: false }
})

export default MarketingModule
