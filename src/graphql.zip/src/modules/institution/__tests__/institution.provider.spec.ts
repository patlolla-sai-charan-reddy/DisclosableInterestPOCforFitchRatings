import 'reflect-metadata'
import InstProvider from '../institution.provider'

/**
 * 1. Test with known structure we get back object as we expect
 * 2. With no composite found, we are safe
 * 3. With composite and no value on composite we are safe
 */

const example = {
  rows: [
    {
      name: 'Example Entity',
      id: 123456
    }
  ],
  count: 1
}

const fixture1 = {
  composites: [
    {
      name: 'entitiesList',
      content: [
        {
          entityName: 'Example Entity',
          entityID: 123456
        }
      ]
    }
  ]
}

const fixture2 = {
  composites: {
    name: 'entitiesList',
    content: []
  }
}

const fixture3 = {
  composites: {
    name: 'entitiesList'
  }
}

describe('Institution Module provider testsuite', () => {
  test('buildInstitutionsList: Should return defined output', async () => {
    const p = new InstProvider()
    const output = p.buildInstitutionsList(fixture1.composites)
    expect(output).toBeTruthy()
  })

  test('buildInstitutionsList: Should return an array with 1 AcceptableCriteria Object matching known spec', async () => {
    const P = new InstProvider()
    const output = P.buildInstitutionsList(fixture1.composites)
    expect(output).toMatchObject(example)
  })

  test('buildInstitutionsList: With no composite found, return {"count": 0, "rows": []}', async () => {
    const p = new InstProvider()
    const output = p.buildInstitutionsList('')
    expect(output).toMatchObject({ count: 0, rows: [] })
  })

  test('buildInstitutionsList: With composite and no content', async () => {
    const p = new InstProvider()
    const output = p.buildInstitutionsList(fixture2)
    expect(output).toMatchObject({ count: 0, rows: [] })
  })

  test('buildInstitutionsList: With composite, name and no content key/value returns []', async () => {
    const p = new InstProvider()
    const output = p.buildInstitutionsList(fixture3)
    expect(output).toMatchObject({ count: 0, rows: [] })
  })
})
