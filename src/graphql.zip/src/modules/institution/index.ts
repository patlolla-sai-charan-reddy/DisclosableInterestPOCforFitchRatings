import { GraphQLModule } from '@graphql-modules/core'
import * as typeDefs from './institution.graphql'
import resolvers from './resolvers'
import InstitutionProvider from './institution.provider'

const InstitutionModule = new GraphQLModule({
  typeDefs,
  resolvers,
  providers: [InstitutionProvider],
  resolverValidationOptions: { requireResolversForResolveType: false }
})

export default InstitutionModule
