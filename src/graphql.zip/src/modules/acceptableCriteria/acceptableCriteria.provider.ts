/* eslint class-methods-use-this: 0 */
import { Injectable } from '@graphql-modules/di'
import lo from 'lodash'
@Injectable()
export default class AcceptableCriteriaProvider {
  buildACList(composites: any): Array<Object> {
    const criteriaReportList = lo.find(
      composites,
      c => c.name === 'criteriaReportList'
    )

    if (!lo.hasIn(criteriaReportList, 'content')) {
      return []
    }

    const list = criteriaReportList.content.map(cr => {
      const {
        reportID: crid,
        reportTitle: crtitle,
        reportPublishDate: publishedDate
      } = cr
      return {
        id: crid,
        title: crtitle,
        publishedDate: new Date(publishedDate)
      }
    })
    return list
  }
}
