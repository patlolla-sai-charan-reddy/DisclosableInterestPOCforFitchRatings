import { GraphQLDate } from 'graphql-iso-date'
import AcceptableCriteriaProvider from './acceptableCriteria.provider'

export default {
  RAC: {
    acceptableCriteria: async (rac, _, context) => {
      return context.injector
        .get(AcceptableCriteriaProvider)
        .buildACList(rac.composites)
    }
  },
  GraphQLDate
}
