/* eslint class-methods-use-this: 0 */
import { Injectable } from '@graphql-modules/di'
import lo from 'lodash'

@Injectable()
export default class EmbeddedRatingProvider {
  buildEmbeddedRatings(composites) {
    const embeddedRatingList = lo.find(
      composites,
      c => c.name === 'embeddedRatingList'
    )

    if (!lo.hasIn(embeddedRatingList, 'content')) {
      return { rows: [], count: 0 }
    }

    const listing = lo.map(embeddedRatingList.content, er => {
      const {
        level,
        description: etitle,
        ratingTypeAbbr: typeAbbr,
        ratingTypeDesc: typeDesc,
        ratingCode,
        watchOutlookCd: watchOutlookCode,
        ratingAction,
        priorRatingCode,
        recoveryRating,
        priorWatchOutlookCd: priorWatchOutlookCode
      } = er

      return {
        level,
        title: etitle,
        typeAbbr,
        typeDesc,
        ratingCode,
        watchOutlookCode,
        ratingAction,
        recoveryRating,
        priorRatingCode,
        priorWatchOutlookCode
      }
    })
    return { rows: listing, count: listing.length }
  }
}
