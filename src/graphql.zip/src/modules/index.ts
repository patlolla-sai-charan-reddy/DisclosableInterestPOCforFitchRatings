import 'reflect-metadata'
import 'graphql-import-node'
import { GraphQLModule } from '@graphql-modules/core'
import RACModule from './rac'
import MarketingModule from './marketing'
import ParagraphsModule from './paragraphs'
import RelatedModule from './related'
import AcceptableCriteriaModule from './acceptableCriteria'
import SolicitationModule from './solicitation'
import EmbeddedRatingModule from './embeddedRating'
import PrimaryReportModule from './primaryReport'
import AuthorModule from './author'

const AppModule = new GraphQLModule({
  imports: [
    AuthorModule,
    RACModule,
    MarketingModule,
    ParagraphsModule,
    RelatedModule,
    AcceptableCriteriaModule,
    SolicitationModule,
    EmbeddedRatingModule,
    PrimaryReportModule
  ],
  resolverValidationOptions: { requireResolversForResolveType: false }
})

export default AppModule
