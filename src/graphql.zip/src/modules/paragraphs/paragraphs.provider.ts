/* eslint class-methods-use-this: 0 */
import { Injectable } from '@graphql-modules/di'
import 'reflect-metadata'
import lo from 'lodash'

@Injectable()
export default class ParagraphsProvider {
  buildParagraphs(composites): Array<Object> {
    const documentContentList = lo.find(
      composites,
      c => c.name === 'documentContentList'
    )

    if (!lo.hasIn(documentContentList, 'content')) {
      return []
    }

    const paras = documentContentList.content.map(p => {
      const {
        fieldName: name,
        fieldSubHeader: subHeader,
        isDisplayHeader: showHeader,
        fieldContent: content
      } = p
      return {
        name,
        subHeader,
        showHeader,
        content
      }
    })

    return paras
  }
}
