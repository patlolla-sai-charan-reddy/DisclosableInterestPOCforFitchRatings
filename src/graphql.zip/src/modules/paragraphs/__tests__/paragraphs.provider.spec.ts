import 'reflect-metadata'
import ParaProvider from '../paragraphs.provider'

/**
 * 1. Test with known structure we get back object as we expect
 * 2. With no composite found, we are safe
 * 3. With composite and no value on composite we are safe
 */

const example = [
  {
    name: 'LEAD PARAGRAPH',
    subHeader: null,
    showHeader: false,
    content:
      "Fitch Ratings has assigned&nbsp;the following rating to the Tender Option Bond Series Trust&nbsp;Series 2016-ZM0318:<br/><br/>--Custodial Receipts, Series CE-2019-004 'AA-'/Outlook Stable.<br/><br/>Fitch has upgraded the following ratings:<br/><br/>--Puttable Floating Rate Receipts, Series 2016-ZM0318 to 'AA-'/'F1+'/Outlook Stable from 'BBB+'/'F2'/Outlook Stable;&nbsp;<br/>--Inverse Floating Receipts, Series 2016-ZM0318 'AA-'/Outlook Stable from 'BBB+'/Outlook Stable.<br/><br/>"
  }
]

const fixture1 = {
  composites: [
    {
      name: 'documentContentList',
      content: [
        {
          fieldName: 'LEAD PARAGRAPH',
          fieldID: 1001,
          fieldHeader: 'Lead Paragraph',
          fieldSubHeader: null,
          isDisplayHeader: false,
          headerDisplayType: 'L2',
          fieldContent:
            "Fitch Ratings has assigned&nbsp;the following rating to the Tender Option Bond Series Trust&nbsp;Series 2016-ZM0318:<br/><br/>--Custodial Receipts, Series CE-2019-004 'AA-'/Outlook Stable.<br/><br/>Fitch has upgraded the following ratings:<br/><br/>--Puttable Floating Rate Receipts, Series 2016-ZM0318 to 'AA-'/'F1+'/Outlook Stable from 'BBB+'/'F2'/Outlook Stable;&nbsp;<br/>--Inverse Floating Receipts, Series 2016-ZM0318 'AA-'/Outlook Stable from 'BBB+'/Outlook Stable.<br/><br/>",
          contentDisplayType: 'L2',
          fieldSequence: 1,
          sectionLevel: 'L2'
        }
      ]
    }
  ]
}

const fixture2 = {
  composites: {
    name: 'documentContentList',
    content: []
  }
}

const fixture3 = {
  composites: {
    name: 'documentContentList'
  }
}

describe('Paragraphs Module provider testsuite', () => {
  test('buildParagraphs: Should return defined output', async () => {
    const p = new ParaProvider()
    const output = p.buildParagraphs(fixture1.composites)
    expect(output).toBeTruthy()
  })

  test('buildParagraphs: Should return an array with 1 AcceptableCriteria Object matching known spec', async () => {
    const P = new ParaProvider()
    const output = P.buildParagraphs(fixture1.composites)
    expect(output).toMatchObject(example)
  })

  test('buildParagraphs: With no composite found, return []', async () => {
    const p = new ParaProvider()
    const output = p.buildParagraphs('')
    expect(output).toMatchObject([])
  })

  test('buildParagraphs: With composite and no content', async () => {
    const p = new ParaProvider()
    const output = p.buildParagraphs(fixture2)
    expect(output).toMatchObject([])
  })

  test('buildParagraphs: With composite, name and no content key/value returns []', async () => {
    const p = new ParaProvider()
    const output = p.buildParagraphs(fixture3)
    expect(output).toMatchObject([])
  })
})
