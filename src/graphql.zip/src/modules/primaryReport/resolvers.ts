import PrimaryReportProvider from './primaryReport.provider'

export default {
  RAC: {
    primaryReports: async (rac, _, context) => {
      return context.injector
        .get(PrimaryReportProvider)
        .buildPRList(rac.composites)
    }
  }
}
