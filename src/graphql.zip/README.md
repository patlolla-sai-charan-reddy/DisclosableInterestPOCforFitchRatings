## Initial Setup

You can use either Yarn or NPM depending on your preference and local machine.

```bash
npm install
```

OR

```bash
yarn install
```

## Schema Stitching

**The below procedure is only required to be done, if the contentful models have been modified.**

The Contentful schema is downloaded using graphql-cli, which can be installed using:

```bash
npm install -g graphql-cli
```

To download the contentful schema, use the following command:

```bash
graphql get-schema \
--endpoint https://graphql.contentful.com/content/v1/spaces/<space>/environments/<environment> \
--header Authorization="Bearer <token>" \
--output contentful.types.graphql
```

Replacing `<space>`, `<environment>` and `<token>` with the correct values.

## Available Scripts

In the project directory, you can run:

### `npm start`

Starts the server.
Open [http://localhost:4000](http://localhost:4000) to view GraphQL Playground in the browser.

###

Added in prettier and eslint configs from fitch_contentful repository.
