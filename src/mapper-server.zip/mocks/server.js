const path = require('path')
// eslint-disable-next-line import/no-extraneous-dependencies
const jsonServer = require('json-server')

// Rewrite rules defined in routes.json
const rewrites = jsonServer.rewriter(require('./routes.json'))

// Override port using PORT= on CLI
const PORT = process.env.PORT || 4004

// Data source defined in db.json
const server = jsonServer.create()
const router = jsonServer.router(path.join(__dirname, 'db.json'))

// Wrap with data object
router.render = (req, res) => {
  res.jsonp({
    data: res.locals.data,
    columnHeaders: null
  })
}

// 403: Forbidden for any request not using GET
server.use(
  jsonServer.defaults({
    readOnly: true
  })
)

// Initiate
server.use(rewrites)
server.use(router)
server.listen(PORT, () => {
  console.info(
    `✧*｡٩(ˊᗜˋ*)و✧*｡ You're successfully running JSON Server on :${PORT}`
  )
})
