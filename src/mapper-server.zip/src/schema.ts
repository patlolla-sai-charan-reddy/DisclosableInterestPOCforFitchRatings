/**
 * Expose for introspect tooling.
 * @see https://graphql-modules.com/docs/guides/graphql-inspector
 */

import AppModule from './modules'

// Get schema from top module, and export it.
export default AppModule.schema
