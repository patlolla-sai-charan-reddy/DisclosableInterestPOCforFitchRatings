export class DocIdHandling extends Error {
    code = 451;
    message = this.message ||
      'This Document id is not available';
}