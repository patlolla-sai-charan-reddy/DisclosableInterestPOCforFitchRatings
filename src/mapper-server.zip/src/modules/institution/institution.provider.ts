/* eslint class-methods-use-this: 0 */
import { Injectable } from '@graphql-modules/di'
import lo from 'lodash'

@Injectable()
export default class InstitutionProvider {
  buildInstitutionsList(composites) {
    const entitiesList = lo.find(composites, c => c.name === 'entitiesList')

    if (!lo.hasIn(entitiesList, 'content')) {
      return { count: 0, rows: [] }
    }

    const listing = entitiesList.content.map(e => {
      const { entityName: name, entityID: id } = e
      return {
        name,
        id
      }
    })

    return { count: listing.length, rows: listing }
  }
}
