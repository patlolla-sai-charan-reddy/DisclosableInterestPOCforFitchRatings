import InstitutionProvider from './institution.provider'

export default {
  RAC: {
    institutions: async (rac, _, context) => {
      return context.injector
        .get(InstitutionProvider)
        .buildInstitutionsList(rac.composites)
    }
  }
}
