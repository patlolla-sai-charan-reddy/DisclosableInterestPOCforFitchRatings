import 'graphql-import-node'
import { GraphQLModule } from '@graphql-modules/core'
import * as typeDefs from './entitiesList.graphql'
import resolvers from './resolvers'
import { Search } from '../../datasources'

const EntitiesListModule = new GraphQLModule({
  providers: [Search],
  typeDefs,
  resolvers,
  resolverValidationOptions: { requireResolversForResolveType: false }
})

export default EntitiesListModule
