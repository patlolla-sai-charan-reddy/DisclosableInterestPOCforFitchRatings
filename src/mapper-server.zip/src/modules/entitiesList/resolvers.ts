import { isEmpty, isNil } from 'lodash'
import { Search } from '../../datasources'

export default {
  Query: {
    getEntitiesList: async (_, { term }, context) => {
      const api = context.injector.get(Search)
      const response = await api.getEntitiesList(term)

      if (isEmpty(response)) {
        return []
      }

      const apiSource: any = response.data
        ? response.data.searchResponse.ENTITY.hits
        : response.searchResponse.ENTITY.hits

      if (isNil(apiSource) || isEmpty(apiSource)) {
        return []
      }

      const entitiesList = apiSource.map(entity => {
        return {
          name: entity.sourceAsMap.name,
          slug: entity.sourceAsMap.marketing.permalink
        }
      })

      const count = entitiesList.length

      return {
        entitiesList,
        count
      }
    }
  }
}
