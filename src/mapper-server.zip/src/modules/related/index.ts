import { GraphQLModule } from '@graphql-modules/core'
import { Research } from '../../datasources'
import * as typeDefs from './related.graphql'
import resolvers from './resolvers'
import RelatedProvider from './related.provider'

const RelatedModule = new GraphQLModule({
  typeDefs,
  resolvers,
  providers: [Research, RelatedProvider],
  resolverValidationOptions: { requireResolversForResolveType: false }
})

export default RelatedModule
