import 'reflect-metadata'
import Provider from './related.provider'

/**
 * 1. Test with known structure we get back object as we expect
 * 2. With no composite found, we are safe
 * 3. With composite and no value on composite we are safe
 */

const example = [
  {
    title: 'Tender Option Bond Series Trust (NY)',
    issuerId: 95653490
  }
]

const fixture1 = {
  composites: [
    {
      name: 'issuerTaggingList',
      content: [
        {
          grpID: 95653490,
          unSolicitedAndNotParticipatedFlag: 'N',
          participationFlag: 'Y',
          euAnalyst: 'EUEndorsed',
          grpNm: 'Tender Option Bond Series Trust (NY)'
        }
      ]
    }
  ]
}

const fixture2 = {
  composites: {
    name: 'issuerTaggingList',
    content: []
  }
}

const fixture3 = {
  composites: {
    name: 'issuerTaggingList'
  }
}

describe('Related Module provider testsuite', () => {
  test('buildIssuers: Should return defined output', async () => {
    const p = new Provider()
    const output = p.buildIssuers(fixture1.composites)
    expect(output).toBeTruthy()
  })

  test('buildIssuers: Should return an array with 1 AcceptableCriteria Object matching known spec', async () => {
    const P = new Provider()
    const output = P.buildIssuers(fixture1.composites)
    expect(output).toMatchObject(example)
  })

  test('buildIssuers: With no composite found, return {"count": 0, "rows": []}', async () => {
    const p = new Provider()
    const output = p.buildIssuers('')
    expect(output).toMatchObject([])
  })

  test('buildIssuers: With composite and no content', async () => {
    const p = new Provider()
    const output = p.buildIssuers(fixture2)
    expect(output).toMatchObject([])
  })

  test('buildIssuers: With composite, name and no content key/value returns []', async () => {
    const p = new Provider()
    const output = p.buildIssuers(fixture3)
    expect(output).toMatchObject([])
  })
})
