import { isNil, isEmpty } from 'lodash'
import { Mapper } from '../../datasources'

export default {
  Query: {
    getCountries: async (_, {}, context) => {
      const api = context.injector.get(Mapper)
      const response = await api.getCountries()

      const countriesList: [any] = response.data ? response.data : response

      if (isNil(countriesList) || isEmpty(countriesList)) {
        return []
      }

      const count = countriesList.length

      return {
        countriesList,
        count
      }
    }
  }
}
