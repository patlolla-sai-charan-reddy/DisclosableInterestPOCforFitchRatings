import 'graphql-import-node'
import { GraphQLModule } from '@graphql-modules/core'
import * as typeDefs from './countries.graphql'
import resolvers from './resolvers'
import { Mapper } from '../../datasources'

const CountriesModule = new GraphQLModule({
  providers: [Mapper],
  typeDefs,
  resolvers,
  resolverValidationOptions: { requireResolversForResolveType: false }
})

export default CountriesModule
