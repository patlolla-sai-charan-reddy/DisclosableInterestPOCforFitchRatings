import { isEmpty, isNil, find, lowerFirst, replace } from 'lodash'
import { Injectable } from '@graphql-modules/di'

@Injectable()
export default class RACProvider {
  getComposites = ({
    analystContactsList,
    criteriaReportList,
    mediaContactsList,
    docContentList,
    documentContentList,
    solicitationVO,
    embeddedRatingList,
    primaryReportList,
    entitiesList,
    issuerTaggingList
  }) => {
    const composites = [
      {
        name: 'analystContactsList',
        content: analystContactsList
      },
      {
        name: 'mediaContactsList',
        content: mediaContactsList
      },
      {
        name: 'criteriaReportList',
        content: criteriaReportList
      },
      {
        name: 'solicitationVO',
        content: solicitationVO
      },
      {
        name: 'embeddedRatingList',
        content: embeddedRatingList
      },
      {
        name: 'primaryReportList',
        content: primaryReportList
      },
      {
        name: 'entitiesList',
        content: entitiesList
      },
      {
        name: 'issuerTaggingList',
        content: issuerTaggingList
      }
    ]

    // documentContentList || docContentList
    if (isNil(documentContentList)) {
      composites.push({
        name: 'docContentList',
        content: docContentList
      })
    } else {
      composites.push({
        name: 'documentContentList',
        content: documentContentList
      })
    }

    return composites
  }

  getDisclosableOrDisqualifyingText = (rac: any, columnHeaders: any) => {
    if (isEmpty(columnHeaders)) return []

    const keys = [
      'isDisclosableEUFlag',
      'isDisclosableNonEUFlag',
      'isDisqualifyingEUFlag',
      'isDisqualifyingNonEUFlag'
    ]
    const index = find(keys, k => {
      return rac[k] === true
    })
    const textValueProperty = lowerFirst(
      replace(replace(index as string, 'Flag', 'Text'), 'is', '')
    )
    return columnHeaders[textValueProperty]
  }

  getEndorsementPolicy = () =>
    '<p class="endorsement-policy" id="endorsement_policy" style="display: block;"><span class="endorsementTitle">Endorsement Policy</span>Fitch\'s approach to ratings endorsement so that ratings produced outside the EU may be used by regulated entities within the EU for regulatory purposes, pursuant to the terms of the EU Regulation with respect to credit rating agencies, can be found on the <a href="https://www.fitchratings.com/regulatory" target="new">EU Regulatory Disclosures</a> page. The endorsement status of all International ratings is provided within the entity summary page for each rated entity and in the transaction detail pages for all structured finance transactions on the Fitch website. These disclosures are updated on a daily basis.</p>'

  getSolicitationStatus = () =>
    'The ratings above were solicited and assigned or maintained at the request of the rated entity/issuer or a related third party. Any exceptions follow below.'

  getAdditionalDisclosures = dbDocId =>
    `<ul><li><a href="/site/dodd-frank-disclosure/${dbDocId}" target="_blank" rel="noopener noreferrer"></a><a href="#solicitation">Solicitation Status</a><a href="/site/regulatory">Endorsement Policy</a></li></ul>`
}
