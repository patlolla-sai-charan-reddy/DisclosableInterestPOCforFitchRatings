import { get, has, first, isNil, isEmpty } from 'lodash'
import { GraphQLDate } from 'graphql-iso-date'
import GraphQLJSON from 'graphql-type-json'
import { DataServices, PgClient, Research } from '../../datasources'
// import { DocIdHandling } from '../../ErroHandling/rac/index'

export default {
  MarketingTagsList: {
    spotLightImage: ({ spotLightImage }) => {
      if (spotLightImage) {
        spotLightImage.effectiveDate = new Date(spotLightImage.effectiveDate)
        spotLightImage.expiryDate = new Date(spotLightImage.expiryDate)
        return spotLightImage
      } else {
        return {}
      }
    }
  },
  Mutation: {
    postResearch: async (_, { docType, research }, context) => {
      const updateDB = async (values, type) => {
        const upsertQuery = {
          text:
            'INSERT INTO issuers ("entryType", "entryId", doc, "createdBy", "createdDate") VALUES($1, $2, $3, $4, $5) ON CONFLICT ("entryId") DO UPDATE SET doc = $3, "modifiedDate"= $5 RETURNING *',
          values
        }

        const res = await PgClient.query(upsertQuery)

        if (res) {
          return {
            status: `${type} updated successfully.`
          }
        } else {
          return {
            status: `${type} update failed.`
          }
        }
      }
      if (docType === 'issuer') {
        const { dbDocId: groupID, marketing } = research
        const values = [
          docType,
          groupID,
          marketing,
          'Admin',
          new Date().toISOString()
        ]
        return await updateDB(values, 'Issuer')
      } else if (docType === 'transaction') {
        const { dbDocId: transactionID, marketing } = research
        const values = [
          docType,
          transactionID,
          marketing,
          'Admin',
          new Date().toISOString()
        ]
        return await updateDB(values, 'Transaction')
      } else {
        const { dbDocId: dbDocID, marketing, racNrac } = research
        const api = context.injector.get(Research)

        const getDocType = () => {
          let docType = 'rpt'
          if (racNrac === 'R') {
            docType = 'rac'
          } else {
            docType = 'nrac'
          }
          return docType
        }

        try {
          await api.putResearch(getDocType(), dbDocID, marketing)
          return {
            status: 'Research updated successfully.'
          }
        } catch (error) {
          console.error(error)
          return {
            status: 'Research update failed.'
          }
        }
      }
    }
  },
  Query: {
    getRAC: async (_, { docType, id }, context) => {
      const validateResearchResponse = response => {
        if (
          !has(response, 'data') ||
          isNil(first(response.data)) ||
          isEmpty(first(response.data))
        ) {
          // throw new DocIdHandling(
          //   'Sorry, The ID you are searching for do not have Data'
          // )
          return []
        }

        if (!get(response, 'data[0].marketing')) {
          // throw new DocIdHandling(
          //   'Sorry, The ID you are searching for did not have Marketing Data'
          // )
          return []
        }

        return response
      }

      const validateDataServicesResponse = response => {
        if (!has(response, 'data')) {
          return []
        }

        if (
          !has(response, 'data.attributes') ||
          !has(response, 'data.attributes.marketing') ||
          isEmpty(response.data.attributes.marketing)
        ) {
          return []
        }
        return response
      }

      const fetchObject = {
        issuer: {
          api: context.injector.get(DataServices).getIssuer(id)
        },
        research: {
          api: context.injector.get(Research).getRAC(id),
          reportApi: context.injector.get(Research).getReport(id)
        },
        transaction: {
          api: context.injector.get(DataServices).getTransaction(id)
        }
      }

      let doc = fetchObject[docType]

      let rac = await doc.api

      if (docType === 'issuer') {
        rac = JSON.parse(rac)
        rac = validateDataServicesResponse(rac)
        rac = rac.data.attributes
        const { name: title, groupID: dbDocId, marketing } = rac
        return {
          title,
          dbDocId,
          marketing
        }
      } else if (docType === 'transaction') {
        rac = JSON.parse(rac)
        rac = validateDataServicesResponse(rac)
        rac = rac.data.attributes
        const { agntStateName: title, transactionID: dbDocId, marketing } = rac
        return {
          title,
          dbDocId,
          marketing
        }
      } else {
        let emptyRac = isEmpty(validateResearchResponse(rac))
        let report = emptyRac ? await doc.reportApi : rac
        report = validateResearchResponse(report)
        report = first(report.data)
        const { dbDocID: dbDocId, marketing, racNrac, title } = report

        return {
          dbDocId,
          marketing,
          racNrac,
          title
        }
      }
    }
  },
  GraphQLDate,
  GraphQLJSON
}
