import 'graphql-import-node'
import { GraphQLModule } from '@graphql-modules/core'
import * as typeDefs from './rac.graphql'
import resolvers from './resolvers'
import { DataServices, Research } from '../../datasources'
// import MarketingModule from '../marketing'
import RelatedModule from '../related'
import AuthorModule from '../author'
import RACProvider from './rac.provider'
import ParagraphsModule from '../paragraphs'
import AcceptableCriteriaModule from '../acceptableCriteria'
import SolicitationModule from '../solicitation'
import EmbeddedRatingModule from '../embeddedRating'
import PrimaryReportModule from '../primaryReport'
import InstitutionModule from '../institution'

const RACModule = new GraphQLModule({
  providers: [DataServices, Research, RACProvider],
  typeDefs,
  resolvers,
  resolverValidationOptions: { requireResolversForResolveType: false },
  imports: [
    AuthorModule,
    ParagraphsModule,
    // MarketingModule,
    RelatedModule,
    AcceptableCriteriaModule,
    SolicitationModule,
    EmbeddedRatingModule,
    PrimaryReportModule,
    InstitutionModule
  ]
})

export default RACModule
