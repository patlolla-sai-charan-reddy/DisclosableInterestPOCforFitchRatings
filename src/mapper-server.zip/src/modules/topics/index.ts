import 'graphql-import-node'
import { GraphQLModule } from '@graphql-modules/core'
import * as typeDefs from './topics.graphql'
import Provider from './provider'
import resolvers from './resolvers'
import { Mapper } from '../../datasources'

const TopicsModule = new GraphQLModule({
  providers: [Mapper, Provider],
  typeDefs,
  resolvers,
  resolverValidationOptions: { requireResolversForResolveType: false }
})

export default TopicsModule
