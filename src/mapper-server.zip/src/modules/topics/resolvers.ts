// import { isNil, isEmpty } from 'lodash'

import { Mapper } from '../../datasources'
import Provider from './provider'
import GraphQLLong from 'graphql-type-long'

export default {
  Mutation: {
    addTopics: async (_, { topics }, { injector }) => {
      const api = injector.get(Mapper)

      try {
        await api.addTopics(topics)
        return {
          status: 'Topics added successfully.'
        }
      } catch (error) {
        console.error(error)
        return {
          status: 'Topics add failed.'
        }
      }
    },
    deleteTopics: async (_, { ids }, context) => {
      const api = context.injector.get(Mapper)

      try {
        await api.deleteTopics(ids)
        return {
          status: 'Topics deleted successfully.'
        }
      } catch (error) {
        console.error(error)
        return {
          status: 'Topics delete failed.'
        }
      }
    },
    updateTopics: async (_, { topics }, { injector }) => {
      const api = injector.get(Mapper)

      try {
        await api.updateTopics(topics)
        return {
          status: 'Topics updated successfully.'
        }
      } catch (error) {
        console.error(error)
        return {
          status: 'Topics update failed.'
        }
      }
    }
  },
  Query: {
    getTopics: async (_, { page, pageSize }, { injector }) => {
      const api = injector.get(Mapper)
      const provider = injector.get(Provider)
      const topics = await api.getTopics()
      return provider.buildTopics(page, pageSize, topics)
    }
  },
  GraphQLLong
}
