// import { map } from 'lodash'
import { Injectable } from '@graphql-modules/di'

@Injectable()
export default class TopicProvider {
  buildTopics = (page, pageSize, topics) => {
    const fromIndex = page * pageSize
    const toIndex = (page + 1) * pageSize
    const count = topics.length
    return {
      topics: topics.slice(fromIndex, toIndex),
      count
    }
  }
}
