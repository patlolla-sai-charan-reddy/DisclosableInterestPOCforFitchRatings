/* eslint class-methods-use-this: 0 */
import { Injectable } from '@graphql-modules/di'
import lo from 'lodash'

@Injectable()
export default class MarketingProvider {
  buildMarketingTags(composites) {
    const marketing = lo.find(composites, c => c.name === 'marketing')

    if (
      !lo.hasIn(marketing, 'content') ||
      !lo.hasIn(marketing, 'content.mappedMarketSectors') ||
      !lo.hasIn(marketing, 'content.regions')
    ) {
      return {
        sectors: [],
        regions: [],
        canonicalUrl: ''
      }
    }

    const { mappedMarketSectors, canonicalUrl, regions } = marketing.content

    const sectorList = mappedMarketSectors.map(sec => {
      return {
        name: sec,
        url: 'http://example.com'
      }
    })

    const regionList = regions.map(r => {
      return {
        name: r,
        url: 'http://example.com'
      }
    })

    return {
      sectors: sectorList,
      regions: regionList,
      canonicalUrl
    }
  }
}
