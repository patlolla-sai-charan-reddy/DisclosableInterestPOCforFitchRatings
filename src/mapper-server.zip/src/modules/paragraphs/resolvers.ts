import ParagraphsProvider from './paragraphs.provider'

export default {
  RAC: {
    paragraphs: async (rac, _, context) => {
      return context.injector
        .get(ParagraphsProvider)
        .buildParagraphs(rac.composites)
    }
  }
}
