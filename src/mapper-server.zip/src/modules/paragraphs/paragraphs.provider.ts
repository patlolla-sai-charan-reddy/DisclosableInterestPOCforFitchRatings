/* eslint class-methods-use-this: 0 */
import { Injectable } from '@graphql-modules/di'
import 'reflect-metadata'
import lo from 'lodash'

@Injectable()
export default class ParagraphsProvider {
  buildParagraphs(composites): Array<Object> {
    const documentContentList = lo.find(
      composites,
      c => c.name === 'documentContentList'
    )

    if (!lo.hasIn(documentContentList, 'content')) {
      return []
    }

    return lo
      .chain(documentContentList.content)
      .map(
        ({
          fieldName: name,
          fieldHeader: header,
          fieldSubHeader: subHeader,
          isDisplayHeader: showHeader,
          fieldContent: content
        }) => ({
          name,
          header,
          subHeader,
          showHeader,
          content
        })
      )
      .map(p =>
        lo.mapValues(p, val => (lo.isNil(val) ? lo.toString(val) : val))
      )
      .value()
  }
}
