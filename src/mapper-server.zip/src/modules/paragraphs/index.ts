import { GraphQLModule } from '@graphql-modules/core'
import * as typeDefs from './paragraphs.graphql'
import resolvers from './resolvers'
import ParagraphsProvider from './paragraphs.provider'

const ParagraphsModule = new GraphQLModule({
  typeDefs,
  resolvers,
  providers: [ParagraphsProvider],
  resolverValidationOptions: { requireResolversForResolveType: false }
})

export default ParagraphsModule
