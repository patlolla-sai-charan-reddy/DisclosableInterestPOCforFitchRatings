import 'graphql-import-node'
import { GraphQLModule } from '@graphql-modules/core'
import * as typeDefs from './regions.graphql'
import resolvers from './resolvers'
import { Mapper } from '../../datasources'

const RegionsModule = new GraphQLModule({
  providers: [Mapper],
  typeDefs,
  resolvers,
  resolverValidationOptions: { requireResolversForResolveType: false }
})

export default RegionsModule
