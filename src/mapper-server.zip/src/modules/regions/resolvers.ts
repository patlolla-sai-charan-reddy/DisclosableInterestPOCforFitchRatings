import { isNil, isEmpty } from 'lodash'
import { Mapper } from '../../datasources'

export default {
  Query: {
    getRegions: async (_, {}, context) => {
      const api = context.injector.get(Mapper)
      const response = await api.getRegions()

      const regionsList: [any] = response.data ? response.data : response

      if (isNil(regionsList) || isEmpty(regionsList)) {
        return []
      }

      const count = regionsList.length

      return {
        regionsList,
        count
      }
    }
  }
}
