import { GraphQLModule } from '@graphql-modules/core'
import * as typeDefs from './primaryReport.graphql'
import resolvers from './resolvers'
import PrimaryReportProvider from './primaryReport.provider'

const PrimaryReportModule = new GraphQLModule({
  typeDefs,
  resolvers,
  providers: [PrimaryReportProvider],
  resolverValidationOptions: { requireResolversForResolveType: false }
})

export default PrimaryReportModule
