import 'reflect-metadata'
import PrimaryProvider from '../primaryReport.provider'

/**
 * 1. Test with known structure we get back object as we expect
 * 2. With no composite found, we are safe
 * 3. With composite and no value on composite we are safe
 */

const example = [
  {
    title: 'Research French',
    reportId: 10059127
  }
]

const fixture1 = {
  composites: [
    {
      name: 'primaryReportList',
      content: [
        {
          reportTitle: 'Research French',
          reportID: 10059127,
          dtpReportID: 943920,
          publishedDate: null
        }
      ]
    }
  ]
}

const fixture2 = {
  composites: {
    name: 'primaryReportList',
    content: []
  }
}

const fixture3 = {
  composites: {
    name: 'primaryReportList'
  }
}

describe('Primary Report Module provider testsuite', () => {
  test('buildPRList: Should return defined output', async () => {
    const p = new PrimaryProvider()
    const output = p.buildPRList(fixture1.composites)
    expect(output).toBeTruthy()
  })

  test('buildPRList: Should return an array with 1 AcceptableCriteria Object matching known spec', async () => {
    const P = new PrimaryProvider()
    const output = P.buildPRList(fixture1.composites)
    expect(output).toMatchObject(example)
  })

  test('buildPRList: With no composite found, return {"count": 0, "rows": []}', async () => {
    const p = new PrimaryProvider()
    const output = p.buildPRList('')
    expect(output).toMatchObject([])
  })

  test('buildPRList: With composite and no content', async () => {
    const p = new PrimaryProvider()
    const output = p.buildPRList(fixture2)
    expect(output).toMatchObject([])
  })

  test('documentContentList: With composite, name and no content key/value returns []', async () => {
    const p = new PrimaryProvider()
    const output = p.buildPRList(fixture3)
    expect(output).toMatchObject([])
  })
})
