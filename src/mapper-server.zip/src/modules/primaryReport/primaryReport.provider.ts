import { Injectable } from '@graphql-modules/di'
/* eslint class-methods-use-this: 0 */
import lo from 'lodash'

@Injectable()
export default class PrimaryReportProvider {
  buildPRList(composites) {
    const primaryReportList = lo.find(
      composites,
      c => c.name === 'primaryReportList'
    )

    if (!lo.hasIn(primaryReportList, 'content')) {
      return []
    }

    const listing = primaryReportList.content.map(pr => {
      const { reportTitle: title, reportID: reportId } = pr
      return {
        title,
        reportId
      }
    })
    return listing
  }
}
