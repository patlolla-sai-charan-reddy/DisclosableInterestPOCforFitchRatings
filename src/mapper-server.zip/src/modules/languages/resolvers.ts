import { isNil, isEmpty } from 'lodash'
import { Mapper } from '../../datasources'

export default {
  Query: {
    getLanguages: async (_, {}, context) => {
      const api = context.injector.get(Mapper)
      const response = await api.getLanguages()

      const languagesList: [any] = response.data ? response.data : response

      if (isNil(languagesList) || isEmpty(languagesList)) {
        return []
      }

      const count = languagesList.length

      return {
        languagesList,
        count
      }
    }
  }
}
