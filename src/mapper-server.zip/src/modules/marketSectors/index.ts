import 'graphql-import-node'
import { GraphQLModule } from '@graphql-modules/core'
import * as typeDefs from './marketSectors.graphql'
import resolvers from './resolvers'
import { Mapper } from '../../datasources'

const MarketSectorsModule = new GraphQLModule({
  providers: [Mapper],
  typeDefs,
  resolvers,
  resolverValidationOptions: { requireResolversForResolveType: false }
})

export default MarketSectorsModule
