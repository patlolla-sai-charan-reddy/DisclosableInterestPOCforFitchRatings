import { isNil, isEmpty } from 'lodash'
import { Mapper } from '../../datasources'

export default {
  Query: {
    getMarketSectors: async (_, {}, context) => {
      const api = context.injector.get(Mapper)
      const response = await api.getMarketSectors()

      const marketSectorsList: [any] = response.data ? response.data : response

      if (isNil(marketSectorsList) || isEmpty(marketSectorsList)) {
        return []
      }

      const count = marketSectorsList.length

      return {
        marketSectorsList,
        count
      }
    }
  }
}
