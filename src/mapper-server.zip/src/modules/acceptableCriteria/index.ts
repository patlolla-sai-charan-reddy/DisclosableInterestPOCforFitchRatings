import { GraphQLModule } from '@graphql-modules/core'
import * as typeDefs from './acceptableCriteria.graphql'
import resolvers from './resolvers'
import AcceptableCriteriaProvider from './acceptableCriteria.provider'

const AcceptableCriteriaModule = new GraphQLModule({
  typeDefs,
  resolvers,
  providers: [AcceptableCriteriaProvider],
  resolverValidationOptions: { requireResolversForResolveType: false }
})

export default AcceptableCriteriaModule
