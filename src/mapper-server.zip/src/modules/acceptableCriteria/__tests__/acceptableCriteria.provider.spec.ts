import 'reflect-metadata'
import ACProvider from '../acceptableCriteria.provider'

/**
 * 1. Test with known structure we get back object as we expect
 * 2. With no composite found, we are safe
 * 3. With composite and no value on composite we are safe
 */

const acceptableCriteriaExample = {
  id: 10020624,
  publishedDate: new Date(1519312276344),
  title: 'U.S. Public Finance Structured Finance Rating Criteria'
}

const fixture1 = {
  composites: [
    {
      name: 'criteriaReportList',
      content: [
        {
          reportID: 10020624,
          reportTitle: 'U.S. Public Finance Structured Finance Rating Criteria',
          reportPublishDate: 1519312276344
        }
      ]
    }
  ]
}

const fixture2 = {
  composites: {
    name: 'criteriaReportList',
    content: []
  }
}

const fixture3 = {
  composites: {
    name: 'criteriaReportList'
  }
}

describe('Acceptable Criteria provider testsuite', () => {
  test('buildAnalysts: Should return defined output', async () => {
    const p = new ACProvider()
    const output = p.buildACList(fixture1.composites)
    expect(output).toBeTruthy()
  })

  test('buildACList: Should return an array with 1 AcceptableCriteria Object matching known spec', async () => {
    const P = new ACProvider()
    const output = P.buildACList(fixture1.composites)
    expect(output).toMatchObject([acceptableCriteriaExample])
  })

  test('buildACList: With no composite found, return []', async () => {
    const p = new ACProvider()
    const output = p.buildACList('')
    expect(output).toMatchObject([])
  })

  test('buildACList: With composite and no content', async () => {
    const p = new ACProvider()
    const output = p.buildACList(fixture2)
    expect(output).toMatchObject([])
  })

  test('buildACList: With composite, name and no content key/value returns []', async () => {
    const p = new ACProvider()
    const output = p.buildACList(fixture3)
    expect(output).toMatchObject([])
  })
})
