import 'reflect-metadata'
import ERProvider from '../embeddedRating.provider'

/**
 * 1. Test with known structure we get back object as we expect
 * 2. With no composite found, we are safe
 * 3. With composite and no value on composite we are safe
 */

const example = {
  level: '1',
  priorRatingCode: '',
  priorWatchOutlookCode: '',
  ratingAction: null,
  ratingCode: null,
  recoveryRating: '',
  title: 'Colorado Water Resources & Power Development Authority (CO)',
  typeAbbr: null,
  typeDesc: null,
  watchOutlookCode: ''
}

const fixture1 = {
  composites: [
    {
      name: 'embeddedRatingList',
      content: [
        {
          level: '1',
          description:
            'Colorado Water Resources & Power Development Authority (CO)',
          ratingTypeAbbr: null,
          ratingTypeDesc: null,
          ratingCode: null,
          watchOutlookCd: '',
          ratingAction: null,
          priorRatingCode: '',
          recoveryRating: '',
          priorWatchOutlookCd: '',
          issuerID: '96249615',
          issueID: '',
          ratingActionId: '',
          ratingID: '',
          ratingCdId: '',
          ratingTypeId: '',
          watchOutlookId: '',
          debtLevelId: ''
        }
      ]
    }
  ]
}

const fixture2 = {
  composites: {
    name: 'embeddedRatingList',
    content: []
  }
}

const fixture3 = {
  composites: {
    name: 'embeddedRatingList'
  }
}

describe('Embedded Rating provider testsuite', () => {
  test('buildEmbeddedRatings: Should return defined output', async () => {
    const p = new ERProvider()
    const output = p.buildEmbeddedRatings(fixture1.composites)
    expect(output).toBeTruthy()
  })

  test('buildEmbeddedRatings: Should return an array with 1 AcceptableCriteria Object matching known spec', async () => {
    const P = new ERProvider()
    const output = P.buildEmbeddedRatings(fixture1.composites)
    expect(output).toMatchObject({ count: 1, rows: [example] })
  })

  test('buildEmbeddedRatings: With no composite found, return {"count": 0, "rows": []}', async () => {
    const p = new ERProvider()
    const output = p.buildEmbeddedRatings('')
    expect(output).toMatchObject({ count: 0, rows: [] })
  })

  test('buildEmbeddedRatings: With composite and no content', async () => {
    const p = new ERProvider()
    const output = p.buildEmbeddedRatings(fixture2)
    expect(output).toMatchObject({ count: 0, rows: [] })
  })

  test('buildEmbeddedRatings: With composite, name and no content key/value returns []', async () => {
    const p = new ERProvider()
    const output = p.buildEmbeddedRatings(fixture3)
    expect(output).toMatchObject({ count: 0, rows: [] })
  })
})
