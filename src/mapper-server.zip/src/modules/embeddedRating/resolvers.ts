import EmbeddedRatingProvider from './embeddedRating.provider'

export default {
  RAC: {
    embeddedRatings: async (rac, _, context) => {
      return context.injector
        .get(EmbeddedRatingProvider)
        .buildEmbeddedRatings(rac.composites)
    }
  }
}
