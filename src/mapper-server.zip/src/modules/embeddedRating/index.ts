import { GraphQLModule } from '@graphql-modules/core'
import * as typeDefs from './embeddedRating.graphql'
import resolvers from './resolvers'
import EmbeddedRatingProvider from './embeddedRating.provider'

const EmbeddedRatingModule = new GraphQLModule({
  typeDefs,
  resolvers,
  providers: [EmbeddedRatingProvider],
  resolverValidationOptions: { requireResolversForResolveType: false }
})

export default EmbeddedRatingModule
