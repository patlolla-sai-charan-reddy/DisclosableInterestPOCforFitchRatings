import AuthorProvider from './author.provider'

export default {
  RAC: {
    analysts: async (rac, _, context) => {
      return context.injector.get(AuthorProvider).buildAnalysts(rac.composites)
    },
    mediaContacts: async (rac, _, context) => {
      return context.injector
        .get(AuthorProvider)
        .buildMediaContacts(rac.composites)
    }
  }
}
