import 'reflect-metadata'
import AuthorProvider from '../author.provider'

/**
 * 1. Test with known structure we get back object as we expect
 * 2. With no composite found, we are safe
 * 3. With composite and no value on composite we are safe
 */

const analyst = {
  type: 'Primary Rating Analyst',
  firstName: 'Linda',
  lastName: 'Friedman',
  employeeNumber: 105725,
  title: 'Senior Director',
  phoneNumber: '+1 212 908 0727',
  address: 'Fitch Ratings, Inc. 33 Whitehall Street  New York 10004'
}

const fixture1 = {
  composites: [
    {
      name: 'analystContactsList',
      content: [
        {
          type: 'Primary Rating Analyst',
          firstName: 'Linda',
          lastName: 'Friedman',
          employeeNumber: 105725,
          professional: '',
          title: 'Senior Director',
          phoneNumber: '+1 212 908 0727',
          analystAddress: [
            {
              locationId: 58,
              companyLocation: 'New York 10004',
              companyStreetAddress: '33 Whitehall Street ',
              companyDesc: 'Fitch Ratings, Inc.'
            }
          ]
        }
      ]
    }
  ]
}

const fixture2 = {
  composites: [
    {
      name: 'analystContactsList',
      content: []
    }
  ]
}

const fixture3 = {
  composites: [
    {
      name: 'analystContactsList'
    }
  ]
}

describe('Author provider testsuite', () => {
  test('buildAnalysts: Should return defined output', async () => {
    const provider = new AuthorProvider()
    const output = provider.buildAnalysts(fixture1.composites)
    expect(output).toBeTruthy()
  })

  test('buildAnalysts: Should return an array with 1 Analyst Object matching known spec', async () => {
    const provider = new AuthorProvider()
    const output = provider.buildAnalysts(fixture1.composites)
    expect(output).toMatchObject([analyst])
  })

  test('buildAnalysts: With no composite found, return []', async () => {
    const provider = new AuthorProvider()
    const output = provider.buildAnalysts('')
    expect(output).toMatchObject([])
  })

  test('buildAnalysts: With composite and no content', async () => {
    const provider = new AuthorProvider()
    const output = provider.buildAnalysts(fixture2)
    expect(output).toMatchObject([])
  })

  test('buildAnalysts: With composite, name and no content key/value returns []', async () => {
    const provider = new AuthorProvider()
    const output = provider.buildAnalysts(fixture3)
    expect(output).toMatchObject([])
  })
})
