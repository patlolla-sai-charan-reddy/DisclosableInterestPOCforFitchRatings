import { GraphQLModule } from '@graphql-modules/core'
import * as typeDefs from './author.graphql'
import resolvers from './resolvers'
import AuthorProvider from './author.provider'

const AuthorModule = new GraphQLModule({
  typeDefs,
  resolvers,
  providers: [AuthorProvider],
  resolverValidationOptions: { requireResolversForResolveType: false }
})

export default AuthorModule
