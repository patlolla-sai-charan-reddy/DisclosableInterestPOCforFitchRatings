import 'reflect-metadata'
import 'graphql-import-node'
import { GraphQLModule } from '@graphql-modules/core'
import EntitiesListModule from './entitiesList'
import ImageModule from './image'
// import IssuerModule from './issuer'
import RACModule from './rac'
import CountriesModule from './countries'
import LanguagesModule from './languages'
import MarketSectorsModule from './marketSectors'
import RegionsModule from './regions'
import TopicsModule from './topics'
// import TransactionModule from './transaction'

const AppModule = new GraphQLModule({
  imports: [
    EntitiesListModule,
    ImageModule,
    // IssuerModule,
    RACModule,
    CountriesModule,
    MarketSectorsModule,
    LanguagesModule,
    RegionsModule,
    TopicsModule
    // TransactionModule
  ],
  resolverValidationOptions: { requireResolversForResolveType: false }
})

export default AppModule
