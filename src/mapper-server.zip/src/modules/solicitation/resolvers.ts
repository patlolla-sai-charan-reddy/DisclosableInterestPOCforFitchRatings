import SolicitationProvider from './solicitation.provider'

export default {
  RAC: {
    unsolicitedIssuers: async (rac, _, context) => {
      return context.injector
        .get(SolicitationProvider)
        .buildSolList(rac.composites)
    }
  }
}
