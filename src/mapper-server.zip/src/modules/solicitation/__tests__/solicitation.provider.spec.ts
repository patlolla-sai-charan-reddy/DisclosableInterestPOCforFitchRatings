import 'reflect-metadata'
import SolProvider from '../solicitation.provider'

/**
 * 1. Test with known structure we get back object as we expect
 * 2. With no composite found, we are safe
 * 3. With composite and no value on composite we are safe
 */

const example = {
  rows: [
    {
      typeDesc: 'Unsolicited',
      rtngDesc: 'Long Term Issuer Default Rating',
      bondName: 'Rio Tinto Ltd',
      isin: null
    }
  ],
  count: 1
}

const fixture1 = {
  composites: [
    {
      name: 'solicitationVO',
      content: {
        solicitationVOList: [
          {
            solicitTypeId: 7,
            solicitTypeDesc: 'Unsolicited',
            rtngDesc: 'Long Term Issuer Default Rating',
            bondName: 'Rio Tinto Ltd',
            cspNum: null,
            isin: null,
            fxdCpnRt: 0
          }
        ]
      }
    }
  ]
}

const fixture2 = {
  composites: {
    name: 'solicitationVO',
    content: {
      solicitationVOList: []
    }
  }
}

const fixture3 = {
  composites: {
    name: 'solicitationVO'
  }
}

describe('Institution Module provider testsuite', () => {
  test('buildSolList: Should return defined output', async () => {
    const p = new SolProvider()
    const output = p.buildSolList(fixture1.composites)
    expect(output).toBeTruthy()
  })

  test('buildSolList: Should return an array with 1 AcceptableCriteria Object matching known spec', async () => {
    const P = new SolProvider()
    const output = P.buildSolList(fixture1.composites)
    expect(output).toMatchObject(example)
  })

  test('buildSolList: With no composite found, return {"count": 0, "rows": []}', async () => {
    const p = new SolProvider()
    const output = p.buildSolList('')
    expect(output).toMatchObject({ count: 0, rows: [] })
  })

  test('buildSolList: With composite and no content', async () => {
    const p = new SolProvider()
    const output = p.buildSolList(fixture2)
    expect(output).toMatchObject({
      rows: [],
      count: 0
    })
  })

  test('buildSolList: With composite, name and no content key/value returns []', async () => {
    const p = new SolProvider()
    const output = p.buildSolList(fixture3)
    expect(output).toMatchObject({
      rows: [],
      count: 0
    })
  })
})
