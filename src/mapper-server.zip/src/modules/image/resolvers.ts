import { mapValues } from 'lodash'
import { ContentfulEnvironment } from '../../datasources'

export default {
  Mutation: {
    uploadImage: async (_, { title, description, file }) => {
      const { createReadStream, filename, mimetype } = await file
      const uploadStream = createReadStream()

      const environment = await ContentfulEnvironment()

      try {
        const uploadFile = await environment.createUpload({
          file: uploadStream,
          uploadStream: mimetype
        })

        const image = {
          title: title,
          description: description,
          file: {
            contentType: mimetype,
            fileName: filename,
            uploadFrom: {
              sys: {
                type: 'Link',
                linkType: 'Upload',
                id: uploadFile.sys.id
              }
            }
          }
        }

        const contentfulImage = { fields: {} }
        contentfulImage.fields = mapValues(image, field => ({ 'en-US': field }))

        const asset = await environment.createAsset(contentfulImage)
        const assetProcessedForLocales = await asset.processForAllLocales()
        const publishedAsset = await assetProcessedForLocales.publish()
        // await asset.publish()
        return {
          status: 'Image uploaded successfully.',
          url: publishedAsset.fields.file['en-US'].url
        }
      } catch (error) {
        console.error(error)
        return { status: 'Image upload failed.' }
      }
    }
  }
}
