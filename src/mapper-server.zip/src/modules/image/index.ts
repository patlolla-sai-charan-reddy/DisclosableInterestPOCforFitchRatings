import 'graphql-import-node'
import { GraphQLModule } from '@graphql-modules/core'
import * as typeDefs from './image.graphql'
import resolvers from './resolvers'

const ImageModule = new GraphQLModule({
  typeDefs,
  resolvers,
  resolverValidationOptions: { requireResolversForResolveType: false }
})

export default ImageModule
