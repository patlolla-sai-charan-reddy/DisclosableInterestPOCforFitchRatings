import { Injectable } from '@graphql-modules/di'
import { RESTDataSource } from 'apollo-datasource-rest'

@Injectable()
export default class Mapper extends RESTDataSource {
  baseURL = process.env.SEARCH_API_URL

  async getEntitiesList(term: string) {
    return this.get(`/${term}`)
  }
}
