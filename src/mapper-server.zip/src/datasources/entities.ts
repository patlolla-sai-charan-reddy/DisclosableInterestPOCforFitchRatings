import { Injectable } from '@graphql-modules/di'
import { RESTDataSource } from 'apollo-datasource-rest'

@Injectable()
export default class Entities extends RESTDataSource {
  baseURL = process.env.ENTITIES_API_URL

  async getEntities() {
    return this.get('/')
  }

  async getEntity(id: number) {
    return this.get(`/${id}`)
  }
}
