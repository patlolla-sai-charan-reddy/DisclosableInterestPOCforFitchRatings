import { Injectable } from '@graphql-modules/di'
import { HTTPCache, RESTDataSource } from 'apollo-datasource-rest'

@Injectable()
export default class Mapper extends RESTDataSource {
  baseURL = process.env.MAPPER_API_URL_DEV

  initialize({ context }) {
    this.context = context
    this.httpCache = new HTTPCache()
    this.memoizedResults.clear()
  }

  // get data for dropdowns

  async getCountries() {
    return this.get('/countryTypeMappings')
  }

  async getLanguages() {
    return this.get('/languageMappings')
  }

  async getMarketSectors() {
    return this.get('/marketSectorMappings')
  }

  async getRegions() {
    return this.get('/regionsMappings')
  }

  // topics table operations

  async addTopics(topics) {
    return this.post('/addTopics', topics)
  }

  async deleteTopics(ids) {
    return this.post('/deleteTopics', ids)
  }

  async getTopics() {
    return this.get('/topicTypeMappings')
  }

  async updateTopics(topics) {
    return this.post('/updateTopics', topics)
  }
}
