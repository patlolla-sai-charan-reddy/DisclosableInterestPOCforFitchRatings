const { Client } = require('pg')

const PgClient = new Client({
  database: 'mapper_ui',
  host: 'pos-brm-due-rds.cvlmljjlxusn.us-east-1.rds.amazonaws.com',
  user: 'marketshare',
  password: 'marketshare',
  port: 5432
})

PgClient.connect()

export default PgClient
