import { Injectable } from '@graphql-modules/di'
import { RESTDataSource } from 'apollo-datasource-rest'

@Injectable()
export default class DataServices extends RESTDataSource {
  baseURL = process.env.DATA_SERVICES

  async getIssuer(id) {
    return this.get(`/entities/${id}`)
  }

  async getTransaction(id) {
    return this.get(`/transactions/${id}`)
  }
}
