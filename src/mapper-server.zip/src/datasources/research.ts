import { Injectable } from '@graphql-modules/di'
import {
  HTTPCache,
  RESTDataSource,
  RequestOptions
} from 'apollo-datasource-rest'

@Injectable()
export default class Research extends RESTDataSource {
  // baseURL = process.env.RESEARCH_API_URL

  initialize({ context }) {
    this.context = context
    this.httpCache = new HTTPCache()
    this.memoizedResults.clear()
  }

  willSendRequest(request: RequestOptions) {
    request.headers.set(
      'Authorization',
      'Basic ZmFkOmZhZDEyM1F4TFVGMWJnSUFkZVFYTk1lckE='
    )
  }

  async getRAC(id: number) {
    return this.get(
      `http://mobile-app-cloud-dev.fitchratings.com/research-ws-v1/rest/locating/getPressRelease?docID=${id}`
    )
  }

  async getReport(id: number) {
    return this.get(
      `http://mobile-app-cloud-dev.fitchratings.com/research-ws-v1/rest/locating/getReportViewer?reportId=${id}`
    )
  }

  async putResearch(docType: string, id: number, data: any) {
    return this.put(
      `https://fad-dev.fitchratings.com/fad/marketingInfo/${docType}/${id}`,
      data
    )
  }
}
