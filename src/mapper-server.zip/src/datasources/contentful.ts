import * as contentful from 'contentful-management'

const Contentful = contentful.createClient({
  accessToken: process.env.CONTENTFUL_ACCESS_TOKEN
})

const ContentfulEnvironment = async () => {
  const space = await Contentful.getSpace(process.env.CONTENTFUL_SPACE)
  return space.getEnvironment(process.env.CONTENTFUL_ENVIRONMENT)
}

export default ContentfulEnvironment
