import 'dotenv-safe/config'
import express from 'express'
import { ApolloServer, mergeSchemas } from 'apollo-server-express'
import depthLimit from 'graphql-depth-limit'
import AppModule from './modules'
import contentfulSchema from './contentful/contentful.schema'

const { APOLLO_INTROSPECTION, APOLLO_PLAYGROUND, APOLLO_DEBUG } = process.env

const { schema, context } = AppModule

const server = new ApolloServer({
  context,
  debug: Boolean(APOLLO_DEBUG),
  introspection: Boolean(APOLLO_INTROSPECTION),
  playground: Boolean(APOLLO_PLAYGROUND),
  schema: mergeSchemas({
    schemas: [schema, contentfulSchema]
  }),
  validationRules: [depthLimit(5)]
})

const app = express()
const path = '/graphql'

server.applyMiddleware({ app, path })

app.listen({ port: 4000 }, () => {
  console.info(
    `🚀  Server ready at http://localhost:4000/${server.graphqlPath}`
  )
  console.log(
    `Try your health check at: http://localhost:4000/.well-known/apollo/server-health`
  )
})
