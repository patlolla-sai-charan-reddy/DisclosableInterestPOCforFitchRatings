module.exports = migration => {
  const event = migration
    .createContentType('event')
    .name('Event')
    .description('')
    .displayField('title')

  event
    .createField('title')
    .name('Title')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([
      {
        unique: true
      }
    ])
    .disabled(false)
    .omitted(false)

  event
    .createField('slug')
    .name('Slug')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([
      {
        unique: true
      }
    ])
    .disabled(false)
    .omitted(false)

  event
    .createField('eventType')
    .name('Event Type')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([
      {
        in: [
          'Teleconference',
          'Webcast',
          'Fitch Ratings Hosted',
          'Fitch Ratings Sponsored',
          'Fitch Solutions Hosted'
        ],

        message: 'Please use a value from list provided'
      }
    ])
    .disabled(false)
    .omitted(false)

  event
    .createField('startDate')
    .name('Start Date')
    .type('Date')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)
  event
    .createField('endDate')
    .name('End Date')
    .type('Date')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  event
    .createField('locationName')
    .name('Location Name')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)
  event
    .createField('locationCoordinates')
    .name('Location Coordinates')
    .type('Location')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  event
    .createField('address')
    .name('Address')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)

  event
    .createField('image')
    .name('Image')
    .type('Link')
    .localized(false)
    .required(false)
    .validations([
      {
        linkMimetypeGroup: ['image']
      }
    ])
    .disabled(false)
    .omitted(false)
    .linkType('Asset')

  event
    .createField('link')
    .name('Link')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  event
    .createField('accessibility')
    .name('Accessibility')
    .type('Text')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  event
    .createField('sector')
    .name('Sector')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  event
    .createField('region')
    .name('Region')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  event
    .createField('country')
    .name('Country')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  event
    .createField('entity')
    .name('Entity')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  event
    .createField('language')
    .name('Language')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  event.changeEditorInterface('title', 'singleLine', {})
  event.changeEditorInterface('slug', 'slugEditor', {})

  event.changeEditorInterface('eventType', 'dropdown', {
    helpText: 'Specify the event type'
  })

  event.changeEditorInterface('startDate', 'datePicker', {
    ampm: '24',
    format: 'time'
  })

  event.changeEditorInterface('endDate', 'datePicker', {
    ampm: '24',
    format: 'time'
  })

  event.changeEditorInterface('locationName', 'singleLine', {
    helpText: 'Provide the name of venue'
  })

  event.changeEditorInterface('locationCoordinates', 'locationEditor', {
    helpText:
      'Please provide the location for lat/log either by browsing on map, or street address in field below map'
  })

  event.changeEditorInterface('address', 'singleLine', {
    helpText: 'Please provide the street address of venue'
  })

  event.changeEditorInterface('image', 'assetLinkEditor', {})

  event.changeEditorInterface('link', 'singleLine', {
    helpText: 'Use this to link to external event page'
  })

  event.changeEditorInterface('accessibility', 'markdown', {})
  event.changeEditorInterface('sector', 'singleLine', {})
  event.changeEditorInterface('region', 'singleLine', {})
  event.changeEditorInterface('country', 'singleLine', {})
  event.changeEditorInterface('entity', 'singleLine', {})
  event.changeEditorInterface('language', 'singleLine', {})
}
