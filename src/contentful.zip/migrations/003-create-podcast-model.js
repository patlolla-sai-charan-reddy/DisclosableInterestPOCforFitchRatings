module.exports = migration => {
  const podcast = migration
    .createContentType('podcast')
    .name('Podcast')
    .description('')
    .displayField('title')
  podcast
    .createField('embedId')
    .name('Embed ID')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)
  podcast
    .createField('title')
    .name('Title')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)
  podcast
    .createField('slug')
    .name('Slug')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)

  podcast
    .createField('image')
    .name('Image')
    .type('Link')
    .localized(false)
    .required(false)
    .validations([
      {
        linkMimetypeGroup: ['image']
      }
    ])
    .disabled(false)
    .omitted(false)
    .linkType('Asset')

  podcast
    .createField('abstract')
    .name('Abstract')
    .type('Text')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)
  podcast
    .createField('transcript')
    .name('Transcript')
    .type('Text')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)

  podcast
    .createField('featuredPeople')
    .name('Featured People')
    .type('Array')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
    .items({
      type: 'Link',

      validations: [
        {
          linkContentType: ['person']
        }
      ],

      linkType: 'Entry'
    })

  podcast
    .createField('subscriptionUrl')
    .name('Subscription URL')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  podcast
    .createField('sector')
    .name('Sector')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  podcast
    .createField('region')
    .name('Region')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  podcast
    .createField('country')
    .name('Country')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  podcast
    .createField('entity')
    .name('Entity')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  podcast
    .createField('language')
    .name('Language')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)

  podcast.changeEditorInterface('embedId', 'urlEditor', {
    helpText: 'Please provide the SoundCloud Embed URL'
  })

  podcast.changeEditorInterface('title', 'singleLine', {})
  podcast.changeEditorInterface('slug', 'slugEditor', {})
  podcast.changeEditorInterface('image', 'assetLinkEditor', {})

  podcast.changeEditorInterface('abstract', 'markdown', {
    helpText:
      'Short introduction about the podcast, used for teaser display and invite to listen'
  })

  podcast.changeEditorInterface('transcript', 'markdown', {})

  podcast.changeEditorInterface('featuredPeople', 'entryLinksEditor', {
    helpText: 'Please provide featured people within the podcast',
    bulkEditing: false
  })

  podcast.changeEditorInterface('subscriptionUrl', 'singleLine', {})
  podcast.changeEditorInterface('sector', 'singleLine', {})
  podcast.changeEditorInterface('region', 'singleLine', {})
  podcast.changeEditorInterface('country', 'singleLine', {})
  podcast.changeEditorInterface('entity', 'singleLine', {})
  podcast.changeEditorInterface('language', 'singleLine', {})
}
