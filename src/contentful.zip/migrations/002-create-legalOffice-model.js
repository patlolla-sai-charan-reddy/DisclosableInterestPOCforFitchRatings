module.exports = migration => {
  const legalOffice = migration
    .createContentType('legalOffice')
    .name('Legal Office')
    .description('')
    .displayField('name')
  legalOffice
    .createField('name')
    .name('Name')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)

  legalOffice
    .createField('email')
    .name('Email')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([
      {
        regexp: {
          pattern: '^\\w[\\w.-]*@([\\w-]+\\.)+[\\w-]+$'
        },

        message: 'Please provide a valid email address'
      }
    ])
    .disabled(false)
    .omitted(false)

  legalOffice
    .createField('website')
    .name('Website')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([
      {
        regexp: {
          pattern:
            '^(http|https):\\/\\/(\\w+:{0,1}\\w*@)?(\\S+)(:[0-9]+)?(\\/|\\/([\\w#!:.?+=&%@!\\-\\/]))?$'
        }
      }
    ])
    .disabled(false)
    .omitted(false)

  legalOffice
    .createField('phoneNumber1')
    .name('Phone Number 1')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)
  legalOffice
    .createField('phoneNumber2')
    .name('Phone Number 2')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  legalOffice
    .createField('phoneNumber3')
    .name('Phone Number 3')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)

  legalOffice.changeEditorInterface('name', 'singleLine', {
    helpText: 'Legal name of office'
  })

  legalOffice.changeEditorInterface('email', 'singleLine', {
    helpText: 'General email address for the office'
  })

  legalOffice.changeEditorInterface('website', 'singleLine', {
    helpText: 'URL for which this legal office can be access'
  })

  legalOffice.changeEditorInterface('phoneNumber1', 'singleLine', {})
  legalOffice.changeEditorInterface('phoneNumber2', 'singleLine', {})
  legalOffice.changeEditorInterface('phoneNumber3', 'singleLine', {})
}
