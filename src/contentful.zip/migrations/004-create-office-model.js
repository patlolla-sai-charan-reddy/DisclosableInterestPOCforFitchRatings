module.exports = migration => {
  const office = migration
    .createContentType('office')
    .name('Office')
    .description('')
    .displayField('name')
  office
    .createField('name')
    .name('Name')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)

  office
    .createField('legalOffices')
    .name('Legal Offices')
    .type('Array')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)
    .items({
      type: 'Link',

      validations: [
        {
          linkContentType: ['legalOffice']
        }
      ],

      linkType: 'Entry'
    })

  office
    .createField('address')
    .name('Address')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)
  office
    .createField('locationCoordinates')
    .name('Location Coordinates')
    .type('Location')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  office.changeEditorInterface('name', 'singleLine', {})

  office.changeEditorInterface('legalOffices', 'entryLinksEditor', {
    bulkEditing: false
  })

  office.changeEditorInterface('address', 'singleLine', {})

  office.changeEditorInterface('locationCoordinates', 'locationEditor', {
    helpText:
      'Please provide the location for lat/log either by browsing on map, or street address in field below map'
  })
}
