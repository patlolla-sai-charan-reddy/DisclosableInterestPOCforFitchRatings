module.exports = migration => {
  const marketSector = migration
    .createContentType('marketSector')
    .name('Market Sector')
    .description('')
    .displayField('title')

  marketSector
    .createField('title')
    .name('Title')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([
      {
        unique: true
      }
    ])
    .disabled(false)
    .omitted(false)

  marketSector
    .createField('slug')
    .name('Slug')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([
      {
        unique: true
      }
    ])
    .disabled(false)
    .omitted(false)

  marketSector
    .createField('banner')
    .name('Hero Banner')
    .type('Link')
    .localized(false)
    .required(true)
    .validations([
      {
        linkContentType: ['banner']
      }
    ])
    .disabled(false)
    .omitted(false)
    .linkType('Entry')

  marketSector.changeEditorInterface('title', 'singleLine', {})
  marketSector.changeEditorInterface('slug', 'slugEditor', {})
  marketSector.changeEditorInterface('banner', 'entryCardEditor')
}
