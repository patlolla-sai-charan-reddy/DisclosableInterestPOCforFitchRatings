module.exports = migration => {
  const person = migration
    .createContentType('person')
    .name('Person')
    .description('')
    .displayField('firstName')

  person
    .createField('employeeId')
    .name('Employee ID')
    .type('Integer')
    .localized(false)
    .required(true)
    .validations([
      {
        unique: true
      }
    ])
    .disabled(false)
    .omitted(false)

  person
    .createField('firstName')
    .name('First Name')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)
  person
    .createField('lastName')
    .name('Last Name')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)
  person
    .createField('status')
    .name('Status')
    .type('Boolean')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)

  person
    .createField('email')
    .name('Email')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([
      {
        regexp: {
          pattern: '^\\w[\\w.-]*@([\\w-]+\\.)+[\\w-]+$'
        },

        message: 'Please provide a valid email address'
      }
    ])
    .disabled(false)
    .omitted(false)

  person
    .createField('phoneNumber')
    .name('Phone Number')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)

  person
    .createField('headshot')
    .name('Headshot')
    .type('Link')
    .localized(false)
    .required(true)
    .validations([
      {
        linkMimetypeGroup: ['image']
      }
    ])
    .disabled(false)
    .omitted(false)
    .linkType('Asset')

  person
    .createField('jobTitle')
    .name('Job Title')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)
  person
    .createField('department')
    .name('Department')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)

  person
    .createField('officeLocations')
    .name('Office Locations')
    .type('Array')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)
    .items({
      type: 'Link',

      validations: [
        {
          linkContentType: ['office']
        }
      ],

      linkType: 'Entry'
    })

  person
    .createField('shortBio')
    .name('Short Bio')
    .type('Text')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)
  person
    .createField('longBio')
    .name('Long Bio')
    .type('Text')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  person
    .createField('slug')
    .name('Slug')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  person
    .createField('sector')
    .name('Sector')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  person
    .createField('region')
    .name('Region')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  person
    .createField('country')
    .name('Country')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  person
    .createField('entity')
    .name('Entity')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  person
    .createField('language')
    .name('Language')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  person.changeEditorInterface('employeeId', 'numberEditor', {})
  person.changeEditorInterface('firstName', 'singleLine', {})
  person.changeEditorInterface('lastName', 'singleLine', {})

  person.changeEditorInterface('status', 'boolean', {
    trueLabel: 'Active',
    falseLabel: 'InActive'
  })

  person.changeEditorInterface('email', 'singleLine', {})
  person.changeEditorInterface('phoneNumber', 'singleLine', {})
  person.changeEditorInterface('headshot', 'assetLinkEditor', {})
  person.changeEditorInterface('jobTitle', 'singleLine', {})
  person.changeEditorInterface('department', 'singleLine', {})

  person.changeEditorInterface('officeLocations', 'entryLinksEditor', {
    bulkEditing: false
  })

  person.changeEditorInterface('shortBio', 'markdown', {})
  person.changeEditorInterface('longBio', 'markdown', {})
  person.changeEditorInterface('slug', 'slugEditor', {})
  person.changeEditorInterface('sector', 'singleLine', {})
  person.changeEditorInterface('region', 'singleLine', {})
  person.changeEditorInterface('country', 'singleLine', {})
  person.changeEditorInterface('entity', 'singleLine', {})
  person.changeEditorInterface('language', 'singleLine', {})
}
