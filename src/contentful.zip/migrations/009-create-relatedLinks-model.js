module.exports = migration => {
  const relatedLinks = migration
    .createContentType('relatedLinks')
    .name('Related Links')
    .description('')
    .displayField('adminTitle')

  relatedLinks
    .createField('adminTitle')
    .name('Admin Title')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([
      {
        unique: true
      }
    ])
    .disabled(false)
    .omitted(false)

  relatedLinks
    .createField('title')
    .name('Title')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)

  relatedLinks
    .createField('links')
    .name('Links')
    .type('Array')
    .localized(false)
    .required(false)
    .validations([
      {
        size: {
          min: 1
        },

        message: 'Please provide more than 1 entry for the list'
      }
    ])
    .disabled(false)
    .omitted(false)
    .items({
      type: 'Link',

      validations: [
        {
          linkContentType: ['link']
        }
      ],

      linkType: 'Entry'
    })

  relatedLinks.changeEditorInterface('adminTitle', 'singleLine', {
    helpText: 'Please provide a meaningful title'
  })

  relatedLinks.changeEditorInterface('title', 'singleLine', {
    helpText: 'Title for the link list'
  })

  relatedLinks.changeEditorInterface('links', 'entryLinksEditor', {
    bulkEditing: true
  })
}
