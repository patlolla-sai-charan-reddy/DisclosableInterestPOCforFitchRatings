module.exports = migration => {
  const link = migration
    .createContentType('link')
    .name('Link')
    .description('')
    .displayField('linkTitle')
  link
    .createField('linkTitle')
    .name('Link Title')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)

  link
    .createField('url')
    .name('URL')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([
      {
        regexp: {
          pattern:
            '^(http|https):\\/\\/(\\w+:{0,1}\\w*@)?(\\S+)(:[0-9]+)?(\\/|\\/([\\w#!:.?+=&%@!\\-\\/]))?$'
        }
      }
    ])
    .disabled(false)
    .omitted(false)

  link.changeEditorInterface('linkTitle', 'singleLine', {})
  link.changeEditorInterface('url', 'singleLine', {})
}
