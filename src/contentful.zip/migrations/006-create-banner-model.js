module.exports = migration => {
  const banner = migration
    .createContentType('banner')
    .name('Banner')
    .description('')
    .displayField('title')

  banner
    .createField('image')
    .name('Image')
    .type('Link')
    .localized(false)
    .required(false)
    .validations([
      {
        linkMimetypeGroup: ['image']
      }
    ])
    .disabled(false)
    .omitted(false)
    .linkType('Asset')

  banner
    .createField('title')
    .name('Title')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)

  banner
    .createField('abstract')
    .name('Abstract')
    .type('Text')
    .localized(false)
    .required(false)
    .validations([
      {
        size: {
          max: 300
        },

        message: 'Please provide less than 300 characters for abstract'
      }
    ])
    .disabled(false)
    .omitted(false)

  banner
    .createField('link')
    .name('Link')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([
      {
        regexp: {
          pattern:
            '^(http|https):\\/\\/(\\w+:{0,1}\\w*@)?(\\S+)(:[0-9]+)?(\\/|\\/([\\w#!:.?+=&%@!\\-\\/]))?$'
        },

        message: 'Please provide a valid URL'
      }
    ])
    .disabled(false)
    .omitted(false)

  banner
    .createField('marketoId')
    .name('Marketo ID')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)

  banner
    .createField('windowBehaviour')
    .name('Window Behaviour')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([
      {
        in: ['New Window', 'Current Window'],
        message: 'Please specify a value for target window'
      }
    ])
    .disabled(false)
    .omitted(false)

  banner.changeEditorInterface('image', 'assetLinkEditor', {})
  banner.changeEditorInterface('title', 'singleLine', {})
  banner.changeEditorInterface('abstract', 'markdown', {})

  banner.changeEditorInterface('link', 'singleLine', {
    helpText: 'Please provide URL to target page'
  })

  banner.changeEditorInterface('marketoId', 'singleLine', {
    helpText:
      'Please provide Marketo Form ID here, if to show as a popup/overlay'
  })

  banner.changeEditorInterface('windowBehaviour', 'radio', {})
}
