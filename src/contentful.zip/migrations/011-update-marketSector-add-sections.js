module.exports = migration => {
  const marketSector = migration.editContentType('marketSector')

  marketSector
    .createField('ratingsDisplayed')
    .name('Ratings to be displayed')
    .type('Integer')
    .localized(false)
    .required(false)
    .validations([
      {
        range: {
          min: 0
        }
      }
    ])
    .disabled(false)
    .omitted(false)

  marketSector
    .createField('researchDisplayed')
    .name('Research Articles to be displayed')
    .type('Integer')
    .localized(false)
    .required(false)
    .validations([
      {
        range: {
          min: 0
        }
      }
    ])
    .disabled(false)
    .omitted(false)

  marketSector
    .createField('videosDisplayed')
    .name('Videos to be displayed')
    .type('Integer')
    .localized(false)
    .required(false)
    .validations([
      {
        range: {
          min: 0
        }
      }
    ])
    .disabled(false)
    .omitted(false)

  marketSector
    .createField('eventsDisplayed')
    .name('Events to be displayed')
    .type('Integer')
    .localized(false)
    .required(false)
    .validations([
      {
        range: {
          min: 0
        }
      }
    ])
    .disabled(false)
    .omitted(false)

  marketSector
    .createField('podcastsDisplayed')
    .name('Podcasts to be displayed')
    .type('Integer')
    .localized(false)
    .required(false)
    .validations([
      {
        range: {
          min: 0
        }
      }
    ])
    .disabled(false)
    .omitted(false)

  marketSector
    .createField('contacts')
    .name('Contacts')
    .type('Array')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
    .items({
      type: 'Link',
      validations: [{ linkContentType: ['person'] }],
      linkType: 'Entry'
    })

  marketSector.changeEditorInterface('ratingsDisplayed', 'numberEditor', {
    helpText:
      'Number of Ratings to be displayed, set to 0 to disable this section'
  })

  marketSector.changeEditorInterface('researchDisplayed', 'numberEditor', {
    helpText:
      'Number of Research Articles to be displayed, set to 0 to disable this section'
  })

  marketSector.changeEditorInterface('videosDisplayed', 'numberEditor', {
    helpText:
      'Number of Videos to be displayed, set to 0 to disable this section'
  })

  marketSector.changeEditorInterface('eventsDisplayed', 'numberEditor', {
    helpText:
      'Number of Events to be displayed, set to 0 to disable this section'
  })

  marketSector.changeEditorInterface('podcastsDisplayed', 'numberEditor', {
    helpText:
      'Number of Podcasts to be displayed, set to 0 to disable this section'
  })

  marketSector.changeEditorInterface('contacts', 'entryLinksEditor', {
    helpText: 'Order is preserved, leave empty to disable this section',
    bulkEditing: false
  })
}
