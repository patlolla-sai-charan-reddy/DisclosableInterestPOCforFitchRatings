module.exports = migration => {
  const video = migration
    .createContentType('video')
    .name('Video')
    .description('')
    .displayField('title')
  video
    .createField('embedId')
    .name('Embed ID')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)
  video
    .createField('title')
    .name('Title')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)
  video
    .createField('slug')
    .name('Slug')
    .type('Symbol')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)

  video
    .createField('image')
    .name('Image')
    .type('Link')
    .localized(false)
    .required(false)
    .validations([
      {
        linkMimetypeGroup: ['image']
      }
    ])
    .disabled(false)
    .omitted(false)
    .linkType('Asset')

  video
    .createField('abstract')
    .name('Abstract')
    .type('Text')
    .localized(false)
    .required(true)
    .validations([])
    .disabled(false)
    .omitted(false)
  video
    .createField('transcript')
    .name('Transcript')
    .type('Text')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)

  video
    .createField('featuredPeople')
    .name('Featured People')
    .type('Array')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
    .items({
      type: 'Link',

      validations: [
        {
          linkContentType: ['person']
        }
      ],

      linkType: 'Entry'
    })

  video
    .createField('sector')
    .name('Sector')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  video
    .createField('region')
    .name('Region')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  video
    .createField('country')
    .name('Country')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  video
    .createField('entity')
    .name('Entity')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)
  video
    .createField('language')
    .name('Language')
    .type('Symbol')
    .localized(false)
    .required(false)
    .validations([])
    .disabled(false)
    .omitted(false)

  video.changeEditorInterface('embedId', 'urlEditor', {
    helpText: 'Please provide the Brightcove Embed URL'
  })

  video.changeEditorInterface('title', 'singleLine', {})
  video.changeEditorInterface('slug', 'slugEditor', {})
  video.changeEditorInterface('image', 'assetLinkEditor', {})

  video.changeEditorInterface('abstract', 'markdown', {
    helpText:
      'Short introduction about the video, used for teaser display and invite to view'
  })

  video.changeEditorInterface('transcript', 'markdown', {})

  video.changeEditorInterface('featuredPeople', 'entryLinksEditor', {
    helpText: 'Please provide featured people within the video',
    bulkEditing: false
  })

  video.changeEditorInterface('sector', 'singleLine', {})
  video.changeEditorInterface('region', 'singleLine', {})
  video.changeEditorInterface('country', 'singleLine', {})
  video.changeEditorInterface('entity', 'singleLine', {})
  video.changeEditorInterface('language', 'singleLine', {})
}
