# FITCH Contentful

This repository contains the CMS as Code implementation(s) for PoC.

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes.

To get started, ensure [Node.js](https://nodejs.org/en/) is installed and added to your `PATH`.

### Installation

```bash
npm install
```

### Configuration

You will need a local `.env` file, see `.env.example` for required keys.

```bash
cp .env.example .env
```

Then populate with access credentials as described in the file.

You can also create a file `.contentfulrc.json` to reuse Contenful CLI config.

```bash
cp .contentfulrc.example.json .contentfulrc.json
```

### Usage

To execute the commands in this repository, you can run

```bash
./bin/contentful-fitch
```

Or instead add `contentful-fitch` to your `PATH` using

```bash
npm link
```

To execute commands against the Contentful CaaS APIs using the Contentful CLI, execute

```bash
npx contentful-cli
```

Further documentation is available for the Contentful CLI on [Github](https://github.com/contentful/contentful-cli/tree/master/docs)

### Contribution

Most additions will be new content models under `fixtures/` and migration scripts under `migrations/`. In either case, it's easiest to refer to the existing examples in those directories. Changes are linted, which will run on a precommit hook. To test your changes, run

```bash
npm test
```
