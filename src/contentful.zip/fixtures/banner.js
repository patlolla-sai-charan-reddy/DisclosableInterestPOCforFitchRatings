const _ = require('lodash')
const faker = require('faker')

const windowBehaviours = ['New Window', 'Current Window']

module.exports = () => {
  const fields = {
    image: {
      sys: {
        type: 'Link',
        linkType: 'Asset',
        id: '63puEMmiCyXkwhB2D9ad2H'
      }
    },
    title: _.startCase(faker.random.words(faker.random.number(5) + 1)),
    abstract: faker.lorem.paragraphs(faker.random.number(3) + 1),
    link: faker.internet.url(),
    marketoId: faker.random.uuid(),
    windowBehaviour:
      windowBehaviours[faker.random.number(windowBehaviours.length)]
  }

  return {
    sys: {
      type: 'Entry',
      contentType: {
        sys: {
          type: 'Link',
          linkType: 'ContentType',
          id: 'banner'
        }
      }
    },
    fields: _.mapValues(fields, field => ({ 'en-US': field }))
  }
}
