const _ = require('lodash')
const faker = require('faker')
const lib = require('../lib/')

module.exports = async () => {
  const fields = {
    name: _.startCase(faker.random.words(faker.random.number(3) + 1)),
    address: faker.address.streetAddress(true),
    locationCoordinates: {
      lon: +faker.address.longitude(),
      lat: +faker.address.latitude()
    }
  }

  const existingLegalOffices = await lib.availableContentfulLinks('legalOffice')

  if (!_.isEmpty(existingLegalOffices)) {
    fields.legalOffices = _.chain(existingLegalOffices)
      .sampleSize(faker.random.number(2) + 1)
      .map(lib.mapContentfulLink)
      .value()
  }

  return {
    sys: {
      type: 'Entry',
      contentType: {
        sys: {
          type: 'Link',
          linkType: 'ContentType',
          id: 'office'
        }
      }
    },
    fields: _.mapValues(fields, field => ({ 'en-US': field }))
  }
}
