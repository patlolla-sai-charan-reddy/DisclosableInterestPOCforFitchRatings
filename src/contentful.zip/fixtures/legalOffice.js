const _ = require('lodash')
const faker = require('faker')

module.exports = () => {
  const fields = {
    name: _.startCase(faker.random.words(faker.random.number(3) + 1)),
    email: faker.internet.email(),
    website: faker.internet.url(),
    phoneNumber1: faker.phone.phoneNumber()
  }

  if (faker.random.boolean()) {
    fields.phoneNumber2 = faker.phone.phoneNumber()
  }

  if (faker.random.boolean()) {
    fields.phoneNumber3 = faker.phone.phoneNumber()
  }

  return {
    sys: {
      type: 'Entry',
      contentType: {
        sys: {
          type: 'Link',
          linkType: 'ContentType',
          id: 'legalOffice'
        }
      }
    },
    fields: _.mapValues(fields, field => ({ 'en-US': field }))
  }
}
