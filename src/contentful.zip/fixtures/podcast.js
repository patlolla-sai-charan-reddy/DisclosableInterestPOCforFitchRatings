const _ = require('lodash')
const faker = require('faker')
const lib = require('../lib/')

const nonSoundCloundClips = _.map(
  [
    'user-125131884/replay-fitch-on-major-cee-economies-political-fiscal-hotspots',
    'user-125131884/social-housing-tc-english-replay',
    'user-125131884/social-housing-french-tc',
    'user-125131884/swedish-banks-replay',
    'user-125131884/gig-emea-transportation-airports-replay',
    'fitchratings/entrevista-com-o-diretor-executivo-da-sicredi',
    'fitchratings/teleconference-replay-insights-on-lestari-banten-energis-first-time-ratings-of-bbb-exp',
    'fitchratings/insights-on-pt-indonesia-asahan-aluminium-first-time-ratings-of-bbb',
    'fitchratings/teleconference-replay-chinas-power-reform',
    'fitchratings/teleconference-replay-fitch-healthcare-medians-hospitals-ccrcs'
  ],
  uri => `https://soundcloud.com/${uri}`
)

module.exports = async () => {
  const title = _.startCase(faker.random.words(faker.random.number(8) + 1))

  const fields = {
    embedId:
      nonSoundCloundClips[faker.random.number(nonSoundCloundClips.length)],
    title,
    slug: `/podcasts/${faker.helpers.slugify(_.lowerCase(title))}`,
    abstract: faker.lorem.paragraphs(faker.random.number(3) + 1),
    transcript: faker.lorem.paragraphs(faker.random.number(11) + 1),
    subscriptionUrl: faker.internet.url(),
    sector: 'Sovereign',
    region: '',
    country: '',
    language: 'en'
  }

  const existingPeople = await lib.availableContentfulLinks('person')

  if (!_.isEmpty(existingPeople)) {
    fields.featuredPeople = _.chain(existingPeople)
      .sampleSize(faker.random.number(4) + 1)
      .map(lib.mapContentfulLink)
      .value()
  }

  return {
    sys: {
      type: 'Entry',
      contentType: {
        sys: {
          type: 'Link',
          linkType: 'ContentType',
          id: 'podcast'
        }
      }
    },
    fields: _.mapValues(fields, field => ({ 'en-US': field }))
  }
}
