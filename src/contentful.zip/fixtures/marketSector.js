const _ = require('lodash')
const faker = require('faker')
const lib = require('../lib/')

module.exports = async () => {
  const name = faker.random.words(faker.random.number(2) + 1)

  const fields = {
    title: _.startCase(name),
    slug: faker.helpers.slugify(_.lowerCase(name)),
    ratingsDisplayed: faker.random.number(3),
    researchDisplayed: faker.random.number(4),
    videosDisplayed: faker.random.number(4),
    eventsDisplayed: faker.random.number(4),
    podcastsDisplayed: faker.random.number(3)
  }

  const existingBanners = await lib.availableContentfulLinks('banner')

  if (!_.isEmpty(existingBanners)) {
    fields.banner = lib.mapContentfulLink(
      existingBanners[faker.random.number(existingBanners.length - 1)]
    )
  }

  const existingPeople = await lib.availableContentfulLinks('person')

  if (!_.isEmpty(existingPeople)) {
    fields.contacts = _.chain(existingPeople)
      .sampleSize(faker.random.number(12))
      .map(lib.mapContentfulLink)
      .value()
  }

  return {
    sys: {
      type: 'Entry',
      contentType: {
        sys: {
          type: 'Link',
          linkType: 'ContentType',
          id: 'marketSector'
        }
      }
    },
    fields: _.mapValues(fields, field => ({ 'en-US': field }))
  }
}
