const _ = require('lodash')
const faker = require('faker')

module.exports = () => {
  const title = _.startCase(faker.random.words(faker.random.number(4) + 1))

  const fields = {
    linkTitle: title,
    url: faker.internet.url()
  }

  return {
    sys: {
      type: 'Entry',
      contentType: {
        sys: {
          type: 'Link',
          linkType: 'ContentType',
          id: 'link'
        }
      }
    },
    fields: _.mapValues(fields, field => ({ 'en-US': field }))
  }
}
