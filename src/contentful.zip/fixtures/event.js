const _ = require('lodash')
const faker = require('faker')

const eventTypes = [
  'Teleconference',
  'Webcast',
  'Fitch Ratings Hosted',
  'Fitch Ratings Sponsored',
  'Fitch Solutions Hosted'
]

module.exports = () => {
  const title = _.startCase(faker.random.words(faker.random.number(8) + 1))

  const fields = {
    title,
    slug: `/events/${faker.helpers.slugify(_.lowerCase(title))}`,
    eventType: eventTypes[faker.random.number(eventTypes.length)],
    startDate: faker.date.recent(30),
    endDate: faker.date.recent(30),
    locationName: faker.random.words(faker.random.number(8) + 1),
    locationCoordinates: {
      lon: +faker.address.longitude(),
      lat: +faker.address.latitude()
    },
    address: faker.address.streetAddress(true),
    image: {
      sys: {
        type: 'Link',
        linkType: 'Asset',
        id: '63puEMmiCyXkwhB2D9ad2H'
      }
    },
    link: faker.internet.url(),
    accessibility: faker.lorem.paragraphs(faker.random.number(5) + 1),
    sector: 'Sovereign',
    region: '',
    country: '',
    language: 'en'
  }

  return {
    sys: {
      type: 'Entry',
      contentType: {
        sys: {
          type: 'Link',
          linkType: 'ContentType',
          id: 'event'
        }
      }
    },
    fields: _.mapValues(fields, field => ({ 'en-US': field }))
  }
}
