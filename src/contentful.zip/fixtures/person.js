const _ = require('lodash')
const faker = require('faker')
const lib = require('../lib/')

module.exports = async () => {
  const employeeId = faker.random.number()

  const fields = {
    employeeId,
    firstName: faker.name.firstName(),
    lastName: faker.name.lastName(),
    status: faker.random.boolean(),
    email: faker.internet.email(),
    phoneNumber: faker.phone.phoneNumber(),
    // TODO: This relies on an asset being available for now.
    headshot: {
      sys: {
        type: 'Link',
        linkType: 'Asset',
        id: '27UkmtlzmyMvMEyqaTBLCP'
      }
    },
    jobTitle: faker.name.jobTitle(),
    department: faker.name.jobArea(),
    shortBio: faker.lorem.paragraphs(1),
    longBio: faker.lorem.paragraphs(faker.random.number(3) + 1),
    slug: `/people/${employeeId}`,
    sector: 'Sovereign',
    region: '',
    country: '',
    language: 'en'
  }

  const existingOffices = await lib.availableContentfulLinks('office')

  if (!_.isEmpty(existingOffices)) {
    fields.officeLocations = _.chain(existingOffices)
      .sampleSize(1)
      .map(lib.mapContentfulLink)
      .value()
  }

  return {
    sys: {
      type: 'Entry',
      contentType: {
        sys: {
          type: 'Link',
          linkType: 'ContentType',
          id: 'person'
        }
      }
    },
    fields: _.mapValues(fields, field => ({ 'en-US': field }))
  }
}
