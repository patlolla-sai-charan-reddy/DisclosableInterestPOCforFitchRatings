const _ = require('lodash')
const faker = require('faker')
const lib = require('../lib/')

module.exports = async () => {
  const randomSuffix = faker.random.number(100) + 1
  const title = _.startCase(faker.random.number(3) + 1)

  const fields = {
    adminTitle: `Related Links - ${randomSuffix}`,
    title
  }

  const existingLinks = await lib.availableContentfulLinks('link')

  if (!_.isEmpty(existingLinks)) {
    fields.links = _.chain(existingLinks)
      .sampleSize(faker.random.number(8) + 1)
      .map(lib.mapContentfulLink)
      .value()
  }

  return {
    sys: {
      type: 'Entry',
      contentType: {
        sys: {
          type: 'Link',
          linkType: 'ContentType',
          id: 'relatedLinks'
        }
      }
    },
    fields: _.mapValues(fields, field => ({ 'en-US': field }))
  }
}
