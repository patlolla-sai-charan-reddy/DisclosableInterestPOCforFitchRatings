const _ = require('lodash')
const faker = require('faker')
const lib = require('../lib/')

module.exports = async () => {
  const { id, name, slug, shortDescription } = await lib.getRandomVideo()

  const fields = {
    embedId: id,
    title: name,
    slug: `/videos/${faker.helpers.slugify(slug)}`,
    image: {
      sys: {
        type: 'Link',
        linkType: 'Asset',
        id: '63puEMmiCyXkwhB2D9ad2H'
      }
    },
    abstract: shortDescription,
    transcript: faker.lorem.paragraphs(faker.random.number(11) + 1),
    sector: 'Sovereign',
    region: '',
    country: '',
    language: 'en'
  }

  const existingPeople = await lib.availableContentfulLinks('person')

  if (!_.isEmpty(existingPeople)) {
    fields.featuredPeople = _.chain(existingPeople)
      .sampleSize(faker.random.number(4) + 1)
      .map(lib.mapContentfulLink)
      .value()
  }

  return {
    sys: {
      type: 'Entry',
      contentType: {
        sys: {
          type: 'Link',
          linkType: 'ContentType',
          id: 'video'
        }
      }
    },
    fields: _.mapValues(fields, field => ({ 'en-US': field }))
  }
}
