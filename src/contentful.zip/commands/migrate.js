const path = require('path')
const _ = require('lodash')
const inquirer = require('inquirer')
const { runMigration } = require('contentful-migration/built/bin/cli')
const { availableMigrations, waterfall } = require('../lib/')

const { SPACE_ID, RW_TOKEN } = process.env

const resolveFilePath = filename =>
  path.resolve(__dirname, '../migrations', filename)

const migrate = async ({ environmentId, filePath }) => {
  const options = {
    filePath,
    environmentId,
    spaceId: SPACE_ID,
    accessToken: RW_TOKEN
  }

  return runMigration(options)
}

const migrateFromStep = async ({ environment, step }) => {
  const migrations = _.slice(availableMigrations(), step - 1)

  return waterfall(
    _.map(migrations, filename =>
      _.partial(migrate, {
        filePath: resolveFilePath(`${filename}.js`),
        environmentId: environment
      })
    )
  )
}

async function prompt() {
  return inquirer.prompt([
    {
      type: 'input',
      name: 'environment',
      message: 'Define an environment to migrate to',
      default: 'develop'
    },
    {
      type: 'input',
      name: 'step',
      message: 'Which migration step would you like to execute from?',
      default: 1,
      filter: async value => _.toNumber(value),
      validate: async value =>
        _.inRange(value, 1, availableMigrations().length + 1)
    }
  ])
}

prompt()
  .then(migrateFromStep)
  .catch(_.noop)
