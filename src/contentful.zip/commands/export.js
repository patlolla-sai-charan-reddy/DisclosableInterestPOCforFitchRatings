const fs = require('fs')
const path = require('path')
const _ = require('lodash')
const mkdirp = require('mkdirp')
const inquirer = require('inquirer')
const contentfulExport = require('contentful-export')

const { availableFixtures } = require('../lib/')

const { SPACE_ID, ENVIRONMENT_ID, RW_TOKEN } = process.env

const exportFromContentful = ({ fixture, outfile }) => {
  const outdir = path.dirname(outfile)

  const options = {
    spaceId: SPACE_ID,
    environmentId: ENVIRONMENT_ID,
    managementToken: RW_TOKEN,
    queryEntries: [`content_type=${fixture}`],
    skipContentModel: true,
    exportDir: outdir,
    contentFile: path.basename(outfile)
  }

  if (!fs.existsSync(outdir)) {
    mkdirp.sync(outdir)
  }

  return contentfulExport(options)
}

inquirer.registerPrompt('autocomplete', require('inquirer-autocomplete-prompt'))

async function prompt() {
  return inquirer.prompt([
    {
      type: 'autocomplete',
      name: 'fixture',
      message: 'Select a content model to export',
      source: async () => availableFixtures()
    },
    {
      type: 'input',
      name: 'outfile',
      message: 'Where would you like to save the output?',
      default: ({ fixture }) => path.join('exported', `${fixture}.json`)
    }
  ])
}

prompt()
  .then(exportFromContentful)
  .catch(_.noop)
