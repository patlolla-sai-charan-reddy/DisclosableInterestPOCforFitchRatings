const fs = require('fs')
const path = require('path')
const _ = require('lodash')
const mkdirp = require('mkdirp')
const inquirer = require('inquirer')
const fixtures = require('../fixtures/')
const { availableFixtures, waterfall } = require('../lib/')

const generate = async data => {
  const { count, fixture } = data

  return waterfall(_.fill(Array(count), fixtures[fixture]))
}

const save = data => {
  const { entries, outfile } = data
  const outdir = path.dirname(outfile)

  if (!fs.existsSync(outdir)) {
    mkdirp.sync(outdir)
  }

  fs.writeFileSync(path.resolve(outfile), JSON.stringify({ entries }, null, 2))

  return data
}

inquirer.registerPrompt('autocomplete', require('inquirer-autocomplete-prompt'))

async function prompt() {
  return inquirer.prompt([
    {
      type: 'autocomplete',
      name: 'fixture',
      message: 'Select a content model to seed from fixtures',
      source: async () => availableFixtures()
    },
    {
      type: 'input',
      name: 'count',
      message: 'How many would you like to create?',
      default: 30,
      filter: async value => _.toNumber(value),
      validate: async value => _.isFinite(value)
    },
    {
      type: 'input',
      name: 'outfile',
      message: 'Where would you like to save the output?',
      default: ({ fixture }) => path.join('generated', `${fixture}.json`)
    }
  ])
}

async function init() {
  const input = await prompt()
  const entries = await generate(input)
  return save({ ...input, entries })
}

init()
