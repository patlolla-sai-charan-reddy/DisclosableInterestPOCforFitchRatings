import React from "react";
import { Router } from "@reach/router";

import * as styles from "./Marketing.styles";

import DocumentType from "../../containers/DocumentType/DocumentType";
import Hero from "../../containers/Hero/Hero";
import MarketingNav from "../Nav/MarketingNav";
import Metadata from "../../containers/Metadata/Metadata";
import Search from "../../containers/Search/Search";
import Taxonomy from "../../containers/Taxonomy/Taxonomy";
import Topics from "../../containers/Topics/Topics";

const marketing = () => (
  <>
    <Search />
    <div className="row">
      <div className={`col s2 ${styles.indexBox}`}>
        <MarketingNav />
      </div>
      <div className="col s10">
        <div className={styles.formContainer}>
          <Router primary={false}>
            <Taxonomy path="taxonomy" />
            <Hero path="hero" />
            <Topics path="topics-dictionary" />
            <DocumentType path="viewing-mode" />
            <Metadata path="metadata" />
          </Router>
        </div>
      </div>
    </div>
  </>
);

export default marketing;
