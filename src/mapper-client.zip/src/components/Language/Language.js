import React from "react";
import { graphql, compose } from "react-apollo";
import { isEmpty } from "lodash";

import Select from "react-select";

import GET_LANGUAGE from "../../queries/get/GET_LANGUAGE";
import GET_LANGUAGES_LIST from "../../queries/get/GET_LANGUAGES_LIST";

import * as styles from "../Chip/Chip.styles";

const languageChip = props => {
  const languagesList = props.languagesList ? props.languagesList : [];
  const language = props.marketing ? props.marketing.language : {};

  const handleChange = () => {};
  return !isEmpty(language) ? (
    <div className="row">
      <div className="col s2">
        <p>Language</p>
      </div>
      <div className="col s10">
        <Select
          styles={styles.chip}
          defaultValue={language}
          options={languagesList}
          getOptionLabel={({ name }) => name}
          getOptionValue={({ slug }) => slug}
          onChange={handleChange}
        />
      </div>
    </div>
  ) : (
    <div />
  );
};

export default compose(
  graphql(GET_LANGUAGES_LIST, {
    props: ({ data: { getLanguages } }) => getLanguages
  }),
  graphql(GET_LANGUAGE, {
    props: ({ data: { getRAC } }) => getRAC
  })
)(languageChip);
