import React from "react";
import { compose, graphql } from "react-apollo";

import GET_APPLICATION_STATUS from "../../queries/get/GET_APPLICATION_STATUS";

const status = props => {
  console.log("props", props.message);
  return (
    <>
      <p>{props.message}</p>
    </>
  );
};

export default compose(
  graphql(GET_APPLICATION_STATUS, {
    props: ({ data: { applicationStatus } }) => applicationStatus
  })
)(status);
