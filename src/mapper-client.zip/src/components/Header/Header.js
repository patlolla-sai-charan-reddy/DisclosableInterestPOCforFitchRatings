import React from "react";
import { Link } from "@reach/router";

import * as styles from "./Header.styles";

const header = () => {
  return (
    <div className={styles.header}>
      <h3>Mapper</h3>
      <Link to="/marketing/taxonomy">
        <span className="waves-effect waves-light btn-large btn-primary">
          Marketing
        </span>
      </Link>
      <Link to="/seo">
        <span className="waves-effect waves-light btn-large btn-primary">
          SEO Tools
        </span>
      </Link>
    </div>
  );
};

export default header;
