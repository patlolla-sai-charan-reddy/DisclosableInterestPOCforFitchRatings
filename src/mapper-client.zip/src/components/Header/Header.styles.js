import { css } from "emotion";

export const header = css`
  text-align: center;
`;
