import React from "react";
import NavLink from "./NavLInk";

const seoNav = () => {
  return (
    <div>
      <ul>
        <li>
          <NavLink to="bulk-redirects">Bulk Redirects</NavLink>
        </li>
        <li>
          <NavLink to="single-redirect">Single Redirect</NavLink>
        </li>
        <li>
          <NavLink to="category-change">Category Change</NavLink>
        </li>
        <li>
          <NavLink to="sitemap">Sitemap Access</NavLink>
        </li>
        <li>
          <NavLink to="robots">Robots Access</NavLink>
        </li>
      </ul>
    </div>
  );
};

export default seoNav;
