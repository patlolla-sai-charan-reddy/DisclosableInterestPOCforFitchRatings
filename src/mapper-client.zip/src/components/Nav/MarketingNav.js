import React from "react";
import NavLink from "./NavLInk";

const marketingNav = () => {
  return (
    <div>
      <ul>
        <li>
          <NavLink to="taxonomy">Taxonomy</NavLink>
        </li>
        <li>
          <NavLink to="hero">Hero Background</NavLink>
        </li>
        <li>
          <NavLink to="topics-dictionary">Topics Dictionary</NavLink>
        </li>
        <li>
          <NavLink to="viewing-mode">Viewing Mode</NavLink>
        </li>
        <li>
          <NavLink to="metadata">Meta Data</NavLink>
        </li>
      </ul>
    </div>
  );
};

export default marketingNav;
