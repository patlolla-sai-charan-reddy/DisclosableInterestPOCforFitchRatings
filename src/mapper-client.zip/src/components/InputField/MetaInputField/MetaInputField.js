import React from "react";

import InputField from "../InputField";

const inputField = ({ label, field, property, type }) => {
  const typeName = type === "metadataTags" ? "MetadataTag" : "OpenGraphTag";
  field = property === "description" ? field.trim() : field;

  return (
    <InputField
      label={label}
      field={field}
      property={property}
      type={type}
      typeName={typeName}
    />
  );
};

export default inputField;
