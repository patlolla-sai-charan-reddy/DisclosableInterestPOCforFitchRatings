import React, { useState } from "react";
import { compose, graphql, withApollo } from "react-apollo";
import gql from "graphql-tag";

import GET_CURRENT_DOC_ID from "../../queries/get/GET_CURRENT_DOC_ID";

const inputField = ({ label, field, property, type, typeName, client }) => {
  const [newValue, updateValue] = useState(field);

  const handleChange = value => {
    updateValue(value);
    client.writeFragment({
      id: "MarketingTagsList",
      fragment: gql`
        fragment ${typeName} on ${type} {
          ${type} {
            ${property}
          }
        }
      `,
      data: {
        [type]: { [property]: value, __typename: typeName }
      }
    });
  };

  return (
    <div className="row">
      <div className="col s2">
        <p>{label}</p>
      </div>
      <div className="col s10">
        <input
          id="icon_prefix"
          className="validate"
          type="text"
          value={newValue}
          onChange={event => handleChange(event.target.value)}
        />
      </div>
    </div>
  );
};

export default compose(
  graphql(GET_CURRENT_DOC_ID, { name: "GET_CURRENT_DOC_ID" })
)(withApollo(inputField));
