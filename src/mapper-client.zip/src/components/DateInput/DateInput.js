import React, { useState } from "react";
import { withApollo } from "react-apollo";
import gql from "graphql-tag";

import TextField from "@material-ui/core/TextField";

const dateInput = ({ client, label, property, type, typeName, value }) => {
  const [newValue, updateValue] = useState(value);
  const handleChange = value => {
    updateValue(value);
    const ISOString = new Date(value).toISOString();
    console.log("value", ISOString);

    client.writeFragment({
      id: "MarketingTagsList",
      fragment: gql`
        fragment ${typeName} on ${type} {
          ${type} {
            ${property}
          }
        }
      `,
      data: {
        [type]: { [property]: ISOString, __typename: typeName }
      }
    });
  };
  return (
    <>
      <div className="col s2">
        <p>Effective Date</p>
      </div>
      <div className="col s4">
        <TextField
          className="date-picker"
          type="date"
          value={newValue}
          onChange={event => handleChange(event.target.value)}
          InputLabelProps={{
            shrink: true
          }}
        />
      </div>
    </>
  );
};

export default withApollo(dateInput);
