import { css } from "emotion";

export const textArea = css`
  height: 7rem;
`;
