import React, { useState } from "react";
import { compose, graphql, withApollo } from "react-apollo";

import GET_CURRENT_DOC_ID from "../../queries/get/GET_CURRENT_DOC_ID";
import GET_SUMMARY from "../../queries/get/GET_SUMMARY";

const summary = props => {
  const initialValue = props.summary ? props.summary.trim() : "";
  const [summary, updateSummary] = useState(initialValue);
  const handleChange = summary => {
    updateSummary(summary);
    props.client.writeQuery({
      query: GET_SUMMARY,
      variables: {
        id: props.docId
      },
      data: {
        getRAC: {
          marketing: {
            summary: summary,
            __typename: "MarketingTagsList"
          },
          __typename: "RAC"
        }
      }
    });
  };

  return (
    <>
      <textarea
        className="materialize-textarea"
        value={summary}
        onChange={event => handleChange(event.target.value)}
      />
      <label htmlFor="textarea1">Abstract</label>
    </>
  );
};

export default compose(
  graphql(GET_CURRENT_DOC_ID, {
    props: ({ data: { currentDocId } }) => currentDocId
  }),
  graphql(GET_SUMMARY, {
    options: ownProps => ({
      variables: {
        id: ownProps.docId,
        docType: ownProps.docType
      }
    }),
    props: ({
      data: {
        getRAC: { marketing }
      }
    }) => marketing
  })
)(withApollo(summary));
