import React from "react";
import { graphql, compose } from "react-apollo";

import GET_CURRENT_DOC_ID from "../../../queries/get/GET_CURRENT_DOC_ID";
import GET_TOPICS from "../../../queries/get/GET_TOPICS";
import GET_TOPICS_CHIP from "../../../queries/get/GET_TOPICS_CHIP";

import Chip from "../Chip";

const topicChip = props => {
  const topicsList = props.topics ? props.topics : [];
  const topics = props.marketing ? props.marketing.topics : [];
  return (
    <Chip
      label="Topics"
      value={topics}
      options={topicsList}
      field="topics"
      imageFlag={props.imageFlag}
    />
  );
};

export default compose(
  graphql(GET_CURRENT_DOC_ID, {
    props: ({ data: { currentDocId } }) => currentDocId
  }),
  graphql(GET_TOPICS_CHIP, {
    props: ({ data: { getTopics } }) => getTopics
  }),
  graphql(GET_TOPICS, {
    options: ownProps => ({
      variables: {
        id: ownProps.docId,
        docType: ownProps.docType
      }
    }),
    props: ({ data: { getRAC } }) => getRAC
  })
)(topicChip);
