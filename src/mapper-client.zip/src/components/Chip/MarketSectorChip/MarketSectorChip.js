import React from "react";
import { graphql, compose } from "react-apollo";

import GET_CURRENT_DOC_ID from "../../../queries/get/GET_CURRENT_DOC_ID";
import GET_MARKET_SECTORS from "../../../queries/get/GET_MARKET_SECTORS";
import GET_MARKET_SECTORS_LIST from "../../../queries/get/GET_MARKET_SECTORS_LIST";

import Chip from "../Chip";

const marketSectorChip = props => {
  const marketSectorsList = props.marketSectorsList
    ? props.marketSectorsList
    : [];
  const marketSectors = props.marketing ? props.marketing.marketSectors : [];
  return (
    <Chip
      label="Market Sector"
      value={marketSectors}
      options={marketSectorsList}
      field="marketSectors"
      imageFlag={props.imageFlag}
    />
  );
};

export default compose(
  graphql(GET_CURRENT_DOC_ID, {
    props: ({ data: { currentDocId } }) => currentDocId
  }),
  graphql(GET_MARKET_SECTORS_LIST, {
    props: ({ data: { getMarketSectors } }) => getMarketSectors
  }),
  graphql(GET_MARKET_SECTORS, {
    options: ownProps => ({
      variables: {
        id: ownProps.docId,
        docType: ownProps.docType
      }
    }),
    props: ({ data: { getRAC } }) => getRAC
  })
)(marketSectorChip);
