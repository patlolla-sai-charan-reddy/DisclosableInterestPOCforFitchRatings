import * as colors from "../../styles/GlobalStyles";

export const chip = {
  control: (styles, { isDisabled, isFocused, isSelected }) => ({
    ...styles,
    boxShadow: isFocused ? 0 : 0,
    backgroundColor: "white",
    borderColor: isFocused ? colors.colorAction : styles.borderColor,
    "&:hover": {
      borderColor: isFocused ? colors.colorAction : styles.borderColor
    }
  }),
  // menu: styles => ({
  //   ...styles,
  //   width: "10rem"
  // }),
  option: (styles, { data, isDisabled, isFocused, isSelected }) => {
    return {
      ...styles,
      backgroundColor: isDisabled
        ? null
        : isSelected
        ? colors.colorAction
        : isFocused
        ? colors.colorActionLight
        : null,
      cursor: isDisabled ? "not-allowed" : "default"
    };
  }
};
