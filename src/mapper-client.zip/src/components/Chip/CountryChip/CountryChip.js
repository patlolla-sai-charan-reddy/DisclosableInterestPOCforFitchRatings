import React from "react";
import { graphql, compose } from "react-apollo";

import GET_CURRENT_DOC_ID from "../../../queries/get/GET_CURRENT_DOC_ID";
import GET_COUNTRIES from "../../../queries/get/GET_COUNTRIES";
import GET_COUNTRIES_LIST from "../../../queries/get/GET_COUNTRIES_LIST";

import Chip from "../Chip";

const countryChip = props => {
  const countriesList = props.countriesList ? props.countriesList : [];
  const countries = props.marketing ? props.marketing.countries : [];
  return (
    <Chip
      label="Countries"
      value={countries}
      options={countriesList}
      field="countries"
      imageFlag={props.imageFlag}
    />
  );
};

export default compose(
  graphql(GET_CURRENT_DOC_ID, {
    props: ({ data: { currentDocId } }) => currentDocId
  }),
  graphql(GET_COUNTRIES_LIST, {
    props: ({ data: { getCountries } }) => getCountries
  }),
  graphql(GET_COUNTRIES, {
    options: ownProps => ({
      variables: {
        id: ownProps.docId,
        docType: ownProps.docType
      }
    }),
    props: ({ data: { getRAC } }) => getRAC
  })
)(countryChip);
