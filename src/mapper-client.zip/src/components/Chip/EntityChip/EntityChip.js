import React, { useState } from "react";
import { compose, graphql, withApollo } from "react-apollo";
import AsyncSelect from "react-select/lib/Async";

import GET_CURRENT_DOC_ID from "../../../queries/get/GET_CURRENT_DOC_ID";
import GET_ENTITIES from "../../../queries/get/GET_ENTITIES";
import GET_ENTITIES_LIST from "../../../queries/get/GET_ENTITIES_LIST";

import * as styles from "../Chip.styles";

const entityChip = ({ client, docId, entities: initialList }) => {
  const [newList, updateList] = useState(initialList);

  const getOptions = async inputValue => {
    const {
      data: {
        getEntitiesList: { entitiesList }
      }
    } = await client.query({
      query: GET_ENTITIES_LIST,
      variables: {
        term: inputValue
      }
    });
    return entitiesList;
  };

  const handleChange = chips => {
    updateList(chips);
    client.writeQuery({
      query: GET_ENTITIES,
      variables: {
        id: docId
      },
      data: {
        getRAC: {
          marketing: {
            entities: chips,
            __typename: "MarketingTagsList"
          },
          __typename: "RAC"
        }
      }
    });
  };

  return (
    <div className="row">
      <div className="col s2">
        <p>Entities</p>
      </div>
      <div className="col s10">
        <AsyncSelect
          isMulti
          cacheOptions
          defaultOptions
          styles={styles.chip}
          defaultValue={newList}
          getOptionLabel={({ name }) => name}
          getOptionValue={({ slug }) => slug}
          loadOptions={getOptions}
          onChange={handleChange}
        />
      </div>
    </div>
  );
};

export default compose(
  graphql(GET_CURRENT_DOC_ID, {
    props: ({ data: { currentDocId } }) => currentDocId
  }),
  graphql(GET_ENTITIES, {
    options: ownProps => ({
      variables: {
        id: ownProps.docId,
        docType: ownProps.docType
      }
    }),
    props: ({
      data: {
        getRAC: { marketing }
      }
    }) => marketing
  })
)(withApollo(entityChip));
