import React from "react";
import { graphql, compose } from "react-apollo";

import GET_CURRENT_DOC_ID from "../../../queries/get/GET_CURRENT_DOC_ID";
import GET_REGIONS from "../../../queries/get/GET_REGIONS";
import GET_REGIONS_LIST from "../../../queries/get/GET_REGIONS_LIST";

import Chip from "../Chip";

const regionChip = props => {
  const regionsList = props.regionsList ? props.regionsList : [];
  const regions = props.marketing ? props.marketing.regions : [];
  return (
    <Chip
      label="Regions"
      value={regions}
      options={regionsList}
      field="regions"
      imageFlag={props.imageFlag}
    />
  );
};

export default compose(
  graphql(GET_CURRENT_DOC_ID, {
    props: ({ data: { currentDocId } }) => currentDocId
  }),
  graphql(GET_REGIONS_LIST, {
    props: ({ data: { getRegions } }) => getRegions
  }),
  graphql(GET_REGIONS, {
    options: ownProps => ({
      variables: {
        id: ownProps.docId,
        docType: ownProps.docType
      }
    }),
    props: ({ data: { getRAC } }) => getRAC
  })
)(regionChip);
