import React, { useState } from "react";
import { compose, graphql, withApollo } from "react-apollo";
import gql from "graphql-tag";
import { filter, unionBy } from "lodash";
import Select from "react-select";

import GET_CURRENT_DOC_ID from "../../queries/get/GET_CURRENT_DOC_ID";

import * as styles from "./Chip.styles";

const chip = ({ client, docId, field, label, value, options, imageFlag }) => {
  let initialList = value;

  if (imageFlag) {
    initialList = filter(value, chip => {
      return chip.useSpotlightImage;
    });
  }

  const [newList, updateList] = useState(initialList);

  const handleChange = async chips => {
    updateList(chips);

    let payload = chips;

    if (imageFlag) {
      let imageChips = chips.map(chip => {
        chip.useSpotlightImage = true;
        return chip;
      });
      payload = unionBy(imageChips, value, "slug");
    }

    await client.writeQuery({
      query: gql`
        query getRAC($id: Int!) {
          getRAC(id: $id) @client {
            marketing {
              ${field} {
                name
                slug
                useSpotlightImage
              }
            }
          }
        }
      `,
      variables: {
        id: docId
      },
      data: {
        getRAC: {
          marketing: {
            [field]: payload,
            __typename: "MarketingTagsList"
          },
          __typename: "RAC"
        }
      }
    });
  };

  return (
    <div className="row">
      <div className="col s2">
        <p>{label}</p>
      </div>
      <div className="col s10">
        <Select
          isMulti
          isDisabled={true}
          styles={styles.chip}
          defaultValue={newList}
          options={options}
          getOptionLabel={({ name }) => name}
          getOptionValue={({ slug }) => slug}
          onChange={handleChange}
        />
      </div>
    </div>
  );
};

export default compose(
  graphql(GET_CURRENT_DOC_ID, {
    props: ({ data: { currentDocId } }) => currentDocId
  })
)(withApollo(chip));
