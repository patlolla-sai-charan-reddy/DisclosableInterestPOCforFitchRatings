import React from "react";
import { compose, graphql, Mutation } from "react-apollo";
import swal from "sweetalert";

import GET_CURRENT_DOC_ID from "../../queries/get/GET_CURRENT_DOC_ID";
import UPDATE_DOC from "../../queries/mutations/UPDATE_DOC";
import GET_DOC from "../../queries/get/GET_DOC";

import * as styles from "./Save.styles";

const save = props => {
  const submit = async mutation => {
    const { dbDocId, marketing, racNrac } = props.getRAC;
    const omitTypename = (key, value) => {
      if (key === "effectiveDate" || key === "expiryDate") {
        return new Date(value).toISOString();
      } else if (key === "useSpotlightImage" && value === null) {
        console.log("key", key, "value", value);
        return false;
      } else {
        return key === "__typename" ? undefined : value;
      }
    };
    const newPayload = JSON.parse(
      JSON.stringify({
        dbDocId: dbDocId,
        marketing: marketing,
        racNrac: racNrac
      }),
      omitTypename
    );
    console.log("new Payload", JSON.stringify(newPayload));
    const response = await mutation({
      variables: { docType: props.docType, research: newPayload }
    });
    if (response) {
      swal({
        title: "Save was successful.",
        icon: "success"
      });
    }
  };

  return (
    <Mutation mutation={UPDATE_DOC}>
      {(postResearch, { data }) => (
        <div className={`row ${styles.submitBox}`}>
          <span
            className="waves-effect waves-light btn-small btn-primary"
            onClick={() => submit(postResearch)}
          >
            Save
          </span>
        </div>
      )}
    </Mutation>
  );
};

export default compose(
  graphql(GET_CURRENT_DOC_ID, {
    props: ({ data: { currentDocId } }) => currentDocId
  }),
  graphql(GET_DOC, {
    options: ownProps => ({
      variables: {
        id: ownProps.docId,
        docType: ownProps.docType
      }
    }),
    props: ({ data }) => data
  })
)(save);
