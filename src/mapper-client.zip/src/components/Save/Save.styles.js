import { css } from "emotion";

export const submitBox = css`
  text-align: center;
  margin-bottom: 1.1rem;
  position: relative;
`;
