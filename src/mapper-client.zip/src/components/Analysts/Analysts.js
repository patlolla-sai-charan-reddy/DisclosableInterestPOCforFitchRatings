import React, { useState } from "react";
import { compose, graphql, withApollo } from "react-apollo";
import gql from "graphql-tag";
import Select from "react-select";

import GET_CURRENT_DOC_ID from "../../queries/get/GET_CURRENT_DOC_ID";

import * as styles from "../Chip/Chip.styles";

const analysts = props => {
  const analysts = props.GET_ANALYSTS.getRAC.analysts;
  const client = props.client;

  const analystDataSource = [
    {
      firstName: "Anthony",
      lastName: "Di Tomasso",
      employeeNumber: 123
    },
    {
      firstName: "Michael",
      lastName: "Shepherd",
      employeeNumber: 456
    },
    {
      firstName: "Tommo",
      lastName: "Delago",
      employeeNumber: 789
    }
  ];

  const [updatedAnalysts, updateList] = useState(analysts);

  //   let analystList = updatedAnalysts.map(analyst => ({
  //     name: analyst.firstName + analyst.lastName,
  //     employeeNumber: analyst.employeeNumber
  //   }));

  const handleChange = chips => {
    updateList(chips);

    // console.log("filter", _.filter);

    // const updateArray = _.reject(analystDataSource, item =>
    //   _.find(chips, { employeeNumber: item.employeeNumber })
    // );

    // var employees = _.keyby(chips, c => c.employeeNumber);

    // var updateArray = _.filter(
    //   analystDataSource,
    //   a => employees[a.employeeNumber] !== undefined
    // );

    // console.log("updatedArray", updateArray);

    client.writeFragment({
      id: "RAC",
      fragment: gql`
        fragment Analyst on analysts {
          analysts {
            firstName
            lastName
            employeeNumber
          }
        }
      `,
      data: {
        analysts: chips
      }
    });
  };

  return (
    <div className="row">
      <div className="col s2">
        <p>Analysts</p>
      </div>
      <div className="col s10">
        <Select
          isMulti
          styles={styles.chip}
          defaultValue={updatedAnalysts}
          options={analystDataSource}
          getOptionLabel={({ firstName, lastName }) => firstName + lastName}
          getOptionValue={({ employeeNumber }) => employeeNumber}
          onChange={handleChange}
        />
      </div>
    </div>
  );
};

const GET_ANALYSTS = gql`
  query getRac($id: Int!) {
    getRAC(id: $id) @client {
      analysts {
        firstName
        lastName
        employeeNumber
      }
    }
  }
`;

export default compose(
  graphql(GET_CURRENT_DOC_ID, { name: "GET_CURRENT_DOC_ID" }),
  graphql(GET_ANALYSTS, {
    name: "GET_ANALYSTS",
    options: ownProps => ({
      variables: {
        id: ownProps.GET_CURRENT_DOC_ID.currentDocId.docId
      }
    })
  })
)(withApollo(analysts));
