import React from "react";
import { Router } from "@reach/router";

import * as styles from "./SEO.styles";

import BulkRedirects from "../BulkRedirects/BulkRedirects";
import Search from "../../containers/Search/Search";
import SeoNav from "../Nav/SeoNav";

const seo = () => (
  <>
    <div className={styles.hidden}>
      <Search />
    </div>
    <div className="row">
      <div className={`col s2 ${styles.indexBox}`}>
        <SeoNav />
      </div>
      <div className="col s10">
        <div className={styles.formContainer}>
          <Router primary={false}>
            <BulkRedirects path="bulk-redirects" />
          </Router>
        </div>
      </div>
    </div>
  </>
);

export default seo;
