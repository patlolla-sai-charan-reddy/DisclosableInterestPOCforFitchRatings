import { css } from "emotion";

export const formContainer = css`
  border: 1px solid black;
  padding: 1rem;

  & form {
    margin-left: 1.5rem;
    margin-right: 1.5rem;
  }
`;

export const hidden = css`
  visibility: hidden;
`;

export const indexBox = css`
  border: 1px solid black;
  padding: 0 20px;
  position: sticky;
  top: 1rem;

  & li span {
    cursor: pointer;
  }

  & li span:hover {
    text-decoration: underline;
  }
`;
