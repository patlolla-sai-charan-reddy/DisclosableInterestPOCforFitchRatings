import React from "react";
import { Router } from "@reach/router";
import * as contentful from "contentful-management";

import Header from "../Header/Header";
import Marketing from "../Marketing/Marketing";
import Seo from "../SEO/SEO";

const app = props => {
  //   const Contentful = contentful.createClient({
  //     accessToken:
  //       "CFPAT-24672c477234d64c83551a1885856265ed751d5a9b1fd0bff6b580ed4a2cd41d"
  //   });

  //   const ContentfulEnvironment = async () => {
  //     const space = await Contentful.getSpace("03fbs7oah13w");
  //     const environment = await space.getEnvironment("master");
  //     console.log("environment", environment);
  //     const country = await environment.getEntries({
  //       content_type: "country",
  //       limit: 500
  //     });
  //     console.log("country", country);
  //   };
  //   ContentfulEnvironment();

  return (
    <div className="container">
      <Header />
      <Router primary={false}>
        <Marketing path="marketing/*" />
        <Seo path="seo/*" />
      </Router>
    </div>
  );
};

export default app;
