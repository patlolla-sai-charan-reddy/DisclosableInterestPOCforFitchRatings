import React from "react";

export const LabelRadio = props => {
  const { name, value, defaultChecked } = props;
  return (
    <label>
      <input name={name} type="radio" defaultChecked={defaultChecked} />
      <span>{value}</span>
    </label>
  );
};
