import React from "react";
import { Query } from "react-apollo";

import GET_DOC_TITLE from "../../queries/get/GET_DOC_TITLE";

const title = () => (
  <Query query={GET_DOC_TITLE}>
    {({ loading, error, data }) => {
      if (loading) return "";
      return <h5>{data.getRAC.title}</h5>;
    }}
  </Query>
);

export default title;
