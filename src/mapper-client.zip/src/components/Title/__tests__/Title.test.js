import React from "react";
import TestRenderer from "react-test-renderer";
import { MockedProvider } from "react-apollo/test-utils";
import GET_DOC_TITLE from "../../../queries/get/GET_DOC_TITLE";
import Title from "../Title";

const mocks = [
  {
    request: {
      query: GET_DOC_TITLE
    },
    result: {
      data: {
        getRAC: { title: "Some title" }
      }
    }
  }
];

it("renders without crashing", () => {
  const tree = TestRenderer.create(
    <MockedProvider mocks={mocks} addTypeName={false}>
      <Title />
    </MockedProvider>
  ).toJSON();
  expect(tree).toMatchSnapshot();
});
