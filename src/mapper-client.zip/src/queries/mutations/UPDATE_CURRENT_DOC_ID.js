import gql from "graphql-tag";

export default gql`
  mutation updateDocId($docType: String, $id: Number!) {
    updateDocId(docType: $docType, id: $id) @client {
      docId
      docType
    }
  }
`;
