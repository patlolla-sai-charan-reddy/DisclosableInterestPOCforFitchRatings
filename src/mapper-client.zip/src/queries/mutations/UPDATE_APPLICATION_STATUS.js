import gql from "graphql-tag";

export default gql`
  mutation updateApplicationStatus($loaded: Boolean!) {
    updateApplicationStatus(loaded: $loaded) @client {
      loaded
    }
  }
`;
