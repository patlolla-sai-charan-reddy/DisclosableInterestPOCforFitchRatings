import gql from "graphql-tag";

export default gql`
  mutation uploadImage($title: String!, $description: String!, $file: Upload!) {
    uploadImage(title: $title, description: $description, file: $file) {
      status
      url
    }
  }
`;
