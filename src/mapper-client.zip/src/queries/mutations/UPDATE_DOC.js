import gql from "graphql-tag";

export default gql`
  mutation postResearch($docType: String!, $research: ResearchInput!) {
    postResearch(docType: $docType, research: $research) {
      status
    }
  }
`;
