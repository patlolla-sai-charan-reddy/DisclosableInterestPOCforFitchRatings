import gql from "graphql-tag";

export default gql`
  mutation updateTopic($topics: [TopicInput]!) {
    updateTopics(topics: $topics) {
      status
    }
  }
`;
