import gql from "graphql-tag";

export default gql`
  mutation addTopic($topics: [TopicInput]!) {
    addTopics(topics: $topics) {
      status
    }
  }
`;
