import gql from "graphql-tag";

export default gql`
  mutation deleteTopic($ids: [IdInput]!) {
    deleteTopics(ids: $ids) {
      status
    }
  }
`;
