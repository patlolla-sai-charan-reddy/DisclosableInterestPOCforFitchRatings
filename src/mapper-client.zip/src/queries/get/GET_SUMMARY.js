import gql from "graphql-tag";

export default gql`
  query getSummary($docType: String!, $id: Int!) {
    getRAC(docType: $docType, id: $id) @client {
      marketing {
        summary
      }
    }
  }
`;
