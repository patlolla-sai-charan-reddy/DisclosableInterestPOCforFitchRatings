import gql from "graphql-tag";

export default gql`
  query {
    getCountries {
      countriesList {
        name
        slug
      }
    }
  }
`;
