import gql from "graphql-tag";

export default gql`
  query getEntitiesList($term: String!) {
    getEntitiesList(term: $term) {
      entitiesList {
        name
        slug
      }
    }
  }
`;
