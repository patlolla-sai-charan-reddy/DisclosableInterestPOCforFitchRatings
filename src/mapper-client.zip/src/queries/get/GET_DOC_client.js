import gql from "graphql-tag";

export default gql`
  query getRac($id: Int!) {
    getRAC(id: $id) @client {
      dbDocId
      marketing {
        analysts {
          firstName
          lastName
        }
        contentAccessType {
          name
          slug
        }
        countries {
          name
          slug
          useSpotlightImage
        }
        entities {
          name
          slug
          useSpotlightImage
        }
        language {
          name
          slug
        }
        marketSectors {
          name
          slug
          useSpotlightImage
        }
        metadataTags {
          description
          title
        }
        modifiedByMapperUI
        openGraphTags {
          articleTag
          regions
          sectionTag
          title
          type
          url
        }
        permalink
        regions {
          name
          slug
        }
        reportType {
          name
          slug
        }
        spotLightImage {
          altText
          effectiveDate
          expiryDate
          url
        }
        summary
        topics {
          name
          slug
          useSpotlightImage
        }
      }
      racNrac
    }
  }
`;
