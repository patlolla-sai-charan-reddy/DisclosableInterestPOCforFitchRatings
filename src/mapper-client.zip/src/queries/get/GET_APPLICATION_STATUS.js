import gql from "graphql-tag";

export default gql`
  query {
    applicationStatus @client {
      message
      loaded
    }
  }
`;
