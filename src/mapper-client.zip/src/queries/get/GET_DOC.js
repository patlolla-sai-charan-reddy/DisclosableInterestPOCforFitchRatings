import gql from "graphql-tag";

export default gql`
  query getRAC($docType: String!, $id: Int!) {
    getRAC(docType: $docType, id: $id) {
      dbDocId
      title
      analysts {
        employeeNumber
        firstName
        lastName
        type
      }
      marketing {
        analysts {
          firstName
          lastName
          slug
        }
        contentAccessType {
          name
          slug
        }
        countries {
          name
          slug
          useSpotlightImage
        }
        entities {
          name
          slug
          useSpotlightImage
        }
        language {
          name
          slug
        }
        marketSectors {
          name
          slug
          useSpotlightImage
        }
        metadataTags {
          description
          title
        }
        modifiedByMapperUI
        openGraphTags {
          articleTag
          regions
          sectionTag
          title
          type
          url
        }
        permalink
        regions {
          name
          slug
          useSpotlightImage
        }
        reportType {
          name
          slug
        }
        spotLightImage {
          altText
          effectiveDate
          expiryDate
          url
        }
        summary
        topics {
          name
          slug
          useSpotlightImage
        }
      }
      racNrac
    }
  }
`;
