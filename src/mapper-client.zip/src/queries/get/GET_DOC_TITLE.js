import gql from "graphql-tag";

export default gql`
  query getRac($docType: String!, $id: Int!) {
    currentDocId @client {
      docId @export(as: "id")
      docType @export(as: "docType")
    }
    getRAC(docType: $docType, id: $id) @client {
      title
    }
  }
`;
