import gql from "graphql-tag";

export default gql`
  query getTopics {
    getTopics {
      topics {
        name
        slug
        useSpotlightImage
      }
    }
  }
`;
