import gql from "graphql-tag";

export default gql`
  query getRac($docType: String!, $id: Int!) {
    getRAC(docType: $docType, id: $id) @client {
      marketing {
        metadataTags {
          description
          title
        }
        openGraphTags {
          articleTag
          regions
          sectionTag
          title
          type
          url
        }
      }
    }
  }
`;
