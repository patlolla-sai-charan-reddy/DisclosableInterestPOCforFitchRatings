import gql from "graphql-tag";

export default gql`
  query getTopics($page: Int, $pageSize: Int) {
    getTopics(page: $page, pageSize: $pageSize) {
      topics {
        author
        effectiveDate
        expirationDate
        id
        name
        slug
      }
      count
    }
  }
`;
