import gql from "graphql-tag";

export default gql`
  query {
    getRegions {
      regionsList {
        name
        slug
      }
    }
  }
`;
