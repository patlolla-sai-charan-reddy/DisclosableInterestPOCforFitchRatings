import gql from "graphql-tag";

export default gql`
  query {
    getLanguages {
      languagesList {
        name
        slug
      }
    }
  }
`;
