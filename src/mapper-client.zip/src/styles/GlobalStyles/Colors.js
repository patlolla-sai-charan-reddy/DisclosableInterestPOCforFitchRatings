export const colorAction = "#ee6e73";
export const colorActionHover = "#d06065";
export const colorActionLight = "#ee6e7380";
