import { css } from "emotion";

export const spaceBetweenGroup = css`
  display: flex;
  justify-content: space-between;
`;
