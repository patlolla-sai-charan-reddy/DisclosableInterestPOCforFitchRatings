import { ApolloClient } from "apollo-client";
import { ApolloProvider } from "react-apollo";
import { createUploadLink } from "apollo-upload-client";
import fetch from "node-fetch";
import gql from "graphql-tag";
// import { HttpLink } from "apollo-link-http";
import { InMemoryCache } from "apollo-cache-inmemory";
import { LicenseManager } from "ag-grid-enterprise";
import React from "react";
import ReactDOM from "react-dom";

// css from libs
import "./styles/libs/materialize/materialize.scss";
import "./styles/libs/materialize/materialIcons.scss";

// css custom
import "./styles/index.scss";
import App from "./components/App/App";

// Apollo config

// Typename to query cache
const cache = new InMemoryCache({
  addTypename: true,
  dataIdFromObject: object => {
    switch (object.__typename) {
      case "Analyst":
        return `${object.__typename}${object.employeeNumber}`;
      case "Country":
        return `Country${object.slug}`;
      case "Entity":
        return `Entity${object.slug}`;
      case "Language":
        return `Language${object.slug}`;
      case "MarketSector":
        return `MarketSector${object.slug}`;
      case "MarketingTag":
        return `MarketingTag${object.slug}`;
      case "MetadataTag":
        return `MetadataTag`;
      case "OpenGraphTag":
        return `OpenGraphTag`;
      case "Region":
        return `Region${object.slug}`;
      case "Topic":
        return `Topic${object.slug}`;
      default:
        return object.__typename;
    }
  }
});

// Apollo remote config
const linkRemote = createUploadLink({
  fetch,
  uri: process.env.REACT_APP_GRAPHQL
});

// initalizing the Apollo Client
const client = new ApolloClient({
  cache,
  link: linkRemote,
  resolvers: {
    Mutation: {
      updateApplicationStatus: (_, { loaded }, { cache }) => {
        const query = gql`
          query {
            applicationStatus @client {
              message
              loaded
            }
          }
        `;
        const previousState = cache.readQuery({ query });

        const data = {
          ...previousState,
          applicationStatus: {
            ...previousState.applicationStatus,
            loaded: loaded
          }
        };

        cache.writeData({ query, data });
      },
      updateDocId: (_, { docType, id }, { cache }) => {
        const query = gql`
          query GetCurrentDocId {
            currentDocId @client {
              docId
              docType
            }
          }
        `;
        const previousState = cache.readQuery({ query });

        const data = {
          ...previousState,
          currentDocId: {
            ...previousState.currentDocId,
            docId: id,
            docType
          }
        };

        cache.writeData({ query, data });
      }
    }
  }
});

// default state
const initState = () => {
  cache.writeData({
    data: {
      applicationStatus: {
        message: "Please search for a document.",
        loaded: false,
        __typename: "ApplicationStatus"
      },
      currentDocId: {
        docId: 0,
        docType: "",
        __typename: "CurrentDocId"
      }
    }
  });
};

initState();

// state cleanup
client.onResetStore(async () => {
  await initState();
});

client.onClearStore(async () => {
  await initState();
});

// ag-grid setup

LicenseManager.setLicenseKey(
  "Fitch_Ratings_BRM_Tool_1Devs_1Deployment_16_April_2020__MTU4Njk5MTYwMDAwMA==f1cb19ebf52b2f3b0c697e0e1da5f327"
);

const Root = () => (
  <ApolloProvider client={client}>
    <App />
  </ApolloProvider>
);

ReactDOM.render(<Root />, document.getElementById("root"));
