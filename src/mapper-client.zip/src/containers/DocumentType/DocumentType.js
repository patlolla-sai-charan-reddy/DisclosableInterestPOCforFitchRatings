import React, { Component } from "react";
import { compose, graphql } from "react-apollo";

import GET_APPLICATION_STATUS from "../../queries/get/GET_APPLICATION_STATUS";

import Summary from "../../components/Summary/Summary";
import Save from "../../components/Save/Save";
import Status from "../../components/Status/Status";
import Title from "../../components/Title/Title";
import { spaceBetweenGroup } from "../../styles/GlobalStyles";
import { LabelRadio } from "../../components/Label/Label";

class DocumentType extends Component {
  state = {
    checked: true
  };
  render() {
    if (!this.props.applicationStatus.loaded) return <Status />;
    return (
      <div>
        <form>
          <div className="row">
            <div className="col s12">
              <Title />
              <Summary />
            </div>
          </div>
          <div className="row">
            <div className="col s2">
              <p>Viewing Mode</p>
            </div>
            <div className="col s8">
              <p className={spaceBetweenGroup}>
                <LabelRadio
                  name="viewMode"
                  value="Public View"
                  defaultChecked={this.state.checked}
                />
                <LabelRadio name="viewMode" value="Known User" />
                <LabelRadio name="viewMode" value="Premium Content" />
              </p>
            </div>
          </div>
        </form>
        <Save />
      </div>
    );
  }
}

export default compose(
  graphql(GET_APPLICATION_STATUS, {
    props: ({ data }) => data
  })
)(DocumentType);
