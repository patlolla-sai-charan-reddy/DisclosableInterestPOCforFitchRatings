import React, { Component } from "react";
import { compose, graphql } from "react-apollo";

import GET_APPLICATION_STATUS from "../../queries/get/GET_APPLICATION_STATUS";

import Analysts from "../../components/Analysts/Analysts";
import CountryChip from "../../components/Chip/CountryChip/CountryChip";
import EntityChip from "../../components/Chip/EntityChip/EntityChip";
import Language from "../../components/Language/Language";
import MarketSectorChip from "../../components/Chip/MarketSectorChip/MarketSectorChip";
import RegionChip from "../../components/Chip/RegionChip/RegionChip";
import Save from "../../components/Save/Save";
import Status from "../../components/Status/Status";
import Summary from "../../components/Summary/Summary";
import Title from "../../components/Title/Title";
import TopicChip from "../../components/Chip/TopicChip/TopicChip";

export class Taxonomy extends Component {
  render() {
    if (!this.props.applicationStatus.loaded) return <Status />;
    return (
      <form>
        <div className="row">
          <div className="col s12">
            <Title />
            <Summary />
          </div>
        </div>
        <MarketSectorChip />
        <EntityChip />
        <CountryChip />
        <RegionChip />
        <Language />
        {/* <Analysts /> */}
        <TopicChip />
        <Save />
      </form>
    );
  }
}

export default compose(
  graphql(GET_APPLICATION_STATUS, {
    props: ({ data }) => data
  })
)(Taxonomy);
