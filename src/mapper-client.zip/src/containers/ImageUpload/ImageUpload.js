import React, { Component } from "react";
import { compose, graphql, withApollo, Mutation } from "react-apollo";
import gql from "graphql-tag";

import GET_CURRENT_DOC_ID from "../../queries/get/GET_CURRENT_DOC_ID";
import GET_SPOTLIGHT_IMAGE from "../../queries/get/GET_SPOTLIGHT_IMAGE";
import UPLOAD_IMAGE from "../../queries/mutations/UPLOAD_IMAGE";

import * as styles from "./ImageUpload.styles";

export class ImageUpload extends Component {
  state = {
    disabled: true,
    image: "",
    initial: true,
    selectedFile: null,
    uploadStatus: ""
  };

  static getDerivedStateFromProps(nextProps, prevState) {
    if (
      prevState.initial &&
      nextProps.marketing.spotLightImage.url !== prevState.image
    ) {
      return { image: nextProps.marketing.spotLightImage.url, initial: false };
    } else return null;
  }

  fileSelectHandler = event => {
    this.setState({
      disabled: false,
      selectedFile: event.target.files[0],
      image: URL.createObjectURL(event.target.files[0])
    });
  };

  fileUploadHandler = async (event, uploadImage) => {
    if (this.props.marketing.spotLightImage.altText) {
      const { data } = await uploadImage({
        variables: {
          title: this.props.marketing.spotLightImage.altText,
          description: this.props.marketing.spotLightImage.altText,
          file: this.state.selectedFile
        }
      });

      await this.props.client.writeQuery({
        query: gql`
          query getRAC($id: Int!) {
            getRAC(id: $id) @client {
              marketing {
                spotLightImage {
                  altText
                  url
                }
              }
            }
          }
        `,
        variables: {
          id: this.props.docId
        },
        data: {
          getRAC: {
            marketing: {
              spotLightImage: {
                altText: this.props.marketing.spotLightImage.altText,
                url: data.uploadImage.url,
                __typename: "Image"
              },
              __typename: "MarketingTagsList"
            },
            __typename: "RAC"
          }
        }
      });

      this.setState({
        uploadStatus: data.uploadImage.status
      });
    } else {
      this.setState({
        uploadStatus: "Please add alt text for the image."
      });
    }
  };

  render() {
    return (
      <Mutation mutation={UPLOAD_IMAGE}>
        {(uploadImage, { data }) => {
          return (
            <div className={`col s4 ${styles.imageContainer}`}>
              <div>
                <input
                  className={styles.inputBtn}
                  id="contained-button-file"
                  type="file"
                  onChange={this.fileSelectHandler}
                />
                <label htmlFor="contained-button-file">
                  {this.state.image ? (
                    <img
                      className="hero-image"
                      src={this.state.image}
                      alt="images"
                    />
                  ) : (
                    <i className="material-icons prefix large add-image">
                      add_photo_alternate
                    </i>
                  )}
                </label>
                <div className={styles.uploadBox}>
                  <p className={styles.uploadButton}>
                    <span
                      className={
                        "waves-effect waves-light btn btn-primary " +
                        (this.state.disabled ? "disabled" : "")
                      }
                      onClick={event =>
                        this.fileUploadHandler(event, uploadImage)
                      }
                    >
                      <i className="material-icons right">cloud_upload</i>
                      Upload
                    </span>
                  </p>
                  <p className={styles.uploadMessage}>
                    <label className="shine">{this.state.uploadStatus}</label>
                  </p>
                </div>
              </div>
            </div>
          );
        }}
      </Mutation>
    );
  }
}

export default compose(
  graphql(GET_CURRENT_DOC_ID, {
    props: ({ data: { currentDocId } }) => currentDocId
  }),
  graphql(GET_SPOTLIGHT_IMAGE, {
    options: ownProps => ({
      variables: {
        id: ownProps.docId,
        docType: ownProps.docType
      }
    }),
    props: ({ data: { getRAC } }) => getRAC
  })
)(withApollo(ImageUpload));
