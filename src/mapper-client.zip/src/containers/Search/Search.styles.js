import { css } from "emotion";

export const searchBox = css`
  text-align: center;
`;
