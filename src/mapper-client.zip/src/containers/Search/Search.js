import React, { Component } from "react";
import { ApolloConsumer, graphql, compose } from "react-apollo";

import GET_DOC from "../../queries/get/GET_DOC";
// import GET_ISSUER from "../../queries/get/GET_ISSUER";
// import GET_TRANSACTION from "../../queries/get/GET_TRANSACTION";
import UPDATE_CURRENT_DOC_ID from "../../queries/mutations/UPDATE_CURRENT_DOC_ID";
import UPDATE_APPLICATION_STATUS from "../../queries/mutations/UPDATE_APPLICATION_STATUS";

import * as styles from "./Search.styles";
import { spaceBetweenGroup } from "../../styles/GlobalStyles";

export class Search extends Component {
  state = {
    docId: "",
    data: {},
    fieldError: false,
    docType: "research",
    query: {
      // issuer: GET_ISSUER,
      research: GET_DOC
      // transaction: GET_TRANSACTION
    },
    selectedQuery: GET_DOC
  };

  onDocTypeSelector = event => {
    this.setState({
      docType: event.target.value
    });
  };

  onSubmitHandler = async (
    event,
    client,
    updateDocId,
    updateApplicationStatus
  ) => {
    event.preventDefault();
    const id = parseInt(this.state.docId);

    if (id) {
      await updateApplicationStatus({
        variables: {
          loaded: false
        }
      });
      await client.resetStore();
      try {
        await client.query({
          query: GET_DOC,
          variables: {
            id,
            docType: this.state.docType
          }
        });

        console.log("data cache", client.cache);

        await updateDocId({
          variables: {
            id,
            docType: this.state.docType
          }
        });

        await updateApplicationStatus({
          variables: {
            loaded: true
          }
        });
      } catch (error) {
        await client.writeData({
          data: {
            applicationStatus: {
              message: "Sorry no marketing data found for the searched ID.",
              loaded: false,
              __typename: "ApplicationStatus"
            }
          }
        });
        return null;
      }
    } else {
      this.setState({
        fieldError: true
      });
    }
  };
  render() {
    const { updateDocId, updateApplicationStatus } = this.props;
    return (
      <ApolloConsumer>
        {client => (
          <div className={`row ${styles.searchBox}`}>
            <div className="input-field col s3">
              <i className="material-icons prefix">search</i>
              <input
                type="number"
                className="validate"
                placeholder="Document ID"
                value={this.state.docId}
                onChange={event =>
                  this.setState({
                    docId: event.target.value,
                    fieldError: false
                  })
                }
                onKeyPress={event =>
                  event.charCode === 13 &&
                  this.onSubmitHandler(
                    event,
                    client,
                    updateDocId,
                    updateApplicationStatus
                  )
                }
              />
              {this.state.fieldError ? (
                <span
                  className="helper-text"
                  data-error="wrong"
                  data-success="right"
                >
                  Please enter a valid Document ID.
                </span>
              ) : (
                ""
              )}
            </div>
            <div className="col s9">
              <p className={spaceBetweenGroup} id="search">
                <label>
                  <input
                    defaultChecked="true"
                    name="search"
                    type="radio"
                    value="research"
                    onChange={this.onDocTypeSelector}
                  />
                  <span>Research</span>
                </label>
                <label>
                  <input
                    name="search"
                    type="radio"
                    value="issuer"
                    onChange={this.onDocTypeSelector}
                  />
                  <span>Issuer</span>
                </label>
                <label>
                  <input
                    name="search"
                    type="radio"
                    value="transaction"
                    onChange={this.onDocTypeSelector}
                  />
                  <span>Transaction</span>
                </label>
                <span
                  className="waves-effect waves-light btn-small btn-primary"
                  onClick={event =>
                    this.onSubmitHandler(
                      event,
                      client,
                      updateDocId,
                      updateApplicationStatus
                    )
                  }
                >
                  Search
                </span>
              </p>
            </div>
          </div>
        )}
      </ApolloConsumer>
    );
  }
}

export default compose(
  graphql(UPDATE_CURRENT_DOC_ID, { name: "updateDocId" }),
  graphql(UPDATE_APPLICATION_STATUS, { name: "updateApplicationStatus" })
)(Search);
