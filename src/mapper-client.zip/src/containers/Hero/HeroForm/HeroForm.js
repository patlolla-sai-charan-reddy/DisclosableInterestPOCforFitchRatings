import React from "react";
import { compose, graphql } from "react-apollo";

import GET_CURRENT_DOC_ID from "../../../queries/get/GET_CURRENT_DOC_ID";
import GET_HERO_FIELDS from "../../../queries/get/GET_HERO_FIELDS";

import DateInput from "../../../components/DateInput/DateInput";
import InputField from "../../../components/InputField/InputField";
import CountryChip from "../../../components/Chip/CountryChip/CountryChip";
import EntityChip from "../../../components/Chip/EntityChip/EntityChip";
import MarketSectorChip from "../../../components/Chip/MarketSectorChip/MarketSectorChip";
import RegionChip from "../../../components/Chip/RegionChip/RegionChip";
import TopicChip from "../../../components/Chip/TopicChip/TopicChip";

const heroForm = ({
  getRAC: {
    marketing: { spotLightImage }
  }
}) => {
  const { altText, effectiveDate, expiryDate, __typename } = spotLightImage;

  return (
    <form action="">
      <InputField
        label="Alt Text"
        field={altText}
        property="altText"
        type="spotLightImage"
        typeName={__typename}
      />
      <div className="row">
        <DateInput
          label="Effective Date"
          property="effectiveDate"
          type="spotLightImage"
          typeName={__typename}
          value={effectiveDate}
        />
        <DateInput
          label="Expiration Date"
          property="expiryDate"
          type="spotLightImage"
          typeName={__typename}
          value={expiryDate}
        />
      </div>
      <CountryChip imageFlag="true" />
      <EntityChip imageFlag="true" />
      <MarketSectorChip imageFlag="true" />
      <RegionChip imageFlag="true" />
      <TopicChip imageFlag="true" />
    </form>
  );
};

export default compose(
  graphql(GET_CURRENT_DOC_ID, {
    props: ({ data: { currentDocId } }) => currentDocId
  }),
  graphql(GET_HERO_FIELDS, {
    options: ownProps => ({
      variables: {
        id: ownProps.docId,
        docType: ownProps.docType
      }
    }),
    props: ({ data: getRAC }) => getRAC
  })
)(heroForm);
