import React, { Component } from "react";
import { compose, graphql } from "react-apollo";

// import GET_CURRENT_DOC_ID from "../../queries/get/GET_CURRENT_DOC_ID";
// import GET_HERO from "../../queries/get/GET_HERO";
// import UPLOAD_IMAGE from "../../queries/mutations/UPLOAD_IMAGE";
import GET_APPLICATION_STATUS from "../../queries/get/GET_APPLICATION_STATUS";

import * as styles from "./Hero.styles";

import HeroForm from "./HeroForm/HeroForm";
import Summary from "../../components/Summary/Summary";
import ImageUpload from "../ImageUpload/ImageUpload";

import Save from "../../components/Save/Save";
import Status from "../../components/Status/Status";
import Title from "../../components/Title/Title";

export class Hero extends Component {
  state = {
    effectiveDate: "",
    expirationDate: ""
  };

  onAltChangeHandler(value) {
    this.setState({
      altText: value
    });
  }

  render() {
    if (!this.props.applicationStatus.loaded) return <Status />;
    return (
      <div>
        <Title />
        <div className={styles.heroRow}>
          <ImageUpload />
          <div className="col s8 abstract-container">
            <Summary />
          </div>
        </div>
        <HeroForm />
        <Save />
      </div>
    );
  }
}

export default compose(
  graphql(GET_APPLICATION_STATUS, {
    props: ({ data }) => data
  })
)(Hero);
