import { css } from "emotion";
// import * as colors from "../../styles/theme/colors";

export const heroRow = css`
  // margin-left: 1.5rem;
  // margin-right: 1.5rem;
  height: 15rem;

  & .abstract-container {
    height: 70%;

    & textarea {
      height: 100%;
    }
  }
`;

// export const imageContainer = css`
//   text-align: center;

//   & .add-image {
//     font-size: 9rem;
//     cursor: pointer;
//     color: ${colors.colorAction};

//     &:hover {
//       color: ${colors.colorActionHover};
//     }
//   }

//   & img {
//     max-width: 78%;
//   }
// `;

// export const uploadBox = css`
//   text-align: center;
// `;

// export const uploadButton = css`
//   margin-bottom: 0;
// `;

// export const uploadMessage = css`
//   margin-top: 0;
// `;

// export const inputBtn = css`
//   display: none;
// `;
