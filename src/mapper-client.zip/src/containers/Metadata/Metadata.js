import React, { Component } from "react";
import { compose, graphql } from "react-apollo";

import GET_APPLICATION_STATUS from "../../queries/get/GET_APPLICATION_STATUS";
import GET_CURRENT_DOC_ID from "../../queries/get/GET_CURRENT_DOC_ID";
import GET_DOC_METADATA from "../../queries/get/GET_DOC_METADATA";

import * as styles from "./Metadata.styles";

import MetaInputField from "../../components/InputField/MetaInputField/MetaInputField";
import Save from "../../components/Save/Save";
import Status from "../../components/Status/Status";

export class Metadata extends Component {
  render() {
    if (!this.props.applicationStatus.loaded) return <Status />;

    const { metadataTags, openGraphTags } = this.props.getRAC.marketing;

    const { description, title: metaTitle } = metadataTags;
    const {
      articleTag,
      regions,
      sectionTag,
      title: openGraphTitle,
      type,
      url
    } = openGraphTags;
    console.log("meta", this.props.getRAC.marketing);
    return (
      <div className={styles.metadataContainer}>
        <form>
          <div className="meta-fields-container">
            <h5 className="margin-top-0">Metadata</h5>
            <div className="meta-fields">
              <MetaInputField
                label="Title"
                field={metaTitle}
                property="title"
                type="metadataTags"
              />
              <MetaInputField
                label="Description"
                field={description}
                property="description"
                type="metadataTags"
              />
            </div>
          </div>
          <div className="open-graph-container">
            <h5>Open Graph Tags</h5>
            <div className={styles.metaFields}>
              <MetaInputField
                label="Title"
                field={openGraphTitle}
                property="title"
                type="openGraphTags"
              />
              <MetaInputField
                label="Url"
                field={url}
                property="url"
                type="openGraphTags"
              />
              <MetaInputField
                label="Type"
                field={type}
                property="type"
                type="openGraphTags"
              />
              <MetaInputField
                label="Regions"
                field={regions}
                property="regions"
                type="openGraphTags"
              />
              <MetaInputField
                label="Article Tag"
                field={articleTag}
                property="articleTag"
                type="openGraphTags"
              />
              <MetaInputField
                label="Section Tag"
                field={sectionTag}
                property="sectionTag"
                type="openGraphTags"
              />
            </div>
          </div>
        </form>
        <Save />
      </div>
    );
  }
}

export default compose(
  graphql(GET_APPLICATION_STATUS, {
    props: ({ data }) => data
  }),
  graphql(GET_CURRENT_DOC_ID, {
    props: ({ data: { currentDocId } }) => currentDocId
  }),
  graphql(GET_DOC_METADATA, {
    options: ownProps => ({
      variables: {
        id: ownProps.docId,
        docType: ownProps.docType
      }
    }),
    props: ({ data: getRAC }) => getRAC
  })
)(Metadata);
