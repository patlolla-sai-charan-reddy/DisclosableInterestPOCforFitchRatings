import { css } from "emotion";

export const metadataContainer = css`
  margin-bottom: 1rem;
`;

export const metaFields = css`
  padding: 1rem;
  border: 1px solid black;
`;
