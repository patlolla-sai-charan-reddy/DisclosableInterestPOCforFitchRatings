import { css } from "emotion";
import * as colors from "../../styles/GlobalStyles";

export const topicsContainer = css`
  margin-bottom: 1rem;
`;

export const topicAddIcon = css`
  font-size: 3rem;
  color: ${colors.colorAction};
  cursor: pointer;

  &:hover {
    color: ${colors.colorActionHover};
  }
`;

export const save = css`
  margin-top: 1rem;
`;
