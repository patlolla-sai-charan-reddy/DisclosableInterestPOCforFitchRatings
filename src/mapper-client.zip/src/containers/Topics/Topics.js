import React, { Component } from "react";
import MaterialTable from "material-table";
import { ApolloConsumer } from "react-apollo";
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import { omit } from "lodash";

import ADD_TOPIC from "../../queries/mutations/ADD_TOPIC";
import DELETE_TOPIC from "../../queries/mutations/DELETE_TOPIC";
import GET_TOPICS from "../../queries/get/GET_TOPICS_LIST";
import UPDATE_TOPIC from "../../queries/mutations/UPDATE_TOPIC";

import * as styles from "./Topics.style";

import Save from "../../components/Save/Save";

export class Topics extends Component {
  tableRef = React.createRef();
  state = {
    topicsList: [],
    tableMessage: "No topics to display."
  };
  getMuiTheme = () =>
    createMuiTheme({
      shadows: Array(25).fill("none"),
      typography: {
        useNextVariants: true
      },
      overrides: {
        MuiInput: {
          underline: {
            "&:after": {
              content: "",
              border: "none"
            },
            "&:before": {
              content: "",
              border: "none"
            }
          }
        }
      }
    });

  getTopics = async (tableProps, client) => {
    try {
      const {
        data: {
          getTopics: { topics, count }
        }
      } = await client.query({
        query: GET_TOPICS,
        variables: {
          page: tableProps.page,
          pageSize: tableProps.pageSize
        },
        fetchPolicy: "network-only"
      });
      const processedTopics = topics.map(topic => {
        topic.effectiveDate = new Date(topic.effectiveDate);
        topic.expirationDate = new Date(topic.expirationDate);
        return topic;
      });
      return {
        data: processedTopics,
        page: tableProps.page,
        totalCount: count
      };
    } catch (error) {
      console.error(error);
      this.setState({
        tableMessage: "Topics fetch failed."
      });
    }
  };

  mutationHandler = async (client, mutation, data) => {
    return client.mutate({
      mutation: mutation,
      variables: data
      // refetchQueries: () => [{ query: GET_TOPICS }]
    });
  };

  formatDate = value => {
    // value = new Date(value).toISOString();
    value = Date.parse(value);
    return value;
  };

  typeNameRemover = value => {
    value.effectiveDate = this.formatDate(value.effectiveDate);
    value.expirationDate = this.formatDate(value.expirationDate);
    return omit(value, "__typename");
  };

  slugify = string =>
    string
      .toString()
      .trim()
      .toLowerCase()
      .replace(/\s+/g, "-")
      .replace(/[^\w\-]+/g, "")
      .replace(/\-\-+/g, "-")
      .replace(/^-+/, "")
      .replace(/-+$/, "");

  render() {
    return (
      <ApolloConsumer>
        {client => {
          return (
            <div className={`topics-table ${styles.topicsContainer}`}>
              <MuiThemeProvider theme={this.getMuiTheme()}>
                <MaterialTable
                  tableRef={this.tableRef}
                  localization={{
                    body: {
                      emptyDataSourceMessage: this.state.tableMessage
                    }
                  }}
                  columns={[
                    { title: "Name", field: "name" },
                    {
                      title: "Author",
                      field: "author"
                    },
                    {
                      title: "Effective Date",
                      field: "effectiveDate",
                      type: "date"
                    },
                    {
                      title: "Expiration Date",
                      field: "expirationDate",
                      type: "date"
                    }
                  ]}
                  data={async query => await this.getTopics(query, client)}
                  title="Topics Dictionary"
                  editable={{
                    onRowAdd: async newData => {
                      const processedData = this.typeNameRemover(newData);
                      let topics = [];
                      processedData.slug = this.slugify(processedData.name);
                      topics.push(processedData);
                      const message = await this.mutationHandler(
                        client,
                        ADD_TOPIC,
                        { topics: topics }
                      );
                      if (message) {
                        this.tableRef.current.onQueryChange();
                      }
                    },
                    onRowUpdate: async (newData, oldData) => {
                      const processedData = this.typeNameRemover(newData);
                      let topics = [];
                      topics.push(processedData);
                      await this.mutationHandler(client, UPDATE_TOPIC, {
                        topics: topics
                      });
                      // if (message) {
                      // this.tableRef.current.onQueryChange();
                      // }
                    },
                    onRowDelete: async row => {
                      let ids = [];
                      ids.push({ id: row.id });
                      const message = await this.mutationHandler(
                        client,
                        DELETE_TOPIC,
                        { ids: ids }
                      );
                      if (message) {
                        this.tableRef.current.onQueryChange();
                      }
                    }
                  }}
                  options={{
                    paper: {
                      boxShadow: "none"
                    },
                    exportButton: true
                  }}
                />
              </MuiThemeProvider>
              <div className={styles.save}>
                <Save />
              </div>
            </div>
          );
        }}
      </ApolloConsumer>
    );
  }
}

export default Topics;
