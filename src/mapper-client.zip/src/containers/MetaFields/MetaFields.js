import React, { Component } from "react";

export class MetaFields extends Component {
  render() {
    return <form action="" />;
  }
}

export default MetaFields;
