module.exports = {
    client: {
      includes: ["./src/**/*.js"],
      service: {
        name: "my-graphql-app",
        url: "http://localhost:4000",
      }
    }
  };