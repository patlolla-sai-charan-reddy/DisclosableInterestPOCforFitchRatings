# FITCH Storybook

This repository contains the component Storybook for PoC.

## Getting Started

This repo depends on the graphql server being run locally on port 4000.

Please clone the `fitch_graphql` repo and follow the instructions in the readme to get set up.

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes.

To get started, ensure [Node.js](https://nodejs.org/en/) is installed and added to your `PATH`.

### Installation

```bash
npm install
```

or

```bash
yarn
```

### Usage

To start the storybook use:

```bash
npm run storybook
```

or

```
yarn storybook
```
