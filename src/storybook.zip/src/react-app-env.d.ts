// / <reference types="react-scripts" />
declare module '@brightcove/react-player-loader'
