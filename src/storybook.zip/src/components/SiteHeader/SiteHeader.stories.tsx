import React from 'react'
import { storiesOf } from '@storybook/react'

import { SiteHeader } from '.'

const image = {
  url:
    'https://your.fitchratings.com/rs/732-CKH-767/images/fitch-ratings-email-logo.png',
  title: 'Fitch Ratings Logo'
}

storiesOf('Atoms/SiteHeader', module).add('default', () => (
  <SiteHeader
    image={image}
    href="https://your.fitchratings.com/homepage.html"
  />
))
