import { css } from 'emotion'

export const logo = css`
  float: left;
`

export const wrapper = css`
  margin: 2.875rem 0 0.938rem;
`

export const image = css`
  width: 10.125rem;
  height: auto;
`

export const hasHeader = css`
  padding-top: 1.3rem;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 100;
`
