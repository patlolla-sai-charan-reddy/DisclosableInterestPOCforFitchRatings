import React from 'react'
import { css } from 'emotion'

import { header, wrapper1, content } from '../GlobalStyles'
import * as styles from './SiteHeader.style'

export type SiteHeaderImage = {
  url: string
  title: string
}

export type SiteHeaderProps = {
  href: string
  image: SiteHeaderImage
  hasHeader?: boolean
}

export const SiteHeader = ({ image, href, hasHeader }: SiteHeaderProps) => (
  <header
    className={css`
      ${header};
      ${hasHeader && styles.hasHeader}
    `}
  >
    <div
      className={css`
        ${wrapper1};
        ${content};
      `}
    >
      <div className={styles.logo}>
        <div>
          <div className={styles.wrapper}>
            <a href={href}>
              <img alt={image.title} className={styles.image} src={image.url} />
            </a>
          </div>
        </div>
      </div>
    </div>
  </header>
)
