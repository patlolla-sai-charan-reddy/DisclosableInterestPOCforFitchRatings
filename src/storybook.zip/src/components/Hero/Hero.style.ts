import { css } from 'emotion'
import {
  c2,
  c4,
  c9,
  heading1,
  lh1,
  mpb2,
  mq1,
  mq2,
  mq3,
  mq4,
  mq5,
  va
} from '../GlobalStyles'

export const header = css`
  position: relative;
  height: calc(100vh - 6.25rem);
  max-height: 53.125rem;
  min-height: 37.5rem;
  padding: 0;
  background-color: ${c9};
  background-repeat: no-repeat;
  background-position: center top;
  background-size: cover;
  color: ${c9};
  overflow: hidden;

  .heading--sub {
    margin-bottom: 1.125rem;
    font-size: 1.75rem;
    text-transform: initial;
  }

  p {
    max-width: 48rem;
    margin-bottom: 0;
    font-size: 1.125rem;
    font-weight: 700;
    line-height: ${lh1};

    & + .button__wrapper {
      margin-top: ${mpb2};
    }
  }

  ${mq1} {
    height: 15rem;
  }
  ${mq5} {
    margin-top: 0;
  }
`

export const heading = css`
  ${heading1}
  max-width: 57rem;
  font-size: 5.25rem;
  line-height: 1;
  margin-bottom: 1.5rem;
`

export const wrapper1 = css`
  width: 100%;
  margin: auto;
  max-width: 85.5rem;
`

export const content = css`
  padding: 0 1.5rem;
`

export const banner = css`
  ${wrapper1};
  height: 100%;
  ${content};
`

export const nav = css`
  position: absolute;
  left: 0;
  bottom: 0;
  width: 100%;
  max-width: 58.25%;
  height: 7.5rem;
  background: ${c4};
  color: ${c9};
  z-index: 1;
  ${mq2} {
    max-width: calc(100% - 7.5rem);
  }
  ${mq3} {
    display: none;
  }
  ${mq5} {
    display: none;
  }
`

export const links = css`
  width: 100%;
  max-width: 48.063rem;
  float: right;
  ${mq2} {
    max-width: 100%;
    padding: 0 ${mpb2};
    float: left;
  }
`

export const text = css`
  padding-left: 4.375rem;
  z-index: 1;
  ${va}
  ${mq3} {
    padding: 0;
  }
  ${mq4} {
    padding: 0;
  }
`

export const textDark = css`
  ${text}
  color: ${c2};
`
