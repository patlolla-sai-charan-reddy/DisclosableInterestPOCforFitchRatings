export default [
  {
    title: 'Copy Internal Handcrafted Plastic Bike',
    abstract:
      'Quos eveniet nemo et labore magni odit laudantium ut. Aperiam voluptatem quam aut. Aut cupiditate voluptatem quisquam porro ducimus. Dolor magnam sapiente dolorum tempora. Ipsum aut vel. Debitis ab veniam.',
    image: {
      url:
        'https://images.ctfassets.net/03fbs7oah13w/63puEMmiCyXkwhB2D9ad2H/cc69c62b0015b33a754042924e1fbd49/audience-blur-bokeh-976866.jpg'
    }
  },
  {
    title: 'Bluetooth Fields Invoice Savings Account Handmade Cotton Computer',
    abstract:
      'Sed et adipisci. Vel voluptatum qui ipsum voluptatibus est aut. Et dolorum unde nam reiciendis. Dolore inventore maxime. Vel reprehenderit pariatur ad minus sed.',
    image: {
      url:
        'https://images.ctfassets.net/03fbs7oah13w/63puEMmiCyXkwhB2D9ad2H/cc69c62b0015b33a754042924e1fbd49/audience-blur-bokeh-976866.jpg'
    }
  },
  {
    title: 'Paradigms Encoding Backing Up Ball Metal Usability',
    abstract:
      'Unde ex atque est. Delectus non molestiae rerum quisquam deserunt. Incidunt numquam laudantium ut laborum voluptates quidem maiores voluptate. Aut reprehenderit tempore commodi. Necessitatibus blanditiis impedit non reprehenderit ea.',
    image: {
      url:
        'https://images.ctfassets.net/03fbs7oah13w/63puEMmiCyXkwhB2D9ad2H/cc69c62b0015b33a754042924e1fbd49/audience-blur-bokeh-976866.jpg'
    }
  }
]
