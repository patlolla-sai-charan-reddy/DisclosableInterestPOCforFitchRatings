import React from 'react'
import { storiesOf } from '@storybook/react'
import { Query } from 'react-apollo'
import gql from 'graphql-tag'

import { Hero } from '.'

const GET_BANNERS_QUERY = gql`
  {
    bannerCollection {
      items {
        title
        abstract
        image(preview: false) {
          url
        }
      }
    }
  }
`

const sections = [
  {
    number: '01',
    title: 'Ratings'
  },
  {
    number: '02',
    title: 'Research'
  },
  {
    number: '03',
    title: 'Video'
  }
]

const buttons = [
  { label: 'VIEW ALL OUTLOOKS', link: 'http://www.fitchratings.com' },
  { label: 'VIEW ALL OUTLOOKS', link: 'http://www.fitchratings.com' }
]

storiesOf('Molecules/Hero', module).add('default', () => (
  <Query query={GET_BANNERS_QUERY} fetchPolicy="no-cache">
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { items } = data.bannerCollection

      return <Hero {...items[0]} sections={sections} />
    }}
  </Query>
))

storiesOf('Molecules/Hero', module).add('without image and inverted', () => (
  <Query query={GET_BANNERS_QUERY} fetchPolicy="no-cache">
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { items } = data.bannerCollection
      items[0].image = null

      return <Hero {...items[0]} sections={sections} dark />
    }}
  </Query>
))

storiesOf('Molecules/Hero', module).add('with buttons', () => (
  <Query query={GET_BANNERS_QUERY} fetchPolicy="no-cache">
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { items } = data.bannerCollection
      items[0].abstract = null

      return <Hero {...items[0]} sections={sections} buttons={buttons} />
    }}
  </Query>
))
