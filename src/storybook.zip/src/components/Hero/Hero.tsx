import React from 'react'
import { css } from 'emotion'

import { JumpLinks } from '../JumpLink/JumpLinks'
import { SVGButton } from '../SVGButton/SVGButton'
import * as styles from './Hero.style'
import { bgBlend, buttonWrapper, buttonWrapper1 } from '../GlobalStyles'

export type HeroButton = {
  label: string
  link: string
}

export type HeroImage = {
  url: string
}

export type HeroSection = {
  number: string
  title: string
}

export type HeroProps = {
  title: string
  abstract: string
  image: HeroImage
  sections: HeroSection[]
  buttons: HeroButton[]
  dark: boolean
}

const renderBannerImage = (image: HeroImage) => {
  if (image && image.url) {
    return {
      marginTop: '-98px',
      backgroundImage: `linear-gradient(108deg, #3e5151 0%,#decba4 100%), url(${
        image.url
      })`
    }
  }
  return {
    marginTop: '-98px'
  }
}

export const Hero = ({
  title,
  abstract,
  image,
  sections,
  buttons,
  dark
}: HeroProps) => (
  <section
    className={css`
      ${styles.header};
      ${bgBlend};
    `}
    style={renderBannerImage(image)}
  >
    <div className={styles.banner}>
      <JumpLinks sections={sections} />
      <div className={dark ? styles.textDark : styles.text}>
        <h1 className={styles.heading}>{title.substring(0, 18)}</h1>

        {buttons && (
          <div
            className={css`
              ${buttonWrapper};
              ${buttonWrapper1};
            `}
          >
            {buttons.map(button => (
              <SVGButton label={button.label} link={button.link} />
            ))}
          </div>
        )}

        {abstract && <p>{abstract}</p>}
      </div>
    </div>
  </section>
)
