import TestRenderer from 'react-test-renderer'
import React from 'react'

import { Hero } from '..'

import mocks from '../__mocks__/Hero.mock'

const sections = [
  {
    number: '01',
    title: 'Ratings'
  },
  {
    number: '02',
    title: 'Research'
  },
  {
    number: '03',
    title: 'Video'
  }
]

describe('Hero', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(
      <Hero {...mocks[0]} sections={sections} />
    ).toJSON()
    expect(tree).toMatchSnapshot()
  })
})
