import React from 'react'

import ReactPlayerLoader from '@brightcove/react-player-loader'

export type VideoSuccess = {
  ref: (success: VideoSuccess) => void
}

export type VideoProps = {
  onSuccess: (success: VideoSuccess) => void
}

// TODO: replace hardcoded accountId
export const Video = ({ onSuccess }: VideoProps) => (
  <ReactPlayerLoader
    attrs={{ className: 'react-player-loader' }}
    accountId="1301119679001"
    playerId="ryVPzahIb"
    onSuccess={onSuccess}
    embedOptions={{
      responsive: true
    }}
  />
)
