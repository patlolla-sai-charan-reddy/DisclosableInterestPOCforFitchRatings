import { css } from 'emotion'

import { c3, mpb1, mpb2 } from '../GlobalStyles'

export const player = css`
  background: ${c3};
`

export const video = css`
  position: relative;
  display: block;

  width: 100%;
  height: 100%;
  max-width: 100%;
`

export const videoWrapper = css`
  height: 0;
  padding-bottom: 56.25%;
`

export const teasers = css`
  width: 100%;
  padding: 0 ${mpb1};
  background: #fbfbfb;
`

export const teasersWrapper = css`
  width: auto;
  padding: ${mpb2} ${mpb1};
  white-space: nowrap;
  overflow-x: scroll;
`
