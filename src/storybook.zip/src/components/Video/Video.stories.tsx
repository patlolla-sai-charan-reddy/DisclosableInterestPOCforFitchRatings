import React from 'react'
import { storiesOf } from '@storybook/react'
import { Query } from 'react-apollo'
import gql from 'graphql-tag'

import { VideoThumb, Video, Videos } from '.'

const GET_VIDEOS_QUERY = gql`
  {
    videoCollection {
      items {
        embedId
        abstract
        slug
        title
        image {
          url
        }
      }
    }
  }
`

storiesOf('Atoms/VideoThumb', module).add('default', () => (
  <Query query={GET_VIDEOS_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { items } = data.videoCollection
      return <VideoThumb {...items[0]} />
    }}
  </Query>
))

storiesOf('Atoms/Video', module).add('default', () => (
  <Query query={GET_VIDEOS_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { items } = data.videoCollection
      return <Video {...items[0]} onSuccess={() => {}} />
    }}
  </Query>
))

storiesOf('Molecules/Videos', module).add('default', () => (
  <Query query={GET_VIDEOS_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { items } = data.videoCollection
      return <Videos items={items.slice(0, 4)} />
    }}
  </Query>
))
