import React from 'react'

import * as styles from './VideoThumb.style'

export type VideoThumbImage = {
  url: string
  title: string
}

export type VideoThumbProps = {
  embedId: string
  image: VideoThumbImage
  handleClick: (embedId: string) => void
}

export const VideoThumb = ({
  embedId,
  image,
  handleClick
}: VideoThumbProps) => (
  <article className={styles.teaser}>
    <div className={styles.imageWrapper}>
      <button
        type="button"
        className={styles.button}
        onClick={() => handleClick(embedId)}
        onKeyUp={() => handleClick(embedId)}
      >
        <img data-video-id="5990598544001" src={image.url} alt={image.title} />
      </button>
    </div>
    <h4 className={styles.title}>{image.title}</h4>
  </article>
)
