import { css } from 'emotion'
import { c3, c9, mpb1, mpb2 } from '../GlobalStyles'

export const teaser = css`
  position: relative;
  width: 16.188rem;
  padding: 0 0.625rem;
  display: inline-block;

  &:hover {
    cursor: pointer;
  }
`

export const title = css`
  position: absolute;
  bottom: ${mpb2};
  left: ${mpb2};
  width: calc(100% - 3rem);
  margin: 0;
  white-space: initial;
  color: ${c9};
  z-index: 10;
`

export const imageWrapper = css`
  width: 100%;

  img {
    width: 100%;
    max-width: 100%;
    height: auto;
    margin-bottom: ${mpb1};
    display: block;
  }
`

export const player = css`
  background: ${c3};
`

export const button = css`
  background: none;
  border: none;
  cursor: pointer;
`
