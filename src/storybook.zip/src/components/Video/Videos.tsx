import React from 'react'
import { css } from 'emotion'

import uniqid from 'uniqid'

import { VideoThumb } from './VideoThumb'
import { Video } from './Video'
import * as styles from './Videos.style'
import {
  content,
  content1,
  heading3,
  headingNo,
  section,
  wrapper1,
  wrapper2
} from '../GlobalStyles'

interface PlayerState {
  player: any
}

export type VideosImage = {
  url: string
  title: string
}

export type VideosItem = {
  embedId: string
  abstract: string
  slug: string
  title: string
  image: VideosImage
}

export type VideosProps = {
  items: VideosItem[]
}

export class Videos extends React.Component<VideosProps, PlayerState> {
  state = {
    player: {}
  }

  onSuccess = (success: any) => {
    const player = success.ref
    this.setState({ player })
    const { items } = this.props

    player.catalog.getVideo(
      items[0].embedId,
      (error: object, video: object) => {
        player.catalog.load(video)
      }
    )
  }

  handleClick = (embedId: string) => {
    const { player }: PlayerState = this.state
    player.catalog.getVideo(embedId, (error: object, video: object) => {
      player.catalog.load(video)
      player.play()
    })
  }

  render() {
    const { items } = this.props
    return (
      <section className={section}>
        <div className={wrapper1}>
          <h2
            className={css`
              ${heading3};
              ${content};
            `}
          >
            <span className={headingNo}>03</span>
            Videos
          </h2>
        </div>
        <div className={styles.player}>
          <div
            className={css`
              ${wrapper2};
              ${content};
            `}
          >
            <div className={styles.video}>
              <div className={styles.videoWrapper}>
                <Video onSuccess={this.onSuccess} />
              </div>
            </div>
          </div>
        </div>

        <div className={styles.teasers}>
          <div
            className={css`
              ${content1};
              ${wrapper2};
              ${styles.teasersWrapper};
            `}
          >
            {items.map(item => (
              <VideoThumb
                handleClick={this.handleClick}
                {...item}
                key={uniqid()}
              />
            ))}
          </div>
        </div>
      </section>
    )
  }
}
