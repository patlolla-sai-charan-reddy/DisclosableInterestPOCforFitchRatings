import TestRenderer from 'react-test-renderer'
import React from 'react'

import { IssuerList, IssuerLists } from '..'

import mocks from '../__mocks__/IssuerList.mock'

describe('IssuerList', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<IssuerList {...mocks[0]} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})

describe('IssuerLists', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<IssuerLists items={mocks} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})
