export default [
  {
    title: 'test',
    dbDocId: 10058819,
    fcReportType: 'Rating Action Commentary'
  },
  {
    title: 'test',
    dbDocId: 10051801,
    fcReportType: 'Rating Action Commentary'
  },
  {
    title: 'test',
    dbDocId: 10051753,
    fcReportType: 'Rating Action Commentary'
  }
]
