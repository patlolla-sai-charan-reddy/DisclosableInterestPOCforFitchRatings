import React from 'react'

import * as styles from './IssuerList.style'

export type IssuerListProps = {
  title: string
  issuerId: string
}

export const IssuerList = ({ title, issuerId }: IssuerListProps) => (
  <li>
    <a href={`/${issuerId}`} className={styles.listItem}>
      {title}
    </a>
  </li>
)
