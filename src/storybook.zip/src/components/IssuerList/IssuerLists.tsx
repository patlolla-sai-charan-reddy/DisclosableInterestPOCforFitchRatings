import React from 'react'
import uniqid from 'uniqid'

import { IssuerList } from './IssuerList'
import { asideBlock, heading5, listStyle2 } from '../GlobalStyles'

export type IssuerListsItem = {
  title: string
  issuerId: string
}

export type IssuerListsProps = {
  items: IssuerListsItem[]
}

export const IssuerLists = ({ items }: IssuerListsProps) => (
  <div className={asideBlock}>
    <h3 className={heading5}>Issuers</h3>
    <ul className={listStyle2}>
      {items && items.map(item => <IssuerList {...item} key={uniqid()} />)}
    </ul>
  </div>
)
