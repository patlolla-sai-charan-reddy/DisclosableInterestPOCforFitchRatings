import React from 'react'
import { storiesOf } from '@storybook/react'
import { Query } from 'react-apollo'
import gql from 'graphql-tag'

import { IssuerList, IssuerLists } from '.'

const GET_RATING_QUERY = gql`
  {
    getRAC(id: 1000) {
      issuers {
        title
        issuerId
      }
    }
  }
`
storiesOf('Atoms/IssuerList', module).add('default', () => (
  <Query query={GET_RATING_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      if (!data.getRAC.issuers) return <p>No data</p>
      const { issuers } = data.getRAC

      return <IssuerList {...issuers[0]} />
    }}
  </Query>
))

storiesOf('Molecules/IssuerLists', module).add('default', () => (
  <Query query={GET_RATING_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      if (!data.getRAC.issuers) return <p>No data</p>
      const { issuers } = data.getRAC

      return <IssuerLists items={issuers} />
    }}
  </Query>
))
