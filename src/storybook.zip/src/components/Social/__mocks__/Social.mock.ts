export default [
  {
    name: 'LEAD PARAGRAPH',
    header: null,
    content:
      "Fitch Ratings has assigned&nbsp;the following rating to the Tender Option Bond Series Trust&nbsp;Series 2016-ZM0318:<br/><br/>--Custodial Receipts, Series CE-2019-004 'AA-'/Outlook Stable.<br/><br/>Fitch has upgraded the following ratings:<br/><br/>--Puttable Floating Rate Receipts, Series 2016-ZM0318 to 'AA-'/'F1+'/Outlook Stable from 'BBB+'/'F2'/Outlook Stable;&nbsp;<br/>--Inverse Floating Receipts, Series 2016-ZM0318 'AA-'/Outlook Stable from 'BBB+'/Outlook Stable.<br/><br/>",
    subHeader: null,
    showHeader: false
  },
  {
    name: 'SECURITY',
    header: null,
    content: '',
    subHeader: null,
    showHeader: false
  },
  {
    name: 'KEY RATING DRIVERS',
    header: null,
    content:
      "The long-term 'AA-'/Outlook Stable ratings assigned to the series 2016 -ZM0318 Floater and Residual Receipts and the Series CE-2019-004 Custodial Receipts are based on the higher of the rating that Fitch has assigned to the Colorado Health Facilities Authority Revenue Bonds (Catholic Health Initiatives) Series 2009A (rated BBB+/Stable) deposited with the custodian and the irrevocable standby letter of credit (LOC) issued by Bank of America (BOA, rated AA-/F1+/Stable), which has a stated expiration date of Jan. 15, 2020, unless such date is extended or earlier terminated. The assignment of the 'AA-'/Outlook Stable rating to the Custodial Receipts CE-2019-004 is based on the credit enhancement provided by Bank of America. The upgrade of the long-term rating assigned to the series 2016-ZM0318 Floater and Inverse Floaters to 'AA-'/Outlook Stable from 'BBB+'/Outlook Stable is based on the rating that Fitch has assigned to the Custodial Receipts deposited in the trust.<br/><br/><br/>The upgrade of the short-term rating assigned to the series 2016-ZM0318 Floater Receipts to'F1+' from 'F2'is based on the obligation of BOA to pay purchase price of tendered floaters as liquidity provider. The liquidity facility has a stated expiration date of July 15, 2019, unless such date is extended or earlier terminated.<br/><br/>",
    subHeader: null,
    showHeader: true
  }
]
