import React from 'react'

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {
  faFacebookF,
  faTwitter,
  faLinkedin
} from '@fortawesome/free-brands-svg-icons'
import { faEnvelope } from '@fortawesome/free-solid-svg-icons'

import * as styles from './Social.style'

export default () => (
  <div className={styles.socialIcons}>
    <a
      href="https://www.facebook.com/share.php?u=http://www.fitchsolutions.com/country-risk-sovereigns/greeces-ratification-marks-historic-moment-macedonia-while-denting-government-support-28-01-2019&amp;title=Greece's Ratification Marks Historic Moment For Macedonia While Denting Government Support"
      target="facebook"
    >
      <i className={styles.facebook}>
        <FontAwesomeIcon icon={faFacebookF} />
      </i>
    </a>
    <a
      href="https://twitter.com/intent/tweet?url=http://www.fitchsolutions.com/country-risk-sovereigns/greeces-ratification-marks-historic-moment-macedonia-while-denting-government-support-28-01-2019&amp;status=Greece's Ratification Marks Historic Moment For Macedonia While Denting Government Support+http://www.fitchsolutions.com/country-risk-sovereigns/greeces-ratification-marks-historic-moment-macedonia-while-denting-government-support-28-01-2019"
      target="twitter"
    >
      <i className={styles.twitter}>
        <FontAwesomeIcon icon={faTwitter} />
      </i>
    </a>
    <a
      href="https://www.linkedin.com/shareArticle?mini=true&amp;url=http://www.fitchsolutions.com/country-risk-sovereigns/greeces-ratification-marks-historic-moment-macedonia-while-denting-government-support-28-01-2019&amp;title=Greece's Ratification Marks Historic Moment For Macedonia While Denting Government Support&amp;source=http://www.fitchsolutions.com/country-risk-sovereigns/greeces-ratification-marks-historic-moment-macedonia-while-denting-government-support-28-01-2019"
      target="linkedin"
    >
      <i className={styles.linkedin}>
        <FontAwesomeIcon icon={faLinkedin} />
      </i>
    </a>
    <a href="mailto:?subject=Greece's Ratification Marks Historic Moment For Macedonia While Denting Government Support&amp;body=Check out this site http://www.fitchsolutions.com/country-risk-sovereigns/greeces-ratification-marks-historic-moment-macedonia-while-denting-government-support-28-01-2019">
      <i className={styles.envelope}>
        <FontAwesomeIcon icon={faEnvelope} />
      </i>
    </a>
  </div>
)
