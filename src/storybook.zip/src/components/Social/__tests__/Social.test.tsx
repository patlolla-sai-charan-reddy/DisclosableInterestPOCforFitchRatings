import TestRenderer from 'react-test-renderer'
import React from 'react'

import { Social } from '..'

describe('Social', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<Social />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})
