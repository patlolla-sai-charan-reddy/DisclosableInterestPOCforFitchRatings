import { css } from 'emotion'

import { c2, mpb2, mq5 } from '../GlobalStyles'

export const socialIcons = css`
  i {
    margin-bottom: ${mpb2};
    font-size: 2.25rem;
    cursor: pointer;
    transition: color 350ms ease;
    display: block;
    text-align: center;

    color: ${c2};

    ${mq5} {
      width: 25%;
      float: left;
    }
  }
  ${mq5} {
    width: 100%;
    margin: ${mpb2} 0;
    float: left;
  }
`

export const facebook = css`
  &:hover,
  &:focus {
    color: #3b5998;
  }
`
export const twitter = css`
  &:hover,
  &:focus {
    color: #1ca1f3;
  }
`

export const linkedin = css`
  &:hover,
  &:focus {
    color: #4875b4;
  }
`
export const envelope = css`
  &:hover,
  &:focus {
    color: #ffd500;
  }
`
