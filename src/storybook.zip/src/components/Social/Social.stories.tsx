import React from 'react'
import { storiesOf } from '@storybook/react'

import { Social } from '.'

storiesOf('Atoms/Social', module).add('default', () => <Social />)
