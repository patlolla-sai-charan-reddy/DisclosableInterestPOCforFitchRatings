import React from 'react'
import { storiesOf } from '@storybook/react'
import { Query } from 'react-apollo'
import gql from 'graphql-tag'

import { Rating, RatingRenderLinkProps, Ratings } from '.'

const GET_RATINGS_QUERY = gql`
  {
    getRACs(sector: "") {
      rows {
        dbDocId
        title
        publishedDate
      }
    }
  }
`

storiesOf('Atoms/Rating', module)
  .add('default', () => (
    <Query query={GET_RATINGS_QUERY}>
      {({ loading, error, data }) => {
        if (loading) return <p>Loading...</p>
        if (error) return <p>Error :(</p>
        const { rows } = data.getRACs

        return <Rating {...rows[0]} />
      }}
    </Query>
  ))
  .add('custom render link', () => {
    const customRenderLink = ({ dbDocId, title }: RatingRenderLinkProps) => (
      <a href={`#${dbDocId}`}>
        Custom:
        {title}
      </a>
    )

    return (
      <Query query={GET_RATINGS_QUERY}>
        {({ loading, error, data }) => {
          if (loading) return <p>Loading...</p>
          if (error) return <p>Error :(</p>
          const { rows } = data.getRACs
          const props = {
            ...rows[0],
            renderLink: customRenderLink
          }

          return <Rating {...props} />
        }}
      </Query>
    )
  })

storiesOf('Molecules/Ratings', module).add('default', () => (
  <Query query={GET_RATINGS_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { rows } = data.getRACs

      return <Ratings items={rows.slice(0, 3)} />
    }}
  </Query>
))
