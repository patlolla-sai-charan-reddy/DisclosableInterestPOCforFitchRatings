import { css } from 'emotion'
import { c5, c9, headingSub, mpb2 } from '../GlobalStyles'

export const highlight = css`
  height: 100%;
  padding: 2.25rem ${mpb2};
  background-color: ${c5};
  color: ${c9};
  a {
    color: ${c9};
  }
`

export const subHeading = css`
  ${headingSub}
  color: inherit;
`
