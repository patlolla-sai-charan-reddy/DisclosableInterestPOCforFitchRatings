export default [
  {
    title: 'RAC with translated research reports',
    publishedDate: '2019-01-17'
  },
  {
    title: 'Colombia Mexico Chile RAC research',
    publishedDate: '2019-01-16'
  },
  {
    title: 'RACM ONLY ISSUE RATING CHANGE+RESEARCH',
    publishedDate: '2019-01-15'
  },
  {
    title: 'RAC ENGLISH MEXICO AND COSTA RICA',
    publishedDate: '2019-01-15'
  },
  {
    title: 'RACM +Research NEW ISSUE rrrrrrrrr',
    publishedDate: '2019-01-15'
  },
  {
    title: 'SPANISH CHILE AND QATAR WITH ASSOCIATED RESEARCH',
    publishedDate: '2019-01-15'
  },
  {
    title: 'JAPANESE RACM with associated report to withdraw and re- publish',
    publishedDate: '2019-01-14'
  },
  {
    title: 'RAC with associated research Issuer and issue rating change',
    publishedDate: '2019-01-14'
  },
  {
    title: 'RAC ESG sov',
    publishedDate: '2019-01-09'
  },
  {
    title: 'QA',
    publishedDate: '2019-01-04'
  },
  {
    title: 'RACM ONLY R42.1',
    publishedDate: '2019-01-03'
  }
]
