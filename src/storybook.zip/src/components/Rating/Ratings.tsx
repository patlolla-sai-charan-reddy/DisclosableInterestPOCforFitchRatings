import React from 'react'
import { css } from 'emotion'
import uniqid from 'uniqid'

import { Rating, RatingProps } from './Rating'

import {
  columnThree,
  content,
  heading3,
  headingNo,
  section,
  wrapper1
} from '../GlobalStyles'

export type RatingsProps = {
  items: RatingProps[]
}

export const Ratings = ({ items }: RatingsProps) => (
  <section className={section}>
    <div className={wrapper1}>
      <h2
        className={css`
          ${heading3};
          ${content};
        `}
      >
        <span className={headingNo}>01</span>
        Ratings
      </h2>

      <div className={columnThree}>
        {items.map(item => (
          <Rating {...item} key={uniqid()} />
        ))}
      </div>
    </div>
  </section>
)
