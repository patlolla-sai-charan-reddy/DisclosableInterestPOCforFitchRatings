import TestRenderer from 'react-test-renderer'
import React from 'react'

import { Rating, Ratings } from '..'

import mocks from '../__mocks__/Rating.mock'

describe('Rating', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<Rating {...mocks[0]} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})

describe('Ratings', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<Ratings items={mocks} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})
