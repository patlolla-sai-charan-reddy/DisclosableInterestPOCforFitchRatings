import React, { ComponentType } from 'react'
import { FormattedDate, IntlProvider } from 'react-intl'

import * as styles from './Rating.style'
import { columnThreeColumn, heading4 } from '../GlobalStyles'

export type RatingProps = {
  dbDocId: number
  title: string
  publishedDate: string
  renderLink?: ComponentType<RatingRenderLinkProps>
}

export type RatingRenderLinkProps = Partial<RatingProps>

const renderLinkDefault = ({ dbDocId, title = '' }: RatingRenderLinkProps) => (
  <a href={`${dbDocId}`}>{title.slice(0, 50)}</a>
)

export const Rating = (props: RatingProps) => {
  const { publishedDate, renderLink: Link = renderLinkDefault } = props

  return (
    <div className={columnThreeColumn}>
      <article className={styles.highlight}>
        <div className={styles.subHeading}>
          <IntlProvider locale="en-GB">
            <FormattedDate
              value={new Date(publishedDate)}
              day="numeric"
              month="short"
              year="numeric"
            />
          </IntlProvider>
        </div>
        <h3 className={heading4}>
          <Link {...props} />
        </h3>
      </article>
    </div>
  )
}
