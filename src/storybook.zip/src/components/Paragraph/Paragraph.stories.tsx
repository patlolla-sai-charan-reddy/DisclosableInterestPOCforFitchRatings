import React from 'react'
import { storiesOf } from '@storybook/react'
import { Query } from 'react-apollo'
import gql from 'graphql-tag'

import { Paragraph, Paragraphs } from '.'

const GET_RAC_QUERY = gql`
  {
    getRAC(id: 1000) {
      paragraphs {
        name
        header
        subHeader
        showHeader
        content
      }
    }
  }
`

storiesOf('Atoms/Paragraph', module).add('default', () => (
  <Query query={GET_RAC_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { paragraphs } = data.getRAC

      return <Paragraph {...paragraphs[0]} />
    }}
  </Query>
))

storiesOf('Molecules/Paragraphs', module).add('default', () => (
  <Query query={GET_RAC_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { paragraphs } = data.getRAC

      return <Paragraphs items={paragraphs} />
    }}
  </Query>
))
