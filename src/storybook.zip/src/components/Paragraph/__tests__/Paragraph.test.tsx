import TestRenderer from 'react-test-renderer'
import React from 'react'

import { Paragraph, Paragraphs } from '..'

import mocks from '../__mocks__/Paragraph.mock'

describe('Paragraph', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<Paragraph {...mocks[0]} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})

describe('Paragraphs', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<Paragraphs items={mocks} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})
