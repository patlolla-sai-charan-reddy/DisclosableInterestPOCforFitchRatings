import React from 'react'
import uniqid from 'uniqid'

import { Paragraph } from './Paragraph'

export type ParagraphsItem = {
  showHeader: boolean
  header: string
  subHeader: string
  content: string
}

export type ParagraphsProps = {
  items: ParagraphsItem[]
}

export const Paragraphs = ({ items }: ParagraphsProps) => (
  <div>
    {items.map(item => (
      <Paragraph {...item} key={uniqid()} />
    ))}
  </div>
)
