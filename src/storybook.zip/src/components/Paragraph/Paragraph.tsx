import React from 'react'

export type ParagraphProps = {
  showHeader: boolean
  header: string
  subHeader: string
  content: string
}

export const Paragraph = ({
  showHeader,
  header,
  subHeader,
  content
}: ParagraphProps) => (
  <div>
    {showHeader && <h2>{header}</h2>}
    {subHeader && <h3>{subHeader}</h3>}
    {/* eslint-disable-next-line react/no-danger */}
    <p dangerouslySetInnerHTML={{ __html: content }} />
  </div>
)
