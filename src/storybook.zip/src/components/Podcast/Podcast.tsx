import React from 'react'
import ReactPlayer from 'react-player'

import { columnThreeColumn } from '../GlobalStyles'

export type PodcastProps = {
  embedId: string
}

export const Podcast = ({ embedId }: PodcastProps) => (
  <div className={columnThreeColumn}>
    <ReactPlayer url={embedId} width="100%" height="238px" />
  </div>
)
