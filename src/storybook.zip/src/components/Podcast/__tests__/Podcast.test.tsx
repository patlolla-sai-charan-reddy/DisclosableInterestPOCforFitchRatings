import TestRenderer from 'react-test-renderer'
import React from 'react'

import { Podcast, Podcasts } from '..'

import mocks from '../__mocks__/Podcast.mock'

describe('Podcast', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<Podcast {...mocks[0]} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})

describe('Podcasts', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<Podcasts items={mocks} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})
