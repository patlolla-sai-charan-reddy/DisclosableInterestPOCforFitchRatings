export default [
  {
    embedId:
      'https://soundcloud.com/user-125131884/social-housing-tc-english-replay',
    title: 'Seamless Chips Backing Up Azure Principal Payment Concrete',
    slug:
      '/podcasts/seamless-chips-backing-up-azure-principal-payment-concrete',
    abstract:
      'Placeat iusto omnis nostrum soluta. Sit qui exercitationem deleniti nihil est enim in. Reprehenderit libero doloremque aspernatur. Commodi quidem sit saepe nisi quis. Quasi non quia sunt dolor sunt eaque in.\n \rAlias sunt architecto sint quos voluptatem velit dolores. Nisi voluptas debitis blanditiis repudiandae libero incidunt natus. Voluptates quibusdam blanditiis qui. Mollitia consequatur aperiam perspiciatis dolores.'
  },
  {
    embedId: 'https://soundcloud.com/user-125131884/social-housing-french-tc',
    title:
      'Iranian Rial Gorgeous Garden Principal Assurance Concept Payment Invoice',
    slug:
      '/podcasts/iranian-rial-gorgeous-garden-principal-assurance-concept-payment-invoice',
    abstract:
      'Quibusdam totam vitae. Et quidem explicabo aut dolorem aliquid cum officiis. Neque hic deserunt aliquam officia excepturi impedit natus fugiat incidunt.\n \rPerspiciatis earum voluptatem accusantium qui sunt. Minus unde qui. Necessitatibus possimus dolores ut.\n \rDolorem quod dicta. Qui earum voluptas consequatur commodi ullam. Maiores temporibus blanditiis voluptatem. Voluptates occaecati adipisci.'
  },
  {
    embedId:
      'https://soundcloud.com/user-125131884/gig-emea-transportation-airports-replay',
    title: 'Specialist Marketing Industrial Overriding Bedfordshire Panel',
    slug:
      '/podcasts/specialist-marketing-industrial-overriding-bedfordshire-panel',
    abstract:
      'Blanditiis consequatur corrupti nulla iste facilis impedit dolorem eum fuga. Iure et accusantium incidunt praesentium est dolorem. Voluptatem error consectetur qui sunt ullam corrupti autem nostrum.'
  }
]
