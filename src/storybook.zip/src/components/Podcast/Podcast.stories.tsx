import React from 'react'
import { storiesOf } from '@storybook/react'
import { Query } from 'react-apollo'
import gql from 'graphql-tag'

import { Podcast, Podcasts } from '.'

const GET_PODCASTS_QUERY = gql`
  {
    podcastCollection {
      items {
        embedId
        title
        slug
        abstract
      }
    }
  }
`

storiesOf('Atoms/Podcast', module).add('default', () => (
  <Query query={GET_PODCASTS_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { items } = data.podcastCollection

      return <Podcast {...items[0]} />
    }}
  </Query>
))

storiesOf('Molecules/Podcasts', module).add('default', () => (
  <Query query={GET_PODCASTS_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { items } = data.podcastCollection

      return <Podcasts items={items.slice(0, 3)} />
    }}
  </Query>
))
