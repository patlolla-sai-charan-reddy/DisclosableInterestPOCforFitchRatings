import React from 'react'
import { css } from 'emotion'
import uniqid from 'uniqid'

import { Podcast } from './Podcast'

import {
  columnThree,
  content,
  heading3,
  headingNo,
  section,
  wrapper1
} from '../GlobalStyles'

export type PodcastsItem = {
  embedId: string
}

export type PodcastsProps = {
  items: PodcastsItem[]
}

export const Podcasts = ({ items }: PodcastsProps) => (
  <section className={section}>
    <div className={wrapper1}>
      <h2
        className={css`
          ${heading3};
          ${content};
        `}
      >
        <span className={headingNo}>05</span>
        Podcasts
      </h2>

      <div className={columnThree}>
        {items.map(item => (
          <Podcast {...item} key={uniqid()} />
        ))}
      </div>
    </div>
  </section>
)
