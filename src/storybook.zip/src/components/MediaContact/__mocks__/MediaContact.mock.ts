export default [
  {
    email: 'sandro.scenga@thefitchgroup.com',
    phone: '+1 212 908 0278',
    lastName: 'Scenga',
    firstName: 'Sandro',
    location: 'New York'
  }
]
