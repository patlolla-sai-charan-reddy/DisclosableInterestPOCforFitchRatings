import React from 'react'
import { storiesOf } from '@storybook/react'
import { Query } from 'react-apollo'
import gql from 'graphql-tag'

import { MediaContact, MediaContacts } from '.'

const GET_RATING_QUERY = gql`
  {
    getRAC(id: 1000) {
      mediaContacts {
        firstName
        lastName
        email
        phone
        location
      }
    }
  }
`

storiesOf('Atoms/MediaContact', module).add('default', () => (
  <Query query={GET_RATING_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { mediaContacts } = data.getRAC

      return <MediaContact {...mediaContacts[0]} />
    }}
  </Query>
))

storiesOf('Molecules/MediaContacts', module).add('default', () => (
  <Query query={GET_RATING_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { mediaContacts } = data.getRAC

      return <MediaContacts items={mediaContacts} />
    }}
  </Query>
))
