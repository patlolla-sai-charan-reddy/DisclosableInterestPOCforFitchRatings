import React from 'react'

export type MediaContactProps = {
  firstName: string
  lastName: string
  email: string
  phone: string
  location: string
}

export const MediaContact = ({
  firstName,
  lastName,
  email,
  phone,
  location
}: MediaContactProps) => (
  <p>
    <strong>{`${firstName} ${lastName}`}</strong>
    <br />
    {location}
    <br />
    {phone}
    <br />
    {email}
  </p>
)
