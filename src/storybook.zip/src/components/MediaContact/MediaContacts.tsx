import React from 'react'
import uniqid from 'uniqid'

import { MediaContact } from './MediaContact'
import { block, heading5 } from '../GlobalStyles'

export type MediaContactsItem = {
  firstName: string
  lastName: string
  email: string
  phone: string
  location: string
}

export type MediaContactsProps = {
  items: MediaContactsItem[]
}

export const MediaContacts = ({ items }: MediaContactsProps) => (
  <div className={block}>
    <h2 className={heading5}>Media Contact</h2>
    {items.map(item => (
      <MediaContact {...item} key={uniqid()} />
    ))}
  </div>
)
