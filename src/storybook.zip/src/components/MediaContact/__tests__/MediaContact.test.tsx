import TestRenderer from 'react-test-renderer'
import React from 'react'

import { MediaContact, MediaContacts } from '..'

import mocks from '../__mocks__/MediaContact.mock'

describe('MediaContact', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<MediaContact {...mocks[0]} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})

describe('MediaContacts', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<MediaContacts items={mocks} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})
