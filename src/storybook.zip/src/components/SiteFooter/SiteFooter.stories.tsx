import React from 'react'
import { storiesOf } from '@storybook/react'

import { SiteFooter } from '.'

storiesOf('Atoms/SiteFooter', module).add('default', () => <SiteFooter />)
