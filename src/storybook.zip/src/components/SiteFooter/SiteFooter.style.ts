import { css } from 'emotion'
import { c2, c3, c9, fs2, mpb1, mpb2, mpb3, mq5 } from '../GlobalStyles'

export const footer = css`
  font-size: ${fs2};
  color: ${c9};
`

export const links = css`
  padding: ${mpb3} 0;
  background: ${c3};

  li {
    margin-bottom: 0.375rem;
    padding-right: ${mpb1};
  }

  a {
    color: #aaaaaa;

    &:hover,
    &:focus {
      color: #d2d2d2;
    }
  }
`

export const legal = css`
  padding: ${mpb2} 0;
  background: ${c2};

  li {
    padding: 0 0.375rem;
    display: inline-block;
  }
`

export const footerColumn = css`
  margin-bottom: 0;

  ${mq5} {
    width: 100% !important;
  }
`

export const column2 = css`
  text-align: right;
`

export const list = css`
  margin: 0px;
  padding: 0px;
  list-style-image: none;
  list-style-type: none;
`
