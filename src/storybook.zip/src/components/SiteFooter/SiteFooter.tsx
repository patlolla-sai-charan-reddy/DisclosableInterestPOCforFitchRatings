import React from 'react'
import { css } from 'emotion'

import {
  heading5,
  wrapper1,
  content,
  column,
  columnGrow,
  columnGrowColumn,
  columnMergeA,
  columnTwo,
  columnTwo21,
  footer
} from '../GlobalStyles'
import * as styles from './SiteFooter.style'

export default () => (
  <footer
    className={css`
      ${styles.footer};
      ${footer};
    `}
  >
    <section className={styles.links}>
      <div
        className={css`
          ${wrapper1};
          ${content};
        `}
      >
        <h4 className={heading5}>Fitch Ratings</h4>
        <div
          className={css`
            ${columnGrow};
            ${columnMergeA};
          `}
        >
          <div
            className={css`
              ${column};
              ${columnGrowColumn};
              ${columnMergeA};
              ${styles.footerColumn};
            `}
          >
            <ul className={styles.list}>
              <li>
                <a href="https://www.fitchratings.com/ethics">
                  Code of Conduct &amp; Ethics
                </a>
              </li>
            </ul>
          </div>
          <div
            className={css`
              ${column};
              ${columnGrowColumn};
              ${columnMergeA};
              ${styles.footerColumn};
            `}
          >
            <ul>
              <li>
                <a href="https://www.fitchratings.com/criteria">Criteria</a>
              </li>
            </ul>
          </div>
          <div
            className={css`
              ${column};
              ${columnGrowColumn};
              ${columnMergeA};
              ${styles.footerColumn};
            `}
          >
            <ul>
              <li>
                <a href="https://www.fitchratings.com/regulatory">
                  Regulatory Affairs
                </a>
              </li>
            </ul>
          </div>
          <div
            className={css`
              ${column};
              ${columnGrowColumn};
              ${columnMergeA};
              ${styles.footerColumn};
            `}
          >
            <ul>
              <li>
                <a href="https://www.fitchratings.com/about/releasenotes">
                  Release Notes
                </a>
              </li>
            </ul>
          </div>
          <div
            className={css`
              ${column};
              ${columnGrowColumn};
              ${columnMergeA};
              ${styles.footerColumn};
            `}
          >
            <ul>
              <li>
                <a href="https://www.fitchratings.com/definitions">
                  Understanding Credit Ratings
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.legal}>
      <div
        className={css`
          ${wrapper1};
          ${content};
        `}
      >
        <div
          className={css`
            ${columnMergeA};
            ${columnTwo21};
            ${columnTwo};
          `}
        >
          <div
            className={css`
              ${column};
              ${columnMergeA};
              ${styles.footerColumn};
            `}
          >
            <div className="block">
              <div>
                Copyright &copy; 2019 Fitch Ratings, Inc., Fitch Ratings, Inc.,
                Fitch Solutions Group, Inc. and their subsidiaries,{' '}
                <a href="https://www.thefitchgroup.com/site/policies">
                  Policies
                </a>{' '}
                |{' '}
                <span>
                  <a href="/#">
                    <span>Manage Cookies</span>
                  </a>
                </span>
              </div>
            </div>
          </div>
          <div
            className={css`
              ${column};
              ${columnMergeA};
              ${styles.footerColumn};
            `}
          >
            <div className="block">
              <div>
                <ul>
                  <li>
                    <a href="https://twitter.com/fitchratings" target="twitter">
                      <i className="fab fa-twitter" />
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.linkedin.com/company/fitch-ratings/"
                      target="linkedin"
                    >
                      <i className="fab fa-linkedin-in" />
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </footer>
)
