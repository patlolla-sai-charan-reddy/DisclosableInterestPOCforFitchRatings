import React from 'react'
import { storiesOf } from '@storybook/react'

import { Highlight, HighlightText, HighlightImage } from '.'

storiesOf('Atoms/HighlightText', module)
  .add('default', () => (
    <div style={{ marginTop: '5rem' }}>
      <HighlightText
        title="What we do and why we love it"
        abstract="Take a peek into Fitch Solutions and learn about our customer-centric approach to building products and solutions, and how we solve client problems through our research, technology and expertise."
      />
    </div>
  ))
  .add('with button', () => (
    <div style={{ marginTop: '7rem' }}>
      <HighlightText
        title="What we do and why we love it"
        abstract="Take a peek into Fitch Solutions and learn about our customer-centric approach to building products and solutions, and how we solve client problems through our research, technology and expertise."
        label="LEARN MORE"
        link="http://fitchratings.com"
      />
    </div>
  ))

storiesOf('Atoms/HighlightImage', module).add('default', () => (
  <HighlightImage
    url="https://your.fitchratings.com/rs/732-CKH-767/images/global-leveraged-finance-2.jpg"
    title="Fitch Ratings"
  />
))

storiesOf('Molecules/Highlight', module).add('default', () => (
  <Highlight
    label="LEARN MORE"
    title="What we do and why we love it"
    abstract="Take a peek into Fitch Solutions and learn about our customer-centric approach to building products and solutions, and how we solve client problems through our research, technology and expertise."
    link="http://fitchratings.com"
    image={{
      url:
        'https://your.fitchratings.com/rs/732-CKH-767/images/global-leveraged-finance-2.jpg',
      title: 'Fitch Ratings'
    }}
  />
))
