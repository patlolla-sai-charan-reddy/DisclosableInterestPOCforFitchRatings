import React from 'react'

import { imageWrapper } from '../GlobalStyles'

export type HighlightImageProps = {
  url: string
  title: string
}

export const HighlightImage = ({ url, title }: HighlightImageProps) => (
  <div className={imageWrapper}>
    <img src={url} alt={title} />
  </div>
)
