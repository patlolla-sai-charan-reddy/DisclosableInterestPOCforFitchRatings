import React from 'react'
import { css } from 'emotion'

import { button, button62, heading2, headingSub, va } from '../GlobalStyles'

export type HighlightTextProps = {
  title: string
  abstract: string
  link?: string
  label?: string
}

export const HighlightText = ({
  title,
  abstract,
  link,
  label
}: HighlightTextProps) => (
  <article className={va}>
    <div className={headingSub}>Video</div>
    <h2 className={heading2}>{title}</h2>
    <p>{abstract}</p>
    {link && (
      <a
        className={css`
          ${button};
          ${button62}
        `}
        href={link}
      >
        {label}
      </a>
    )}
  </article>
)
