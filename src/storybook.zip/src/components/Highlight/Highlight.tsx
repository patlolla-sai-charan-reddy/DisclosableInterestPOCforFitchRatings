import React from 'react'

import { HighlightImage, HighlightImageProps } from './HighlightImage'
import { HighlightText } from './HighlightText'
import { columnTwo, columnTwoColumn, section, wrapper1 } from '../GlobalStyles'

export type HighlightProps = {
  title: string
  abstract: string
  link: string
  label: string
  image: HighlightImageProps
}

export const Highlight = ({
  title,
  abstract,
  link,
  label,
  image
}: HighlightProps) => (
  <section className={section}>
    <div className={wrapper1}>
      <div className={columnTwo}>
        <div className={columnTwoColumn}>
          <HighlightText
            title={title}
            abstract={abstract}
            link={link}
            label={label}
          />
        </div>
        <div className={columnTwoColumn}>
          <HighlightImage {...image} />
        </div>
      </div>
    </div>
  </section>
)
