import React from 'react'
import uniqid from 'uniqid'

import { JumpLink } from './JumpLink'
import MouseLink from './MouseLink'
import * as styles from './JumpLinks.style'

export type JumpLinksSection = {
  number: string
  title: string
}

export type JumpLinksProps = {
  sections: JumpLinksSection[]
}

export const JumpLinks = ({ sections }: JumpLinksProps) => (
  <div className={styles.nav}>
    <div className={styles.links}>
      <ul className={styles.list}>
        {sections.map(section => (
          <JumpLink
            number={section.number}
            title={section.title}
            handleClick={e => e.preventDefault()}
            key={uniqid()}
          />
        ))}
      </ul>
    </div>
    <MouseLink />
  </div>
)
