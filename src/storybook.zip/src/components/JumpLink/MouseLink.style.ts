import { css } from 'emotion'

export const button = css`
  position: relative;
  bottom: 0;
  left: 100%;
  width: 7.5rem;
  height: 7.5rem;
  background: rgba(0, 0, 0, 0.6);
  background-blend-mode: multiply;
  cursor: pointer;
`

export const image = css`
  position: absolute;
  top: calc(50% - 1.25rem);
  left: calc(50% - 0.625rem);
  display: block;
`
