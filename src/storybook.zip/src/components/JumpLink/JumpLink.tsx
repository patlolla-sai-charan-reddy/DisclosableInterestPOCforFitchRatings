import React from 'react'

import * as styles from './JumpLink.style'

export type JumpLinkProps = {
  number: string
  title: string
  handleClick: (e: React.MouseEvent<HTMLElement>, n: string) => void
}

export const JumpLink = ({ number, title, handleClick }: JumpLinkProps) => (
  <li className={styles.listItem}>
    <a
      className="js-scroll"
      href="#section--0"
      onClick={e => handleClick(e, number)}
    >
      <span className={styles.number}>{number}</span>
      <br />
      <span>{title}</span>
    </a>
  </li>
)
