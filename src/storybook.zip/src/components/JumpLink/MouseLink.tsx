import React from 'react'

import * as styles from './MouseLink.style'

export default () => (
  <div className={styles.button}>
    <img
      alt="Click to scroll down"
      className={styles.image}
      src="https://your.fitchratings.com/rs/732-CKH-767/images/page-scroll.png"
    />
  </div>
)
