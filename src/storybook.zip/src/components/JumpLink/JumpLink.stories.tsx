import React from 'react'
import { storiesOf } from '@storybook/react'

import { MouseLink, JumpLink, JumpLinks, JumpLinksSection } from '.'

storiesOf('Atoms/JumpLink', module).add('default', () => (
  <ul>
    <JumpLink title="Ratings" number="01" handleClick={() => {}} />
  </ul>
))

const wrapperStyle = { height: '120px', width: '120px' }
storiesOf('Atoms/MouseLink', module).add('default', () => (
  <div style={wrapperStyle}>
    <MouseLink />
  </div>
))

const sections: JumpLinksSection[] = [
  {
    number: '01',
    title: 'Ratings'
  },
  {
    number: '02',
    title: 'Research'
  },
  {
    number: '03',
    title: 'Video'
  }
]

storiesOf('Molecules/JumpLinks', module).add('default', () => (
  <JumpLinks sections={sections} />
))
