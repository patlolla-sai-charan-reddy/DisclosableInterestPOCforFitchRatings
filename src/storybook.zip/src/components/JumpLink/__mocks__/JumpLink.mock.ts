export default [
  {
    number: '01',
    title: 'Ratings'
  },
  {
    number: '02',
    title: 'Research'
  },
  {
    number: '03',
    title: 'Video'
  }
]
