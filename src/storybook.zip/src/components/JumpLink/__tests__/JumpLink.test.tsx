import TestRenderer from 'react-test-renderer'
import React from 'react'

import { JumpLink, JumpLinks } from '..'

import mocks from '../__mocks__/JumpLink.mock'

describe('JumpLink', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(
      <JumpLink {...mocks[0]} handleClick={() => {}} />
    ).toJSON()
    expect(tree).toMatchSnapshot()
  })
})

describe('JumpLinks', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<JumpLinks sections={mocks} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})
