import { css } from 'emotion'
import { c4, c9, mpb2, mq2, mq3, mq5, va } from '../GlobalStyles'

export const nav = css`
  position: absolute;
  left: 0;
  bottom: 0;
  width: 100%;
  max-width: 58.25%;
  height: 7.5rem;
  background: ${c4};
  color: ${c9};
  z-index: 1;
  ${mq2} {
    max-width: calc(100% - 7.5rem);
  }
  ${mq3} {
    display: none;
  }
  ${mq5} {
    display: none;
  }
`

export const list = css`
  justify-content: left;
  display: flex;
`

export const links = css`
  width: 100%;
  max-width: 48.063rem;
  float: right;
  ${va}
  ${mq2} {
    max-width: 100%;
    padding: 0 ${mpb2};
    float: left;
  }
  ${mq3} {
    display: none;
  }
  ${mq5} {
    display: none;
  }
`
