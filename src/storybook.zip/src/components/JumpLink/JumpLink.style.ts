import { css } from 'emotion'
import { c4, c9, mpb2 } from '../GlobalStyles'

export const number = css`
  font-size: ${mpb2};
  font-weight: 900;
  border-bottom: 1px solid ${c9};
`

export const listItem = css`
  background: ${c4};
  color: ${c9};
  flex-grow: 1;
  a {
    color: ${c9};
  }
`
