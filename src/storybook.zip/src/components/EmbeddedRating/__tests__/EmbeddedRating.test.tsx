import TestRenderer from 'react-test-renderer'
import React from 'react'

import { EmbeddedRatings } from '..'

import mocks from '../__mocks__/EmbeddedRating.mock'

describe('EmbeddedRating', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<EmbeddedRatings rows={mocks} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})
