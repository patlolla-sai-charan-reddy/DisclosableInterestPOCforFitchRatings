import { css } from 'emotion'
import { mpb1 } from '../GlobalStyles/Variables'

export const row = css`
  border-bottom: 1px solid #dddddd;

  &:hover,
  &focus {
    td {
      background: #f5f5f5;
    }
  }
`

export const cell = css`
  padding: ${mpb1};
  text-align: left;
  vertical-align: top;

  white-space: nowrap;
`
