export default [
  {
    title:
      'Colorado Water Resources & Power Development Authority (CO) /Revolving Fund Revenues/1 LT',
    level: 2,
    typeAbbr: 'LT',
    typeDesc: 'Long Term Rating',
    ratingCode: 'AAA',
    watchOutlookCode: 'RO:Sta',
    ratingAction: 'Affirmed',
    recoveryRating: '',
    priorRatingCode: 'AAA',
    priorWatchOutlookCode: 'RO:Sta'
  },
  {
    title:
      'New York Power Authority (NY) /Power Supply Revenues - Subordinated Obligations/1 LT',
    level: 2,
    typeAbbr: 'LT',
    typeDesc: 'Long Term Rating',
    ratingCode: 'AA',
    watchOutlookCode: 'RO:Sta',
    ratingAction: 'Affirmed',
    recoveryRating: '',
    priorRatingCode: 'AA',
    priorWatchOutlookCode: 'RO:Sta'
  },
  {
    title: 'New York Power Authority (NY) /Power Supply Revs/1 LT',
    level: 2,
    typeAbbr: 'LT',
    typeDesc: 'Long Term Rating',
    ratingCode: 'AA',
    watchOutlookCode: 'RO:Sta',
    ratingAction: 'Affirmed',
    recoveryRating: '',
    priorRatingCode: 'AA',
    priorWatchOutlookCode: 'RO:Sta'
  },
  {
    title: 'New York Power Authority (NY) /Self-Liquidity/1 ST',
    level: 2,
    typeAbbr: 'ST',
    typeDesc: 'Short Term Rating',
    ratingCode: 'F1+',
    watchOutlookCode: '',
    ratingAction: 'Affirmed',
    recoveryRating: '',
    priorRatingCode: 'F1+',
    priorWatchOutlookCode: ''
  }
]
