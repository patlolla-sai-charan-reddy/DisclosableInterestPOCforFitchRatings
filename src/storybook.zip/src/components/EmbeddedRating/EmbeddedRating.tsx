import React from 'react'

import * as styles from './EmbeddedRating.style'

export type EmbeddedRatingProps = {
  title: string
  level: number
  typeAbbr: string
  typeDesc: string
  ratingCode: string
  watchOutlookCode: string
  ratingAction: string
  recoveryRating: string
  priorRatingCode: string
  priorWatchOutlookCode: string
}

export const EmbeddedRating = ({
  title,
  typeAbbr,
  ratingCode,
  ratingAction,
  priorRatingCode
}: EmbeddedRatingProps) => (
  <tr className={styles.row}>
    <td className={styles.cell}>{title}</td>
    <td className={styles.cell}>
      {typeAbbr}
      {'   '}
      {ratingCode}
      {'   '}
      {ratingAction}
    </td>
    <td className={styles.cell}>{priorRatingCode}</td>
  </tr>
)
