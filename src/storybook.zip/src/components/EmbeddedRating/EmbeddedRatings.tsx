import React from 'react'
import uniqid from 'uniqid'

import { EmbeddedRating } from './EmbeddedRating'
import * as styles from './EmbeddedRatings.style'

export type EmbeddedRatingsItem = {
  title: string
  level: number
  typeAbbr: string
  typeDesc: string
  ratingCode: string
  watchOutlookCode: string
  ratingAction: string
  recoveryRating: string
  priorRatingCode: string
  priorWatchOutlookCode: string
}

export type EmbeddedRatingsProps = {
  rows: EmbeddedRatingsItem[]
}

export const EmbeddedRatings = ({ rows }: EmbeddedRatingsProps) => (
  <div className={styles.table}>
    <div className={styles.overflow}>
      <table className={styles.wrapper}>
        <thead>
          <tr className={styles.row}>
            <th className={styles.head}>ENTITY/DEBT</th>
            <th className={styles.head}>RATING</th>
            <th className={styles.head}>PRIOR</th>
          </tr>
        </thead>
        <tbody>
          {rows.map(item => (
            <EmbeddedRating {...item} key={uniqid()} />
          ))}
        </tbody>
      </table>
    </div>
  </div>
)
