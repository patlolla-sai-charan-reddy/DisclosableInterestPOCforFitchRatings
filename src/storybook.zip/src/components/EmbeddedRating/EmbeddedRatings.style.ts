import { css } from 'emotion'
import { mpb1 } from '../GlobalStyles'

export const table = css`
  width: 100%;
`

export const overflow = css`
  width: 100%;
  overflow-x: scroll;
`

export const wrapper = css`
  width: 40.5rem;
  border-collapse: collapse;
  border-spacing: 0;
`

export const head = css`
  padding: ${mpb1};
  text-align: left;
  vertical-align: top;
  font-weight: 900;
  text-transform: uppercase;
`

export const row = css`
  border-bottom: 1px solid #dddddd;
`
