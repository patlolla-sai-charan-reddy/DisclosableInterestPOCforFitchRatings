import React from 'react'
import { storiesOf } from '@storybook/react'
import { Query } from 'react-apollo'
import gql from 'graphql-tag'

import { EmbeddedRatings } from '.'

const GET_EMBEDDED_RATINGS_QUERY = gql`
  {
    getRAC(id: 1000) {
      embeddedRatings {
        rows {
          title
          level
          typeAbbr
          typeDesc
          ratingCode
          watchOutlookCode
          ratingAction
          recoveryRating
          priorRatingCode
          priorWatchOutlookCode
        }
      }
    }
  }
`

storiesOf('Molecules/EmbeddedRatings', module).add('default', () => (
  <Query query={GET_EMBEDDED_RATINGS_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { rows } = data.getRAC.embeddedRatings
      return <EmbeddedRatings rows={rows} />
    }}
  </Query>
))
