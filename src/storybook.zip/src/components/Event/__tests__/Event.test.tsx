import TestRenderer from 'react-test-renderer'
import React from 'react'

import { Event, Events } from '..'

import mocks from '../__mocks__/Event.mock'

describe('Event', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<Event {...mocks[0]} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})

describe('Events', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<Events items={mocks} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})
