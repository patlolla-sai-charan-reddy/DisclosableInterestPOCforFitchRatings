import { css } from 'emotion'

import { c9, mq1, mq3, mq5, mq6 } from '../GlobalStyles'

export const teaser = css`
  width: 100%;
  height: 12.5rem;
  float: left;
  color: ${c9};
  a {
    color: ${c9};
  }
  ${mq1} {
    height: 15rem;
  }
  ${mq3} {
    height: 25rem;
  }
  ${mq5} {
    height: 25rem;
  }
`

export const details = css`
  position: relative;
  width: 50%;
  height: 100%;
  padding: 1.125rem;
  float: left;
  background-color: #171721;
  color: #ffffff;
  ${mq3} {
    width: 100%;
    height: 50%;
  }
  ${mq5} {
    width: 100%;
    height: 50%;
  }
  ${mq6} {
    width: 100%;
  }
`

export const location = css`
  position: absolute;
  width: calc(100% - 2.25rem);
  bottom: 1.125rem;
  margin: 0;
  font-size: 0.875rem;
  font-weight: 300;
  line-height: 1.35;
`

export const map = css`
  position: relative;
  width: 50%;
  height: 100%;
  float: left;
  background: #fbfbfb;
  ${mq3} {
    width: 100%;
    height: 50%;
  }
  ${mq5} {
    width: 100%;
    height: 50%;
  }
  ${mq6} {
    width: 100%;
  }
`

export const innerMap = css`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
`
