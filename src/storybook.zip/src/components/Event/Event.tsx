import React from 'react'
import { DateTime, IANAZone } from 'luxon'

import * as styles from './Event.style'
import { columnTwoColumn, heading7 } from '../GlobalStyles'

const formatDate = (date: string, format: string) =>
  DateTime.fromISO(date)
    .setZone(new IANAZone('America/Chicago'))
    .toFormat(format)

const formatStartEndDate = (startDate: string, endDate: string) =>
  `${formatDate(startDate, 'DD | T')} - ${formatDate(endDate, 'T')}`

export type EventImage = {
  url: string
  title: string
}

export type EventProps = {
  title: string
  startDate: string
  endDate: string
  address: string
  image: EventImage
}

export const Event = ({
  title,
  startDate,
  endDate,
  address,
  image
}: EventProps) => (
  <div className={columnTwoColumn}>
    <article className={styles.teaser}>
      <div className={styles.details}>
        <h4 className={heading7}>
          <a href="#TODO">{title.slice(0, 30)}</a>
        </h4>
        <p className={styles.location}>
          {formatStartEndDate(startDate, endDate)}
          <br />
          {address}
          <br />
        </p>
      </div>
      <div className={styles.map}>
        <div
          className={styles.innerMap}
          style={{ backgroundImage: `url(${image.url})` }}
        />
      </div>
    </article>
  </div>
)
