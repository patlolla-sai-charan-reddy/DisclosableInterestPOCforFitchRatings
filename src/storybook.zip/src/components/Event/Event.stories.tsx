import React from 'react'
import { storiesOf } from '@storybook/react'
import { Query } from 'react-apollo'
import gql from 'graphql-tag'

import { Event, Events } from '.'

const GET_EVENTS_QUERY = gql`
  {
    eventCollection {
      items {
        title
        startDate
        endDate
        address
        region
        country
        eventType
        slug
        locationName
        locationCoordinates {
          lat
          lon
        }
        image {
          url
          title
        }
      }
    }
  }
`

storiesOf('Atoms/Event', module).add('default', () => (
  <Query query={GET_EVENTS_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { items } = data.eventCollection

      return <Event {...items[0]} />
    }}
  </Query>
))

storiesOf('Molecules/Events', module).add('default', () => (
  <Query query={GET_EVENTS_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { items } = data.eventCollection

      return <Events items={items.slice(0, 4)} />
    }}
  </Query>
))
