import React from 'react'
import { css } from 'emotion'
import uniqid from 'uniqid'

import { Event, EventImage } from './Event'

import {
  columnTwo,
  content,
  heading3,
  headingNo,
  section,
  wrapper1
} from '../GlobalStyles'

export type EventsItem = {
  title: string
  startDate: string
  endDate: string
  address: string
  image: EventImage
}

export type EventsProps = {
  items: EventsItem[]
}

export const Events = ({ items }: EventsProps) => (
  <section className={section}>
    <div className={wrapper1}>
      <h2
        className={css`
          ${heading3};
          ${content};
        `}
      >
        <span className={headingNo}>04</span>
        Events
      </h2>
      <div className={columnTwo}>
        {items.map(item => (
          <Event {...item} key={uniqid()} />
        ))}
      </div>
    </div>
  </section>
)
