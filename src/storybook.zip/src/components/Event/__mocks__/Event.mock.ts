export default [
  {
    title: 'Representative E Services Refined Cotton Salad',
    startDate: '2018-12-22T14:28:34.439Z',
    endDate: '2018-12-31T03:54:32.103Z',
    address: '04155 Shields Walks Suite 425',
    region: '',
    country: '',
    eventType: 'Webcast',
    slug: '/events/representative-e-services-refined-cotton-salad-indexing',
    locationName: 'Awesome Frozen Ball bleeding-edge',
    locationCoordinates: {
      lat: -33.0247,
      lon: -130.1028
    },
    image: {
      url:
        'https://images.ctfassets.net/03fbs7oah13w/63puEMmiCyXkwhB2D9ad2H/cc69c62b0015b33a754042924e1fbd49/audience-blur-bokeh-976866.jpg',
      title: 'Hands in the air, blur photo'
    }
  },
  {
    title: 'Auto Loan Account Content Lodge Plastic Frozen',
    startDate: '2018-12-28T18:06:26.839Z',
    endDate: '2019-01-03T13:45:53.530Z',
    address: '767 Mayert Well Suite 173',
    region: '',
    country: '',
    eventType: 'Fitch Solutions Hosted',
    slug:
      '/events/auto-loan-account-content-lodge-plastic-frozen-bedfordshire-data-illinois',
    locationName: 'parse Designer iterate Executive',
    locationCoordinates: {
      lat: -29.3088,
      lon: 151.5229
    },
    image: {
      url:
        'https://images.ctfassets.net/03fbs7oah13w/63puEMmiCyXkwhB2D9ad2H/cc69c62b0015b33a754042924e1fbd49/audience-blur-bokeh-976866.jpg',
      title: 'Hands in the air, blur photo'
    }
  },
  {
    title: 'Granite Hat Borders Open Source Generic',
    startDate: '2019-01-02T07:57:00.775Z',
    endDate: '2019-01-04T14:50:08.223Z',
    address: '54982 Calista Bridge Suite 230',
    region: '',
    country: '',
    eventType: 'Webcast',
    slug:
      '/events/granite-hat-borders-open-source-generic-steel-chicken-rustic-concrete-bacon',
    locationName: 'grid-enabled copying ADP Clothing',
    locationCoordinates: { lat: 6.7003, lon: -2.7328 },
    image: {
      url:
        'https://images.ctfassets.net/03fbs7oah13w/63puEMmiCyXkwhB2D9ad2H/cc69c62b0015b33a754042924e1fbd49/audience-blur-bokeh-976866.jpg',
      title: 'Hands in the air, blur photo'
    }
  },
  {
    title:
      'Solid State Invoice Encryption Envisioneer Transform Standardization',
    startDate: '2019-01-03T19:06:22.991Z',
    endDate: '2018-12-31T00:15:47.944Z',
    address: '501 Hermiston Fork Apt. 464',
    region: '',
    country: '',
    eventType: 'Webcast',
    slug:
      '/events/solid-state-invoice-encryption-envisioneer-transform-standardization',
    locationName: 'HDD compelling productivity Circle US Dollar application',
    locationCoordinates: {
      lat: -61.7249,
      lon: -142.4819
    },
    image: {
      url:
        'https://images.ctfassets.net/03fbs7oah13w/63puEMmiCyXkwhB2D9ad2H/cc69c62b0015b33a754042924e1fbd49/audience-blur-bokeh-976866.jpg',
      title: 'Hands in the air, blur photo'
    }
  }
]
