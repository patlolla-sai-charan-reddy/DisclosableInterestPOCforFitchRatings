import React from 'react'
import { css } from 'emotion'
import uniqid from 'uniqid'

import { RelatedLink, RelatedLinkCollection } from './RelatedLink'
import {
  columnFour,
  content,
  heading3,
  headingNo,
  section,
  wrapper1
} from '../GlobalStyles'

export type RelatedLinksItem = {
  adminTitle: string
  linksCollection: RelatedLinkCollection
}

export type RelatedLinksProps = {
  items: RelatedLinksItem[]
}

export const RelatedLinks = ({ items }: RelatedLinksProps) => (
  <section className={section}>
    <div className={wrapper1}>
      <h2
        className={css`
          ${heading3};
          ${content};
        `}
      >
        <span className={headingNo}>07</span>
        Related Links
      </h2>

      <div className={columnFour}>
        {items.map(item => (
          <RelatedLink {...item} key={uniqid()} />
        ))}
      </div>
    </div>
  </section>
)
