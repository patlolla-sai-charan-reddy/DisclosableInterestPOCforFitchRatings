import React from 'react'
import uniqid from 'uniqid'

import { columnFourColumn } from '../GlobalStyles'
import * as styles from './RelatedLink.style'

export type RelatedLinkItem = {
  linkTitle: string
  url: string
}

export type RelatedLinkCollection = {
  items: RelatedLinkItem[]
}

export type RelatedLinkProps = {
  adminTitle: string
  linksCollection: RelatedLinkCollection
}

export const RelatedLink = ({
  adminTitle,
  linksCollection
}: RelatedLinkProps) => (
  <div className={columnFourColumn}>
    <ul>
      <li>
        <strong>{adminTitle}</strong>
      </li>
      {linksCollection.items.map(item => (
        <li key={uniqid()}>
          <a href={item.url} className={styles.listItem}>
            {' '}
            {item.linkTitle}
          </a>
        </li>
      ))}
    </ul>
  </div>
)
