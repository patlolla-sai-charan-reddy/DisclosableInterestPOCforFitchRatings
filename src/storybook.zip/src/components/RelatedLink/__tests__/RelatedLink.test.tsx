import TestRenderer from 'react-test-renderer'
import React from 'react'

import { RelatedLink, RelatedLinks } from '..'

import mocks from '../__mocks__/RelatedLink.mock'

describe('RelatedLink', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<RelatedLink {...mocks[0]} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})

describe('RelatedLinks', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<RelatedLinks items={mocks} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})
