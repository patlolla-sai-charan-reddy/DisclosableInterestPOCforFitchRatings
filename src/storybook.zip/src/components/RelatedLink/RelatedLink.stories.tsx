import React from 'react'
import { storiesOf } from '@storybook/react'
import { Query } from 'react-apollo'
import gql from 'graphql-tag'

import { RelatedLink, RelatedLinks } from '.'

const GET_RELATED_LINKS_QUERY = gql`
  {
    relatedLinksCollection {
      items {
        adminTitle
        title
        linksCollection {
          items {
            linkTitle
            url
          }
        }
      }
    }
  }
`

storiesOf('Atoms/RelatedLink', module).add('default', () => (
  <Query query={GET_RELATED_LINKS_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { items } = data.relatedLinksCollection

      return <RelatedLink {...items[0]} />
    }}
  </Query>
))

storiesOf('Molecules/RelatedLinks', module).add('default', () => (
  <Query query={GET_RELATED_LINKS_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>

      return <RelatedLinks {...data.relatedLinksCollection} />
    }}
  </Query>
))
