export default [
  {
    adminTitle: 'Related Links - 9',
    title: '2',
    linksCollection: {
      items: [
        {
          linkTitle: 'Fully Configurable Multi Tasking Licensed Concrete Chair',
          url: 'https://noemi.info'
        },
        {
          linkTitle: 'Refined Metal Shirt Trafficway',
          url: 'https://eusebio.name'
        },
        {
          linkTitle: 'TCP Azure Value Added Reinvent Hat',
          url: 'http://steve.name'
        },
        {
          linkTitle: 'Seychelles Product THX Kids International',
          url: 'http://destiny.net'
        },
        {
          linkTitle: 'Indian Rupee Ngultrum',
          url: 'http://presley.com'
        },
        { linkTitle: 'Indiana', url: 'https://eldon.name' },
        {
          linkTitle: 'Function Based Bacon Personal Loan Account Fresh Pixel',
          url: 'http://birdie.info'
        },
        {
          linkTitle: 'Supply Chains Florida Kids South Carolina SQL',
          url: 'http://willy.net'
        }
      ]
    }
  },
  {
    adminTitle: 'Related Links - 21',
    title: '2',
    linksCollection: {
      items: [
        {
          linkTitle: 'Indian Rupee Ngultrum',
          url: 'http://presley.com'
        }
      ]
    }
  },
  {
    adminTitle: 'Related Links - 26',
    title: '2',
    linksCollection: {
      items: [
        {
          linkTitle: 'Supply Chains Florida Kids South Carolina SQL',
          url: 'http://willy.net'
        },
        {
          linkTitle: 'Generic JBOD Borders Vista Auxiliary',
          url: 'http://vesta.org'
        },
        {
          linkTitle: 'Fully Configurable Multi Tasking Licensed Concrete Chair',
          url: 'https://noemi.info'
        },
        {
          linkTitle: 'Refined Metal Shirt Trafficway',
          url: 'https://eusebio.name'
        },
        {
          linkTitle:
            'Credit Card Account Withdrawal Lavender Representative Rhode Island',
          url: 'https://demarco.org'
        }
      ]
    }
  },
  {
    adminTitle: 'Related Links - 98',
    title: '3',
    linksCollection: {
      items: [
        {
          linkTitle: 'Intranet Olive Florida',
          url: 'http://abel.net'
        },
        {
          linkTitle: 'Compress Online Dynamic',
          url: 'http://brandi.info'
        },
        {
          linkTitle: 'Methodologies Metrics Cheese',
          url: 'https://deon.com'
        }
      ]
    }
  },
  {
    adminTitle: 'Related Links - 3',
    title: '4',
    linksCollection: {
      items: [
        {
          linkTitle: 'Savings Account Chief',
          url: 'https://devyn.net'
        },
        {
          linkTitle:
            'Credit Card Account Withdrawal Lavender Representative Rhode Island',
          url: 'https://demarco.org'
        }
      ]
    }
  },
  {
    adminTitle: 'Related Links - 50',
    title: '2',
    linksCollection: {
      items: [
        {
          linkTitle: 'Generic JBOD Borders Vista Auxiliary',
          url: 'http://vesta.org'
        },
        {
          linkTitle: 'Intranet Olive Florida',
          url: 'http://abel.net'
        },
        {
          linkTitle:
            'Refined Granite Bike Transmit Back End Ergonomic Soft Table Burgs',
          url: 'https://ewell.org'
        },
        {
          linkTitle: 'Indian Rupee Ngultrum',
          url: 'http://presley.com'
        },
        {
          linkTitle: 'Utilize Turn Key Credit Card Account Iowa',
          url: 'https://blanca.net'
        },
        {
          linkTitle: 'TCP Azure Value Added Reinvent Hat',
          url: 'http://steve.name'
        }
      ]
    }
  }
]
