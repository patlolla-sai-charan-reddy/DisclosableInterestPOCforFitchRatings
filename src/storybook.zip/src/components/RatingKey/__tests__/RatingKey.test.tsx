import TestRenderer from 'react-test-renderer'
import React from 'react'

import { RatingKey } from '..'

describe('RatingKey', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<RatingKey />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})
