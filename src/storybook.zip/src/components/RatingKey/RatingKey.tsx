import React from 'react'

import * as styles from './RatingKey.style'
import { euRatingText } from '../GlobalStyles'

export default () => (
  <div className={styles.ratingKey}>
    <table>
      <thead>
        <tr>
          <th>RATINGS KEY</th>
          <th>OUTLOOK</th>
          <th>WATCH</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Positive</td>
          <td>
            <span className={styles.outlookPositive} />
          </td>
          <td>
            <span className={styles.watchPositive} />
          </td>
        </tr>
        <tr>
          <td>Negative</td>
          <td>
            <span className={styles.outlookNegative} />
          </td>
          <td>
            <span className={styles.watchNegative} />
          </td>
        </tr>
        <tr>
          <td>Evolving</td>
          <td>
            <span className={styles.outlookEvolving} />
          </td>
          <td>
            <span className={styles.watchEvolving} />
          </td>
        </tr>
        <tr>
          <td>Stable</td>
          <td>
            <span className={styles.outlookStable} />
          </td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>Premium Content</td>
          <td>
            <span className={styles.premium} />
          </td>
          <td>&nbsp;</td>
        </tr>
      </tbody>
    </table>
    <p>
      *
      <span className={euRatingText}>
        Long Term/Short Term Issuer Default Rating&nbsp;
      </span>
      displayed in&nbsp;
      <span className={euRatingText}>orange</span>
      &nbsp;denotes EU Unsolicited and Non-Participatory Ratings
    </p>
  </div>
)
