import { css } from 'emotion'
import { mpb2 } from '../GlobalStyles'

export const ratingKey = css`
  table {
    width: 100%;
  }
  th {
    padding-bottom: 0.375rem;
    font-weight: 900;
  }
  td {
    padding: 0.375rem 0;
    font-size: 0.75rem;
    font-weight: 900;
    text-transform: uppercase;
  }

  th:nth-child(1),
  td:nth-child(1) {
    text-align: left;
  }
  th:nth-child(2),
  td:nth-child(2) {
    padding: 0 0.375rem 0.375rem;
    text-align: center;
  }

  th:nth-child(3),
  td:nth-child(3) {
    text-align: center;
  }
`

const icon = css`
  width: ${mpb2};
  height: ${mpb2};
  background-image: url('../_images/ratings-key.png');
  background-repeat: no-repeat;
  overflow: hidden;
  display: inline-block;
`
export const outlookPositive = css`
  ${icon}
  background-position: 0 0;
`
export const outlookNegative = css`
  ${icon}
  background-position: 0 -36px;
`
export const outlookEvolving = css`
  ${icon}
  background-position: 0 -72px;
`
export const outlookStable = css`
  ${icon}
  background-position: 0 -108px;
`
export const watchPositive = css`
  ${icon}
  background-position: -31px 0;
`
export const watchNegative = css`
  ${icon}
  background-position: -31px -36px;
`
export const watchEvolving = css`
  ${icon}
  background-position: -31px -72px;
`
export const premium = css`
  ${icon}
  background-position: -31px -108px;
`
