import React from 'react'
import { storiesOf } from '@storybook/react'

import RatingKey from './RatingKey'

storiesOf('Atoms/RatingKey', module).add('default', () => <RatingKey />)
