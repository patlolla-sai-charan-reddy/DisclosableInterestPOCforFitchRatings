export default [
  {
    title: 'Senior Director',
    firstName: 'Linda',
    lastName: 'Friedman',
    type: 'Primary Rating Analyst',
    phoneNumber: '+1 212 908 0727',
    address: 'Fitch Ratings, Inc. 33 Whitehall Street  New York 10004'
  },
  {
    title: 'Senior Director',
    firstName: 'Ronald',
    lastName: 'McGovern',
    type: 'Secondary Rating Analyst',
    phoneNumber: '+1 212 908 0513',
    address: 'Fitch Ratings, Inc. 33 Whitehall Street  New York 10004'
  },
  {
    title: 'Senior Director',
    firstName: 'Mario',
    lastName: 'Civico',
    type: 'Committee Chairperson',
    phoneNumber: '+1 212 908 0796',
    address: '   '
  }
]
