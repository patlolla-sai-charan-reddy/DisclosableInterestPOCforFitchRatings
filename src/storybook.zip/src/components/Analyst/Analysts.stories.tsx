import React from 'react'
import { storiesOf } from '@storybook/react'
import { Query } from 'react-apollo'
import gql from 'graphql-tag'

import { Analyst, Analysts } from '.'

const GET_RATING_QUERY = gql`
  {
    getRAC(id: 1000) {
      analysts {
        type
        firstName
        lastName
        title
        phoneNumber
        address
      }
    }
  }
`

storiesOf('Atoms/Analyst', module).add('default', () => (
  <Query query={GET_RATING_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { analysts } = data.getRAC

      return <Analyst {...analysts[0]} />
    }}
  </Query>
))

storiesOf('Molecules/Analysts', module).add('default', () => (
  <Query query={GET_RATING_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { analysts } = data.getRAC

      return <Analysts items={analysts} />
    }}
  </Query>
))
