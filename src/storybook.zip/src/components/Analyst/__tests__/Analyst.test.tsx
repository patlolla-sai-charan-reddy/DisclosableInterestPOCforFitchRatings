import TestRenderer from 'react-test-renderer'
import React from 'react'

import { Analyst, Analysts } from '..'

import mocks from '../__mocks__/Analyst.mock'

describe('Analyst', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<Analyst {...mocks[0]} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})

describe('Analysts', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<Analysts items={mocks} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})
