import React from 'react'

export type AnalystProps = {
  firstName: string
  lastName: string
  title: string
  type: string
  phoneNumber: string
  address: string
}

export const Analyst = ({
  firstName,
  lastName,
  title,
  type,
  phoneNumber,
  address
}: AnalystProps) => (
  <p>
    <strong>{`${firstName} ${lastName}`}</strong>
    <br />
    {title}
    <br />
    {type}
    <br />
    {phoneNumber}
    <br />
    {address}
  </p>
)
