import React from 'react'
import uniqid from 'uniqid'

import { Analyst } from './Analyst'
import { block, heading5 } from '../GlobalStyles'

export type AnalystsItem = {
  firstName: string
  lastName: string
  title: string
  type: string
  phoneNumber: string
  address: string
}

export type AnalystsProps = {
  items: AnalystsItem[]
}

export const Analysts = ({ items }: AnalystsProps) => (
  <div className={block}>
    <h2 className={heading5}>Fitch Ratings Analysts</h2>
    {items.map(item => (
      <Analyst {...item} key={uniqid()} />
    ))}
  </div>
)
