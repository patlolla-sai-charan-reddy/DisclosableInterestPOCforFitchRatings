import React from 'react'
import { storiesOf } from '@storybook/react'
import { Query } from 'react-apollo'
import gql from 'graphql-tag'

import {
  Research,
  ResearchItem,
  ResearchItemRenderLinkProps,
  ResearchHighlight,
  ResearchHighlightRenderLinkProps
} from '.'

const GET_RATINGS_QUERY = gql`
  {
    getRACs(sector: "") {
      rows {
        dbDocId
        publishedDate
        reportType
        title
      }
    }
  }
`
storiesOf('Atoms/ResearchItem', module)
  .add('default', () => (
    <Query query={GET_RATINGS_QUERY}>
      {({ loading, error, data }) => {
        if (loading) return <p>Loading...</p>
        if (error) return <p>Error :(</p>
        const { rows } = data.getRACs
        return <ResearchItem {...rows[0]} />
      }}
    </Query>
  ))
  .add('with styled report type', () => (
    <Query query={GET_RATINGS_QUERY}>
      {({ loading, error, data }) => {
        if (loading) return <p>Loading...</p>
        if (error) return <p>Error :(</p>
        const { rows } = data.getRACs
        return <ResearchItem {...rows[0]} reportTypeColor="#cc0033" />
      }}
    </Query>
  ))
  .add('custom render link', () => {
    const customRenderLink = ({
      dbDocId,
      title
    }: ResearchItemRenderLinkProps) => (
      <a href={`#${dbDocId}`}>
        Custom:
        {title}
      </a>
    )

    return (
      <Query query={GET_RATINGS_QUERY}>
        {({ loading, error, data }) => {
          if (loading) return <p>Loading...</p>
          if (error) return <p>Error :(</p>
          const { rows } = data.getRACs
          const props = {
            ...rows[0],
            renderLink: customRenderLink
          }

          return <ResearchItem {...props} />
        }}
      </Query>
    )
  })

storiesOf('Atoms/ResearchHighlight', module)
  .add('default', () => (
    <Query query={GET_RATINGS_QUERY}>
      {({ loading, error, data }) => {
        if (loading) return <p>Loading...</p>
        if (error) return <p>Error :(</p>
        const { rows } = data.getRACs
        return (
          <ResearchHighlight
            {...rows[0]}
            image={{
              url:
                'https://your.fitchratings.com/rs/732-CKH-767/images/global-leveraged-finance-2.jpg'
            }}
          />
        )
      }}
    </Query>
  ))
  .add('with background color', () => {
    return (
      <Query query={GET_RATINGS_QUERY}>
        {({ loading, error, data }) => {
          if (loading) return <p>Loading...</p>
          if (error) return <p>Error :(</p>
          const { rows } = data.getRACs

          return <ResearchHighlight {...rows[0]} backgroundColor="#171721" />
        }}
      </Query>
    )
  })
  .add('custom render link', () => {
    const customRenderLink = ({
      dbDocId,
      title
    }: ResearchHighlightRenderLinkProps) => (
      <a href={`#${dbDocId}`}>
        Custom:
        {title}
      </a>
    )

    return (
      <Query query={GET_RATINGS_QUERY}>
        {({ loading, error, data }) => {
          if (loading) return <p>Loading...</p>
          if (error) return <p>Error :(</p>
          const { rows } = data.getRACs
          const props = {
            ...rows[0],
            renderLink: customRenderLink
          }

          return (
            <ResearchHighlight
              {...props}
              image={{
                url:
                  'https://your.fitchratings.com/rs/732-CKH-767/images/global-leveraged-finance-2.jpg'
              }}
            />
          )
        }}
      </Query>
    )
  })

storiesOf('Molecules/Research', module).add('default', () => (
  <Query query={GET_RATINGS_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { rows } = data.getRACs
      return <Research items={rows.slice(0, 5)} />
    }}
  </Query>
))
