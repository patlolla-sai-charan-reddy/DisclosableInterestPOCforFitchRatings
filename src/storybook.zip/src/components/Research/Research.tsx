import React from 'react'
import { css } from 'emotion'
import uniqid from 'uniqid'

import { ResearchItem, ResearchItemProps } from './ResearchItem'
import { ResearchHighlight } from './ResearchHighlight'
import {
  column,
  columnTwo,
  columnTwoColumn,
  content,
  heading3,
  headingNo,
  section,
  va,
  wrapper1
} from '../GlobalStyles'

type ResearchItem = Partial<ResearchItemProps> & {
  dbDocId: string
  title: string
  publishedDate: string
}

export type ResearchProps = {
  items: ResearchItem[]
}

export const Research = ({ items }: ResearchProps) => (
  <section className={section}>
    <div className={wrapper1}>
      <h2
        className={css`
          ${heading3};
          ${content};
        `}
      >
        <span className={headingNo}>02</span>
        Research
      </h2>

      <div className={columnTwo}>
        <div className={columnTwoColumn}>
          <ResearchHighlight
            {...items[0]}
            image={{
              url:
                'https://your.fitchratings.com/rs/732-CKH-767/images/global-leveraged-finance-2.jpg'
            }}
          />
        </div>
        <div className={column}>
          <div className={va}>
            {items.map(item => (
              <ResearchItem {...item} key={uniqid()} />
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
)
