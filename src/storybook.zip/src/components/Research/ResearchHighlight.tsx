import React, { ComponentType } from 'react'
import { css } from 'emotion'

import * as styles from './ResearchHighlight.style'
import { bgImg, bg1 } from '../GlobalStyles'

export type ResearchHighlightRenderLinkProps = Partial<ResearchHighlightProps>

const renderLinkDefault = ({
  dbDocId,
  title = ''
}: ResearchHighlightRenderLinkProps) => (
  <a href={`${dbDocId}`}>{title.slice(0, 50)}</a>
)

export type ResearchHighlightImage = {
  url: string
}

export type ResearchHighlightProps = {
  dbDocId: string
  title: string
  backgroundColor?: string
  image: ResearchHighlightImage
  renderLink?: ComponentType<ResearchHighlightRenderLinkProps>
}

const renderBackground = (
  image?: ResearchHighlightImage,
  backgroundColor?: string
) => {
  if (image && image.url) {
    return { backgroundImage: `url(${image.url})` }
  }
  if (backgroundColor) {
    return { backgroundColor }
  }
  return {}
}

export const ResearchHighlight = (props: ResearchHighlightProps) => {
  const { image, backgroundColor, renderLink: Link = renderLinkDefault } = props

  return (
    <article
      className={css`
        ${bgImg};
        ${bg1};
        ${styles.highlight};
      `}
      style={renderBackground(image, backgroundColor)}
    >
      <div className={styles.subHeading}>Highlight</div>
      <h2 className={styles.heading}>
        <Link {...props} />
      </h2>
    </article>
  )
}
