import { css } from 'emotion'
import { c9, heading1, headingSub, mpb2 } from '../GlobalStyles'

export const highlight = css`
  position: relative;
  height: 100%;
  padding: 2.25rem ${mpb2};
  overflow: hidden;

  > *:not(.video) {
    position: relative;
  }

  p:last-of-type:not(:first-of-type) {
    margin-bottom: 0;
  }

  p:last-of-type {
    margin-bottom: 0;
  }

  .button__wrapper {
    position: absolute;
    bottom: 36px;
    width: calc(100% - 48px);

    + p {
      margin-bottom: 88px;
    }
  }

  .video {
    position: absolute;
    left: 0;
    width: 100%;
    height: 0;
    padding-bottom: 56.25%;
  }

  a {
    color: ${c9};
  }
`
export const heading = css`
  ${heading1}
  width: 66%;
  margin-bottom: 4.625rem;
`

export const subHeading = css`
  ${headingSub}
  color: inherit;
`
