import React, { ComponentType } from 'react'

import { articleRow, heading4, headingSub } from '../GlobalStyles'
import * as styles from './ResearchItem.style'

const formatDate = (date: string) => {
  const eventDate = new Date(date.split('T')[0])
  const month = eventDate.toString().split(' ')[1]
  const day = eventDate.getDate()
  const year = eventDate.getFullYear()
  return `${month} ${day}, ${year}`
}

export type ResearchItemRenderLinkProps = Partial<ResearchItemProps>

const renderLinkDefault = ({
  dbDocId,
  title = ''
}: ResearchItemRenderLinkProps) => (
  <a href={`${dbDocId}`} className={styles.listItem}>
    {title.slice(0, 30)}
  </a>
)

export type ResearchItemProps = {
  dbDocId: string
  publishedDate: string
  reportType?: string
  title: string
  reportTypeColor?: string
  renderLink?: ComponentType<ResearchItemRenderLinkProps>
}

const renderReportTypeColor = (reportTypeColor?: string) => {
  if (reportTypeColor) {
    return { color: reportTypeColor }
  }
  return {}
}

export const ResearchItem = (props: ResearchItemProps) => {
  const {
    publishedDate,
    reportType,
    reportTypeColor,
    renderLink: Link = renderLinkDefault
  } = props

  return (
    <article className={articleRow}>
      <div className={headingSub}>
        <span style={renderReportTypeColor(reportTypeColor)}>{reportType}</span>{' '}
        /{formatDate(publishedDate)}
      </div>
      <h3 className={heading4}>
        <Link {...props} />
      </h3>
    </article>
  )
}
