import React from 'react'

import * as styles from './MarketingTag.style'

export type MarketingTagProps = {
  name: string
  url: string
}

export const MarketingTag = ({ name, url }: MarketingTagProps) => (
  <div className={styles.default}>
    <a href={url}>{name}</a>
  </div>
)
