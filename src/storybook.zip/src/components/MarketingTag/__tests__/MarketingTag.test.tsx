import TestRenderer from 'react-test-renderer'
import React from 'react'

import { MarketingTag, MarketingTags } from '..'

import mocks from '../__mocks__/MarketingTag.mock'

const { sectors, regions } = mocks
const items = sectors
regions.map(region => items.push(region))

describe('MarketingTag', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<MarketingTag {...items[0]} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})

describe('MarketingTags', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<MarketingTags items={items} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})
