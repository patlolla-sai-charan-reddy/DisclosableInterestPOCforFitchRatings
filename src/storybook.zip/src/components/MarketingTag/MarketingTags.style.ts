import { css } from 'emotion'
import { mpb2 } from '../GlobalStyles'

export default css`
  margin-bottom: 5.25rem;
  padding: ${mpb2} 0;
  border-top: 1px solid #dddddd;
  border-bottom: 1px solid #dddddd;
`
