export default {
  sectors: [
    {
      url: 'http://example.com',
      name: 'Corporate Finance'
    },
    {
      url: 'http://example.com',
      name: 'Banks'
    },
    {
      url: 'http://example.com',
      name: 'Structured Finance'
    }
  ],
  regions: [
    {
      url: 'http://example.com',
      name: 'Australia/Oceania'
    }
  ]
}
