import React from 'react'
import { storiesOf } from '@storybook/react'
import { Query } from 'react-apollo'
import gql from 'graphql-tag'

import { MarketingTag, MarketingTags } from '.'

const GET_RATING_QUERY = gql`
  {
    getRAC(id: 1000) {
      marketing {
        sectors {
          name
          url
        }
        regions {
          name
          url
        }
      }
    }
  }
`

storiesOf('Atoms/MarketingTag', module).add('default', () => (
  <Query query={GET_RATING_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { sectors } = data.getRAC.marketing
      return <MarketingTag {...sectors[0]} />
    }}
  </Query>
))

storiesOf('Molecules/MarketingTags', module).add('default', () => (
  <Query query={GET_RATING_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { sectors, regions } = data.getRAC.marketing
      const marketingTags = [...regions, ...sectors]

      return <MarketingTags items={marketingTags} />
    }}
  </Query>
))
