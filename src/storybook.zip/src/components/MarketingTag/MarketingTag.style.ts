import { css } from 'emotion'
import { c2 } from '../GlobalStyles'

export default css`
  margin: 0.375rem 0.188rem;
  padding: 0.25rem 0.5rem;
  background: #dddddd;
  font-size: 0.875rem;
  border-radius: 5px;
  cursor: pointer;
  display: inline-block;
  color: ${c2};

  a {
    color: ${c2};
  }

  &:hover,
  &:focus {
    background: #e5e5e5;
  }
`
