import React from 'react'

import uniqid from 'uniqid'

import { MarketingTag } from './MarketingTag'
import * as styles from './MarketingTags.style'

export type MarketingTagsItem = {
  name: string
  url: string
}

export type MarketingTagsProps = {
  items: MarketingTagsItem[]
}

export const MarketingTags = ({ items }: MarketingTagsProps) => (
  <div className={styles.default}>
    {items.map(item => (
      <MarketingTag {...item} key={uniqid()} />
    ))}
  </div>
)
