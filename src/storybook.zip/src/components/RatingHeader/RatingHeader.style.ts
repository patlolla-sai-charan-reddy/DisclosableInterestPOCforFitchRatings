import { css } from 'emotion'
import { c2, mq3 } from '../GlobalStyles'

export default css`
  margin-top: 4.313rem;
  a {
    color: ${c2};
  }
  ${mq3} {
    height: 100vh;
    min-height: auto;
  }
`
