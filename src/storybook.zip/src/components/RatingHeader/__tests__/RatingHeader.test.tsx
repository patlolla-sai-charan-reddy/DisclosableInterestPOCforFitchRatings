import TestRenderer from 'react-test-renderer'
import React from 'react'

import { RatingHeader } from '..'

import mocks from '../__mocks__/RatingHeader.mock'

describe('Header', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<RatingHeader {...mocks} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})
