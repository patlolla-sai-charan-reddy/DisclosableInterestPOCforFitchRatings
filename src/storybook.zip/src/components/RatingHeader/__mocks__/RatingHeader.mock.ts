export default {
  title: 'Fitch Takes Various Rating Actions on TOBs Series 2016-ZM0318',
  companyDesc: 'Fitch Ratings',
  reportType: 'Rating Action Commentary',
  origin: 'New York',
  publishedDate: 1551765600000
}
