import React from 'react'
import { DateTime, IANAZone } from 'luxon'

import {
  columnLeftLM,
  columnMainLM,
  heading1,
  heading7,
  pageLayout
} from '../GlobalStyles'
import * as styles from './RatingHeader.style'

const formatDateTime = (milliseconds: number) =>
  DateTime.fromMillis(milliseconds)
    .setZone(new IANAZone('America/Chicago'))
    .toFormat('DD - T ZZZZ')

export type RatingHeaderProps = {
  title: string
  reportType: string
  publishedDate: number
  origin: string
  companyDesc: string
}

export const RatingHeader = ({
  title,
  reportType,
  publishedDate,
  origin,
  companyDesc
}: RatingHeaderProps) => (
  <header className={styles.default}>
    <div className={pageLayout}>
      <div className={columnLeftLM}>&nbsp;</div>
      <div className={columnMainLM}>
        <p className={heading7}>
          <a href="http://www.fitchsolutions.com/articles">{reportType}</a>
        </p>
        <h1 className={heading1}>{title}</h1>
        <p>
          {companyDesc} /{origin} /{formatDateTime(publishedDate)}
        </p>
      </div>
    </div>
  </header>
)
