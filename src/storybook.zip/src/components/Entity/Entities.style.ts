import { css } from 'emotion'

export default css`
  padding: 24px 0;
  text-align: center;
`
