import React from 'react'
import { css } from 'emotion'

import * as styles from './EntityHighlight.style'
import { bg5, heading1 } from '../GlobalStyles'

export default () => (
  <article
    className={css`
      ${styles.entities};
      ${bg5};
    `}
  >
    <h2 className={heading1}>
      We rate over
      <span className={styles.figure}>1,250</span>
      sector name entities
    </h2>
  </article>
)
