import React from 'react'

import * as styles from './EntityLogo.style'

export type EntityLogoProps = {
  url: string
  description: string
}

export const EntityLogo = ({ url, description }: EntityLogoProps) => (
  <img src={url} alt={description} className={styles.default} />
)
