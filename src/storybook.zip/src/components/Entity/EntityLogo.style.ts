import { css } from 'emotion'

export default css`
  width: 110px;
  height: auto;
  margin: 21px;
  display: inline-block;
`
