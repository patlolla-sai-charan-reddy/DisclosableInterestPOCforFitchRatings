import React from 'react'
import { storiesOf } from '@storybook/react'

import { Entities, EntityLogo, EntityHighlight } from '.'

const items = [
  {
    url: 'https://www.dropbox.com/s/32l5oenb6tzvtvl/logo-virgin-media.png?dl=1',
    description: 'Virgin Media'
  },
  {
    url: 'https://www.dropbox.com/s/01kyxrz0ksuxenv/logo-amazon.png?dl=1',
    description: 'Virgin Media'
  },
  {
    url: 'https://www.dropbox.com/s/ytyjm7l6vo3fpgh/logo-rio-tinto.png?dl=1',
    description: 'Rio Tinto'
  },
  {
    url: 'https://www.dropbox.com/s/ormm94jpv69aayw/logo-fox.png?dl=1',
    description: '21st Cemtury Fox'
  },
  {
    url:
      'https://www.dropbox.com/s/jwjzjrvyaeud4je/logo-goodyear-dunlop.png?dl=1',
    description: 'Goodyear Dunlop'
  },
  {
    url:
      'https://www.dropbox.com/s/7viqri7bgs645qj/logo-expedia-group.png?dl=1',
    description: 'Expedia'
  },

  {
    url: 'https://www.dropbox.com/s/a20nobx3yjr7hjz/logo-petronas.png?dl=1',
    description: 'Pertronas'
  },
  {
    url: 'https://www.dropbox.com/s/x5e3132azelr05a/logo-accenture.png?dl=1',
    description: 'Accenture'
  }
]

storiesOf('Atoms/EntityLogo', module).add('default', () => (
  <EntityLogo {...items[0]} />
))

storiesOf('Atoms/EntityHighlight', module).add('default', () => (
  <EntityHighlight />
))

storiesOf('Molecules/Entities', module).add('default', () => {
  return <Entities items={items} />
})
