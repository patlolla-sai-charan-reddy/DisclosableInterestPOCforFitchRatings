import React from 'react'
import { css } from 'emotion'
import uniqid from 'uniqid'

import EntityHighlight from './EntityHighlight'
import * as styles from './Entities.style'
import { EntityLogo } from './EntityLogo'
import {
  column,
  columnMergeA,
  columnTwo,
  columnTwoColumn,
  heading3,
  headingNo,
  content,
  section,
  va,
  wrapper1
} from '../GlobalStyles'

export type EntitiesItem = {
  url: string
  description: string
}

export type EntitiesProps = {
  items: EntitiesItem[]
}

export const Entities = ({ items }: EntitiesProps) => (
  <section className={section}>
    <div className={wrapper1}>
      <h2
        className={css`
          ${heading3};
          ${content};
        `}
      >
        <span className={headingNo}>03</span>
        Entities
      </h2>

      <div className={columnTwo}>
        <div className={columnTwoColumn}>
          <EntityHighlight />
        </div>
        <div
          className={css`
            ${column};
            ${columnMergeA};
            ${columnTwoColumn};
          `}
        >
          <div
            className={css`
              ${styles.default};
              ${va};
            `}
          >
            {items.map(item => (
              <EntityLogo {...item} key={uniqid()} />
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
)
