import { css } from 'emotion'
import { mpb2 } from '../GlobalStyles'

export const entities = css`
  height: 100%;
  padding: 2.25rem ${mpb2};
`

export const figure = css`
  font-size: 121px;
  line-height: 1;
  display: block;
`
