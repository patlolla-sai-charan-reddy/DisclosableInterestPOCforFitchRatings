import { css } from 'emotion'
import { c2 } from '../GlobalStyles'

// eslint-disable-next-line import/prefer-default-export
export const listItem = css`
  color: ${c2};
`
