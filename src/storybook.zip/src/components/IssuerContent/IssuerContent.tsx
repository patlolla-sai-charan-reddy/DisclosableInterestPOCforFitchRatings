import React from 'react'

import * as styles from './IssuerContent.style'

export type IssuerContentProps = {
  title: string
}

export const IssuerContent = ({ title }: IssuerContentProps) => (
  <li>
    <a href="/" className={styles.listItem}>
      {title}
    </a>
  </li>
)
