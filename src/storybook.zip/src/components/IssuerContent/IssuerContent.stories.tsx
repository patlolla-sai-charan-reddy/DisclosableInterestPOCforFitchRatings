import React from 'react'
import { storiesOf } from '@storybook/react'
import { Query } from 'react-apollo'
import gql from 'graphql-tag'

import { IssuerContent, IssuerContents } from '.'

const GET_ISSUER_CONTENTS_QUERY = gql`
  {
    getIssuerContentForRAC(id: 1) {
      title
      dbDocId
      fcReportType
    }
  }
`

storiesOf('Atoms/IssuerContent', module).add('default', () => (
  <Query query={GET_ISSUER_CONTENTS_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      return <IssuerContent {...data.getIssuerContentForRAC[0]} />
    }}
  </Query>
))

storiesOf('Molecules/IssuerContents', module).add('default', () => (
  <Query query={GET_ISSUER_CONTENTS_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      return <IssuerContents items={data.getIssuerContentForRAC} />
    }}
  </Query>
))
