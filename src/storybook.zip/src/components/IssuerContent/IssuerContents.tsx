import React from 'react'
import uniqid from 'uniqid'

import { IssuerContent } from './IssuerContent'
import { asideBlock, heading5, listStyle2 } from '../GlobalStyles'

export type IssuerContentsItem = {
  title: string
  dbDocId: string
}

export type IssuerContentsProps = {
  items: IssuerContentsItem[]
}

export const IssuerContents = ({ items }: IssuerContentsProps) => (
  <div className={asideBlock}>
    <h3 className={heading5}>Issuer Content</h3>
    <ul className={listStyle2}>
      {items.map(item => (
        <IssuerContent {...item} key={uniqid()} />
      ))}
    </ul>
  </div>
)
