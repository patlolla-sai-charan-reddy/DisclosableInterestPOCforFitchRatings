export default [
  {
    title: 'CORRECT 1 test',
    dbDocId: 10050353,
    fcReportType: 'Rating Action Commentary'
  },
  {
    title: 'NRAC 650 ISSUERS',
    dbDocId: 10050118,
    fcReportType: 'Non-Rating Action Commentary'
  },
  {
    title: 'Research 650 issuers',
    dbDocId: 10050121,
    fcReportType: 'Profile'
  }
]
