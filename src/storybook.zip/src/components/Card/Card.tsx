import React from 'react'

import * as styles from './Card.style'
import { content, heading5 } from '../GlobalStyles'

export type CardImage = {
  url: string
  title: string
}

export type CardProps = {
  title: string
  text: string
  link: string
  image: CardImage
}

export const Card = ({ title, text, link, image }: CardProps) => (
  <div className={styles.card}>
    <div className={styles.imageWrapper}>
      <a href={link} className={styles.link}>
        <img src={image.url} alt={image.title} className={styles.image} />
      </a>
    </div>
    <div className={content}>
      <h4 className={heading5}>
        <a href={link}>{title}</a>
      </h4>
      <p>{text}</p>
    </div>
  </div>
)
