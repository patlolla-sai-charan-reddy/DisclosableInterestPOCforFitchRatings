import React from 'react'
import { storiesOf } from '@storybook/react'

import { Card } from './Card'

const props = {
  title:
    'Fitch Ratings: Global Steel Outlook Stable, but Producer Margins Will Fall',
  text:
    'Fitch Ratings-London-30 January 2019: The outlook for the global steel sector is stable in 2019, Fitch Ratings says. Chinese export restraint is a key support for the sector in the face of rising output elsewhere, which, combined with lower...',
  link: 'http://www.fitchratings.com',
  image: {
    url:
      'https://your.fitch.group/rs/732-CKH-767/images/fr-outlook-realestate-3.jpg',
    title: 'Fitch Ratings'
  }
}

storiesOf('Atoms/Card', module).add('default', () => (
  <div style={{ width: '20rem' }}>
    <Card {...props} />
  </div>
))
