import { css } from 'emotion'
import { c2, c3, mpb2, mpb3 } from '../GlobalStyles'

export const card = css`
  height: 100%;
  margin-bottom: ${mpb2};
  padding-bottom: ${mpb2};
  text-align: center;
  border-left: 1px solid #dddddd;
  border-bottom: 1px solid #dddddd;
  border-right: 1px solid #dddddd;

  a {
    color: ${c2};
  }
`

export const imageWrapper = css`
  margin-bottom: ${mpb3};
`

export const image = css`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: ${c3};
`

export const link = css`
  position: relative;
  width: 100%;
  height: 0;
  padding-bottom: 56.25%;
  display: block;
`
