import React from 'react'
import { storiesOf } from '@storybook/react'

import { KeyPoint } from '.'

storiesOf('Atoms/KeyPoint', module)
  .add('default', () => (
    <KeyPoint
      heading="Unrivaled local knowledge"
      abstract="We have 1,100 leading&nbsp;analysts in 50 offices over&nbsp;24 countries."
      link="http://fitchratings.com"
      label="Learn More"
    />
  ))
  .add('with background image', () => (
    <KeyPoint
      heading="Unrivaled local knowledge"
      abstract="We have 1,100 leading&nbsp;analysts in 50 offices over&nbsp;24 countries."
      link="http://fitchratings.com"
      label="Learn More"
      image={{
        url:
          'https://your.fitchratings.com/rs/732-CKH-767/images/global-leveraged-finance-2.jpg'
      }}
    />
  ))
