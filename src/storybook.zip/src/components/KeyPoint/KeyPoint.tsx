import React from 'react'
import { css } from 'emotion'

import * as styles from './KeyPoint.style'

import {
  buttonWrapper,
  buttonWrapper2,
  button,
  button3,
  content,
  heading1,
  section,
  ta2,
  bgImg,
  wrapper2
} from '../GlobalStyles'

export type KeyPointImage = {
  url: string
}

export type KeyPointProps = {
  heading: string
  abstract: string
  link: string
  label: string
  backgroundColor?: string
  image?: KeyPointImage
}

const renderBackground = (image?: KeyPointImage, backgroundColor?: string) => {
  if (image && image.url) {
    return { backgroundImage: `url(${image.url})` }
  }
  if (backgroundColor) {
    return { backgroundColor }
  }
  return {}
}

export const KeyPoint = ({
  heading,
  abstract,
  link,
  label,
  image,
  backgroundColor
}: KeyPointProps) => (
  <section className={section}>
    <article
      style={renderBackground(image, backgroundColor)}
      className={css`
        ${styles.keyPoint};
        ${ta2};
        ${bgImg};
      `}
    >
      <div
        className={css`
          ${wrapper2};
          ${content};
        `}
      >
        <h3 className={heading1}>{heading}</h3>
        <p>{abstract}</p>
        <div
          className={css`
            ${buttonWrapper};
            ${buttonWrapper2};
          `}
        >
          <a
            className={css`
              ${button};
              ${button3};
            `}
            href={link}
          >
            {label}
          </a>
        </div>
      </div>
    </article>
  </section>
)
