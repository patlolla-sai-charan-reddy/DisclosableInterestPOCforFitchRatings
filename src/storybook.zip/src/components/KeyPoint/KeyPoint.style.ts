import { css } from 'emotion'
import { c5, c9, mpb2 } from '../GlobalStyles'

export const keyPoint = css`
  padding: 84px ${mpb2};
  background: ${c5};
  color: ${c9};
`

export const ctaButton = css`
  color: ${c9};
`
