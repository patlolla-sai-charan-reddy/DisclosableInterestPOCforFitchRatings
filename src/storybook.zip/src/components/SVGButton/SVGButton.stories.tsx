import React from 'react'
import { storiesOf } from '@storybook/react'

import { SVGButton } from '.'

storiesOf('Atoms/SVGButton', module).add('default', () => (
  <div style={{ backgroundColor: 'black', padding: '5rem' }}>
    <SVGButton label="View all outlooks" link="http://www.fitchratings.com" />
  </div>
))
