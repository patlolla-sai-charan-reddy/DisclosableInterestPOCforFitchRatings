import React from 'react'
import { css } from 'emotion'

import * as styles from './SVGButton.style'

export type SVGButtonProps = {
  label: string
  link: string
}

export const SVGButton = ({ label, link }: SVGButtonProps) => (
  <a href={link}>
    <svg
      className={css`
        ${styles.button};
        ${styles.button42};
      `}
    >
      <rect
        className={styles.rect}
        width="200px"
        height="43px"
        x="0"
        y="0"
        rx="8"
        ry="8"
        fillOpacity="1"
        mask="url(#cta-text-1)"
      />
      <mask id="cta-text-1">
        <rect width="200px" height="43px" x="0" y="0" fill="#ffffff" />
        <text x="50%" y="27" fill="#000000" textAnchor="middle">
          {label}
        </text>
      </mask>
    </svg>
  </a>
)
