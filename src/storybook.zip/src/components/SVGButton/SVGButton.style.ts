import { css } from 'emotion'
import { c7, c9 } from '../GlobalStyles'

export const button = css`
  height: auto;
  padding: 10px 18px;
  font-size: 0.938rem;
  font-weight: 800;
  text-transform: uppercase;
  border: 0 none;
  border-radius: 5px;
  outline: none;
  transition: all 350ms ease;
  cursor: pointer;
  display: inline-block;
  margin-right: 1rem;
`

export const button42 = css`
  width: 200px;
  height: 43px;
  padding: 0;
  background: none;
`

export const rect = css`
  width: 100%;
  height: 100%;
  fill: ${c9};
  transition: all 350ms ease;

  &:hover,
  &:focus {
    fill: ${c7};
  }
`
