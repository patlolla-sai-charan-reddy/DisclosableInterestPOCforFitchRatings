import React from 'react'
import uniqid from 'uniqid'

import { RelatedContent } from '.'
import { asideBlock, heading5, listStyle2 } from '../GlobalStyles'

export type RelatedContentsItem = {
  title: string
  dbDocId: string
}

export type RelatedContentsProps = {
  items: RelatedContentsItem[]
}

export const RelatedContents = ({ items }: RelatedContentsProps) => (
  <div className={asideBlock}>
    <h3 className={heading5}>Related Content</h3>
    <ul className={listStyle2}>
      {items.map(item => (
        <RelatedContent {...item} key={uniqid()} />
      ))}
    </ul>
  </div>
)
