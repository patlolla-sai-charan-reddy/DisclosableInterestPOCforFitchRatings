import React from 'react'

import * as styles from './RelatedContent.style'

export type RelatedContentProps = {
  title: string
}

export const RelatedContent = ({ title }: RelatedContentProps) => (
  <li>
    <a href="/" className={styles.listItem}>
      {title}
    </a>
  </li>
)
