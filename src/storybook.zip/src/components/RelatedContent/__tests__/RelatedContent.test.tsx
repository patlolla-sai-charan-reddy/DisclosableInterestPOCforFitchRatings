import TestRenderer from 'react-test-renderer'
import React from 'react'

import { RelatedContent, RelatedContents } from '..'

import mocks from '../__mocks__/RelatedContent.mock'

describe('RelatedContent', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<RelatedContent {...mocks[0]} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})

describe('RelatedContents', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<RelatedContents items={mocks} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})
