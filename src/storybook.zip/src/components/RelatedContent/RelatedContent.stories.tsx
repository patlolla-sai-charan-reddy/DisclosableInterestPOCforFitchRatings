import React from 'react'
import { storiesOf } from '@storybook/react'
import { Query } from 'react-apollo'
import gql from 'graphql-tag'

import { RelatedContent, RelatedContents } from '.'

const GET_RELATED_CONTENT_QUERY = gql`
  {
    getSectorContentForRAC(id: 1000) {
      title
      dbDocId
      fcReportType
    }
  }
`

storiesOf('Atoms/RelatedContent', module).add('default', () => (
  <Query query={GET_RELATED_CONTENT_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>

      return <RelatedContent {...data.getSectorContentForRAC[0]} />
    }}
  </Query>
))

storiesOf('Molecules/RelatedContents', module).add('default', () => (
  <Query query={GET_RELATED_CONTENT_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      return <RelatedContents items={data.getSectorContentForRAC} />
    }}
  </Query>
))
