import React from 'react'
import { css } from 'emotion'

import uniqid from 'uniqid'

import { Person } from './Person'

import {
  columnSix,
  content,
  heading3,
  headingNo,
  section,
  wrapper1
} from '../GlobalStyles'

export type PersonsHeadshot = {
  url: string
  description: string
}

export type PersonsItem = {
  firstName: string
  lastName: string
  department: string
  jobTitle: string
  phoneNumber: string
  headshot: PersonsHeadshot
}

export type PersonsProps = {
  items: PersonsItem[]
}

export const Persons = ({ items }: PersonsProps) => (
  <section className={section}>
    <div className={wrapper1}>
      <h2
        className={css`
          ${heading3};
          ${content};
        `}
      >
        <span className={headingNo}>06</span>
        Contact
      </h2>

      <div className={columnSix}>
        {items.map(item => (
          <Person {...item} key={uniqid()} />
        ))}
      </div>
    </div>
  </section>
)
