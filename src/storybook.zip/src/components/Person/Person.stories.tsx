import React from 'react'
import { storiesOf } from '@storybook/react'
import { Query } from 'react-apollo'
import gql from 'graphql-tag'

import { Person, Persons } from '.'

const GET_PERSONS_QUERY = gql`
  {
    personCollection {
      items {
        jobTitle
        firstName
        lastName
        department
        phoneNumber
        headshot {
          url
          description
        }
      }
    }
  }
`

storiesOf('Atoms/Person', module).add('default', () => (
  <Query query={GET_PERSONS_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { items } = data.personCollection

      return <Person {...items[0]} />
    }}
  </Query>
))

storiesOf('Molecules/People', module).add('default', () => (
  <Query query={GET_PERSONS_QUERY}>
    {({ loading, error, data }) => {
      if (loading) return <p>Loading...</p>
      if (error) return <p>Error :(</p>
      const { items } = data.personCollection

      return <Persons items={items.slice(0, 12)} />
    }}
  </Query>
))
