export default [
  {
    jobTitle: 'Human Optimization Consultant',
    firstName: 'Eliane',
    lastName: 'Gerhold',
    department: 'Infrastructure',
    phoneNumber: '1-583-060-4104 x3312',
    headshot: {
      url:
        'https://images.ctfassets.net/03fbs7oah13w/27UkmtlzmyMvMEyqaTBLCP/905ac437842e85a0c21e6977803e8642/profile-default.png',
      description: 'Default profile image associated with a person'
    }
  },
  {
    jobTitle: 'Corporate Group Technician',
    firstName: 'Carissa',
    lastName: 'Kutch',
    department: 'Response',
    phoneNumber: '1-352-107-9094 x69819',
    headshot: {
      url:
        'https://images.ctfassets.net/03fbs7oah13w/27UkmtlzmyMvMEyqaTBLCP/905ac437842e85a0c21e6977803e8642/profile-default.png',
      description: 'Default profile image associated with a person'
    }
  },
  {
    jobTitle: 'Product Functionality Officer',
    firstName: 'Garfield',
    lastName: 'Predovic',
    department: 'Research',
    phoneNumber: '(192) 623-8411 x19832',
    headshot: {
      url:
        'https://images.ctfassets.net/03fbs7oah13w/27UkmtlzmyMvMEyqaTBLCP/905ac437842e85a0c21e6977803e8642/profile-default.png',
      description: 'Default profile image associated with a person'
    }
  },
  {
    jobTitle: 'Lead Markets Orchestrator',
    firstName: 'Tillman',
    lastName: "O'Kon",
    department: 'Research',
    phoneNumber: '338.810.7238 x8088',
    headshot: {
      url:
        'https://images.ctfassets.net/03fbs7oah13w/27UkmtlzmyMvMEyqaTBLCP/905ac437842e85a0c21e6977803e8642/profile-default.png',
      description: 'Default profile image associated with a person'
    }
  },
  {
    jobTitle: 'Dynamic Accounts Analyst',
    firstName: 'Theodore',
    lastName: 'Gleason',
    department: 'Response',
    phoneNumber: '182.712.5508 x1364',
    headshot: {
      url:
        'https://images.ctfassets.net/03fbs7oah13w/27UkmtlzmyMvMEyqaTBLCP/905ac437842e85a0c21e6977803e8642/profile-default.png',
      description: 'Default profile image associated with a person'
    }
  },
  {
    jobTitle: 'Chief Marketing Representative',
    firstName: 'Rachelle',
    lastName: 'Graham',
    department: 'Data',
    phoneNumber: '(557) 606-6420 x7091',
    headshot: {
      url:
        'https://images.ctfassets.net/03fbs7oah13w/27UkmtlzmyMvMEyqaTBLCP/905ac437842e85a0c21e6977803e8642/profile-default.png',
      description: 'Default profile image associated with a person'
    }
  }
]
