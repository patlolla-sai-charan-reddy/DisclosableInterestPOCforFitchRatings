import TestRenderer from 'react-test-renderer'
import React from 'react'

import { Person, Persons } from '..'

import mocks from '../__mocks__/Person.mock'

describe('Person', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<Person {...mocks[0]} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})

describe('Persons', () => {
  it('renders correctly', () => {
    const tree = TestRenderer.create(<Persons items={mocks} />).toJSON()
    expect(tree).toMatchSnapshot()
  })
})
