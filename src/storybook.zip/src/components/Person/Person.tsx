import React from 'react'

import * as styles from './Person.style'

import { columnSixColumn } from '../GlobalStyles'

export type Headshot = {
  url: string
  description: string
}

export type PersonProps = {
  firstName: string
  lastName: string
  department: string
  jobTitle: string
  phoneNumber: string
  headshot: Headshot
}

export const Person = ({
  firstName,
  lastName,
  department,
  jobTitle,
  phoneNumber,
  headshot
}: PersonProps) => (
  <div className={columnSixColumn}>
    <div className={styles.imageWrapper}>
      <img
        className={styles.image}
        src={headshot.url}
        alt={headshot.description}
        style={{ height: '200px', background: '#171721' }}
      />
    </div>
    <p>
      <strong>
        {firstName} {lastName}
      </strong>
      <br />
      {department}
      <br />
      {jobTitle}
      <br />
      {phoneNumber}
    </p>
  </div>
)
