import { css } from 'emotion'
import { mpb1 } from '../GlobalStyles'

export const imageWrapper = css`
  width: 100%;
`

export const image = css`
  width: 100%;
  max-width: 100%;
  height: auto;
  margin-bottom: ${mpb1};
  display: block;
`
