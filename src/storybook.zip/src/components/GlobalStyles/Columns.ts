import { css } from 'emotion'
import * as variables from './Variables'
import * as mq from './MediaQueries'

export const base = css`
  width: 50%;
  align-items: stetch;
  flex-flow: row wrap;
  display: flex;
  padding: 0 ${variables.mpb1};
  ${mq.mq5} {
    width: 100% !important;
  }
`

export const column = css`
  position: relative;
  margin-bottom: ${variables.mpb2};
  padding: 0 ${variables.mpb1};
`

export const columnTwo = css`
  ${base}
  width: 100%;
`

export const columnTwoColumn = css`
  ${column}
  width: 50%;
`

export const columnThree = css`
  ${base}
  width: 100%;
`

export const columnThreeColumn = css`
  ${column}
  width: 33.33%;
`

export const columnFour = css`
  ${base}
  width: 100%;
`

export const columnFourColumn = css`
  ${column}
  width: 25%;
`

export const columnSix = css`
  ${base}
  width: 100%;
`

export const columnSixColumn = css`
  ${column}
  width: 16.6%;
  ${mq.mq3} {
    width: 33.33%;
  }
  ${mq.mq4} {
    width: 33.33%;
  }
`

export const columnTwo21 = css`
  &:nth-child(1n) {
    width: calc(100% - 360px);
  }
  &:nth-child(2n) {
    width: 360px;
  }
`

export const grow = css`
  position: relative;
  width: 100%;
  align-items: stetch;
  flex-flow: row wrap;
  display: flex;
  padding: 0 ${variables.mpb1};

  justify-content: center;
`

export const columnGrow = css`
  flex-grow: 1;
  ${mq.mq5} {
    width: 100% !important;
  }
`

export const columnGrowColumn = css`
  flex-grow: 1;
  ${mq.mq5} {
    width: 100% !important;
  }
`

export const columnMergeA = css`
  padding: 0;
`

export const columnMergeR = css`
  padding-right: 0;
`

export const columnMergeL = css`
  padding-left: 0;
`
