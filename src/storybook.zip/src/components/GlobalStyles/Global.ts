import { css } from 'emotion'
import * as variables from './Variables'

export const body = css`
  font-family: ${variables.ff1};
  font-size: ${variables.fs1};
  line-height: ${variables.lh1};
  color: ${variables.c2};
  -webkit-font-smoothing: antialiased;
  overflow-x: hidden;
  overflow-y: scroll;
`

export const heading1 = css`
  margin-bottom: ${variables.mpb1};
  font-size: 3rem;
  font-weight: 900;
  line-height: ${variables.lh2};
`

export const heading2 = css`
  margin-bottom: ${variables.mpb1};
  font-size: 2.25rem;
  font-weight: 900;
  line-height: ${variables.lh2};
`

export const heading3 = css`
  margin-bottom: ${variables.mpb1};
  font-size: 1.875rem;
  font-weight: 300;
  line-height: ${variables.lh2};
`

export const heading4 = css`
  margin-bottom: ${variables.mpb1};
  font-size: 1.75rem;
  font-weight: 700;
  line-height: ${variables.lh2};
`

export const heading5 = css`
  margin-bottom: ${variables.mpb1};
  font-size: 1.25rem;
  font-weight: 700;
  line-height: ${variables.lh2};
`

export const heading7 = css`
  margin-bottom: ${variables.mpb1};
  font-size: 1rem;
  font-weight: 900;
  line-height: ${variables.lh2};
  text-transform: uppercase;
`

export const headingSub = css`
  margin-bottom: ${variables.mpb1};
  font-size: 0.625rem;
  font-weight: 900;
  text-transform: uppercase;
  line-height: ${variables.lh2};
`

export const headingNo = css`
  position: relative;
  margin-right: 9px;
  font-weight: 900;

  &:after {
    content: '';
    position: absolute;
    bottom: -2px;
    left: 0;
    width: 100%;
    border-bottom: 1px solid;
    border-color: inherit;
  }
`

export const va = css`
  position: relative;
  top: 50%;
  transform: translateY(-50%);
`

export const euRatingText = css`
  color: #fc7822;
`

export const listStyle2 = css`
  padding: 0;

  li {
    margin-bottom: 0.375rem;
  }
`

export const buttonWrapper = css`
  width: 100%;
`

export const buttonWrapper1 = css`
  margin-top: 0.75rem;
  text-align: left;
`

export const buttonWrapper2 = css`
  text-align: center;
`

export const button = css`
  height: auto;
  padding: 0.625rem 1.125rem;
  font-size: 0.938rem;
  font-weight: 900;
  text-transform: uppercase;
  border: 0 none;
  border-radius: 5px;
  outline: none;
  transition: all 350ms ease;
  cursor: pointer;
  display: inline-block;
`

export const button3 = css`
  background: ${variables.c9};
  border: 2px solid ${variables.c9};
  color: ${variables.c2};

  &:hover,
  &:focus {
    background: #2a8abf;
    border-color: #2a8abf;
    color: ${variables.c9};
  }
`

export const button62 = css`
  background: transparent;
  border: 2px solid ${variables.c2};
  color: ${variables.c2};

  &:hover,
  &:focus {
    background: ${variables.c2};
    border-color: ${variables.c2};
    color: ${variables.c9};
  }
`

export const ta1 = css`
  text-align: left;
  justify-content: flex-start;
`

export const ta2 = css`
  text-align: center;
  justify-content: center;
`

export const ta3 = css`
  text-align: right;
  justify-content: flex-end;
`
export const bgImg = css`
  background-repeat: no-repeat;
  background-position: center center;
  background-size: cover;
`

export const bgBlend = css`
  background-blend-mode: multiply;
`

export const bgOverlay = css`
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: ${variables.c3};
  opacity: 0.44;
`

export const bg1 = css`
  background-color: ${variables.c5};
  color: ${variables.c9};
`

export const bg2 = css`
  background-color: ${variables.c6};
  color: ${variables.c9};
`

export const bg3 = css`
  background-color: ${variables.c7};
  color: ${variables.c2};
`

export const bg4 = css`
  background-color: ${variables.c3};
  color: ${variables.c9};
`

export const bg5 = css`
  background-color: #fc3d67;
  color: ${variables.c9};
`

export const imageWrapper = css`
  width: 100%;
`
