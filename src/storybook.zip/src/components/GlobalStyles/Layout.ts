import { css } from 'emotion'
import * as variables from './Variables'
import * as mq from './MediaQueries'

export const main = css`
  width: 100%;
  float: left;
`

export const header = css`
  ${main}
`

export const footer = css`
  ${main}
`

export const aside = css`
  width: 100%;
  font-size: 0.875rem;
`

export const block = css`
  width: 100%;
  margin-bottom: ${variables.mpb3};
`

export const section = css`
  width: 100%;
  padding: 2.625em 0;
  float: left;
`

export const wrapper1 = css`
  width: 100%;
  margin: auto;
  max-width: 85.5rem;
`

export const wrapper2 = css`
  width: 100%;
  margin: auto;
  max-width: 67.125rem;
`

export const content = css`
  padding: 0 ${variables.mpb2};
`

export const content1 = css`
  padding: 0 ${variables.mpb1};
`

export const article = css`
  position: relative;
  width: 100%;
`

export const articleRow = css`
  margin-bottom: 2.25rem;

  &:last-of-type:not(:first-of-type) {
    margin-bottom: 0;
  }
`

export const pageLayout = css`
  width: 100%;
  float: left;
  ${mq.mq5} {
    div[class*='column'] {
      width: 100%;
      margin: 0;
      padding: 0;
    }
  }
`

export const columnLeftLMR = css`
  width: 13.18%;
  margin-top: 54px;
  float: left;
`

export const columnMainLMR = css`
  width: 63.18%;
  padding-right: 186px;
  float: left;
`

export const columnRightLMR = css`
  width: 23.63%;
  margin-top: 48px;
  float: left;
`

export const columnLeftLM = css`
  width: 13.18%;
  float: left;
`

export const columnMainLM = css`
  width: 63.18%;
  float: left;
`

export const asideBlock = css`
  margin-bottom: ${variables.mpb3};
`
