export const mq1 = `@media only screen and (max-width: 1366px)`
export const mq2 = `@media only screen and (max-width: 1024px)`
export const mq3 = `@media only screen and (max-width: 896px) and (orientation: landscape)`
export const mq4 = `@media only screen and (max-width: 768px)`
export const mq5 = `@media only screen and (max-width: 736px)`
export const mq6 = `@media only screen and (max-width: 480px)`
