import React from 'react'
import ApolloClient from 'apollo-boost'
import { ApolloProvider } from 'react-apollo'
import { configure, addDecorator } from '@storybook/react'
import { css } from 'emotion'

import { c2, ff1, fs1, lh1, mpb2 } from '../src/components/GlobalStyles'

const client = new ApolloClient({
  uri: process.env.REACT_APP_APOLLO
})

const req = require.context('../src', true, /\.stories\.(js|tsx)$/)

const global = css`
  box-sizing: border-box;
  font-family: ${ff1};
  font-size: ${fs1};
  line-height: ${lh1};
  color: ${c2};
  -webkit-font-smoothing: antialiased;

  * {
    margin-top: 0;
    box-sizing: inherit;

    &:before,
    &:after {
      box-sizing: inherit;
    }
  }

  * a {
    font-size: inherit;
    text-decoration: none;
    transition: all 350ms ease;
  }

  p,
  ul,
  ol,
  table {
    margin-bottom: ${mpb2};
  }

  ul,
  ol,
  ul li,
  ol li {
    margin: 0px;
    padding: 0px;
    list-style-image: none;
    list-style-type: none;
  }
`

function loadStories() {
  addDecorator(story => (
    <ApolloProvider client={client}>
      <div className={global}>{story()}</div>
    </ApolloProvider>
  ))
  req.keys().forEach(filename => req(filename))
}

configure(loadStories, module)
